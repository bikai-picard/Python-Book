#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@毕凯，北京市人工影响天气办公室
@ email: bikai_picard@vip.sina.com 
"""
import os 
os.chdir("E:\\BIKAI_books\\data\\chap4\\grimm180") 
os.getcwd() 
import glob2
import pandas as pd

def read_single_grimm_pickup(file_name):
    data_grimm = pd.read_table(file_name,
                               sep='\s+', 
                               header=None) 
    data_grimm.columns=[str(i) for i in data_grimm.columns] 
    data_grimm_1=data_grimm[data_grimm['2']=='N_,']
    
    data_grimm_1['1']=data_grimm_1['1'].apply(lambda x:str(x)[:-1])
    
    data_grimm_1['date_time']=pd.to_datetime(data_grimm_1['0'])+pd.to_timedelta(data_grimm_1['1']) 
    data_grimm_1['PM10']=data_grimm_1['3'].apply(lambda x:x*0.1) 
    data_grimm_1['PM2.5']=data_grimm_1['4'].apply(lambda x:x*0.1) 
    data_grimm_1['PM1']=data_grimm_1['5'].apply(lambda x:x*0.1) 
    
    data_grimm_result=data_grimm_1.loc[:,['date_time','PM10','PM2.5','PM1']] 
    return(data_grimm_result)

if __name__ == '__main__': 
    
    batch_filenames='Grimm*.txt'
    file_grimm_names_list = glob2.glob(batch_filenames) 

    data_grimm=pd.DataFrame() 
    for i in range(len(file_grimm_names_list)): 
        data_single_grimm=read_single_grimm_pickup(file_grimm_names_list[i]) 
        data_grimm= pd.concat([data_grimm,data_single_grimm],ignore_index=True)
    data_grimm=data_grimm.sort_values(by='date_time')
    data_grimm.to_csv('grimm_pm.txt', 
                      sep='\t',
                      index=False, 
                      float_format='%.1f') 




