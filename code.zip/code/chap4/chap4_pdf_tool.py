#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@毕凯，北京市人工影响天气办公室
@ email: bikai_picard@vip.sina.com 
"""
import os
os.chdir("E:\\BIKAI_books\\data\\chap4")
os.getcwd()
from PyPDF2 import PdfFileWriter, PdfFileReader 

def pdf_select_pages_PyPDF2(pdf_input_file,page_list,pdf_out_file):
    pdf_read_file = PdfFileReader(open(pdf_input_file, "rb"))
    write_output = PdfFileWriter()   
    
    pdf_pages_len = pdf_read_file.getNumPages()
    print('总页码数:'+ str(pdf_pages_len))

    for i in range(len(page_list)):
        write_output.addPage(pdf_read_file.getPage(page_list[i]))
  
    write_output.write(open(pdf_out_file, "wb"))   
    return()

def pdf_exchange_page_PyPDF2(pdf_input_file,input_pdf_page_mumber_for_exchange,pdf_exchange_file,use_page_mumber_in_exchange_file,pdf_out_file):

    pdf_read_file = PdfFileReader(open(pdf_input_file, "rb")) 
    write_output = PdfFileWriter()  
    
    exchange_input_file = PdfFileReader(open(pdf_exchange_file, "rb")) 
    exchange_page =exchange_input_file.getPage(use_page_mumber_in_exchange_file)
    if input_pdf_page_mumber_for_exchange==0:   
        
        write_output.addPage(exchange_page)                   
        for i in range(input_pdf_page_mumber_for_exchange+1,len(pdf_read_file.pages)):
            write_output.addPage(pdf_read_file.getPage(i))             
    
    else:
        for i in range(input_pdf_page_mumber_for_exchange):
            write_output.addPage(pdf_read_file.getPage(i))
        write_output.addPage(exchange_page)               
        for j in range(input_pdf_page_mumber_for_exchange+1,len(pdf_read_file.pages)):
            write_output.addPage(pdf_read_file.getPage(j))                  
   
    write_output.write(open(pdf_out_file, "wb"))        
    return()

if __name__ == '__main__':
    
    pdf_input_file='paper.pdf'
    
    pdf_out_file='挑选页面.pdf' 
    page_list=[0,2,5]    
    pdf_select_pages_PyPDF2(pdf_input_file,page_list,pdf_out_file)   
    pdf_exchange_file='snow.pdf' 
    pdf_exchange_out_file='替换页面.pdf' 
    input_pdf_page_mumber_for_exchange=3 
    use_page_mumber_in_exchange_file=0 
    pdf_exchange_page_PyPDF2(pdf_input_file,input_pdf_page_mumber_for_exchange,pdf_exchange_file,use_page_mumber_in_exchange_file,pdf_exchange_out_file) 