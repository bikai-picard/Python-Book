#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@毕凯，北京市人工影响天气办公室
@ email: bikai_picard@vip.sina.com 
"""
import os
os.chdir("/SCI/data_python/BIKAI_books") 
os.getcwd()
import cdsapi 
import datetime as dt 
from queue import Queue 
from threading import Thread 
import time 
start =time.clock()

class DownloadCDS(Thread): 
   def __init__(self, queue): 
       Thread.__init__(self)
       self.queue = queue 
   def run(self):
       while True:
           date_file_name = self.queue.get() 
           download_single_cds_file(date_file_name)
           self.queue.task_done() 

def download_single_cds_file(date_file_name):
    filename=date_file_name+'.nc' 
    if(os.path.isfile(filename)): 
      print("当前数据文件已经存在: ",filename) 
    else:
      print("当前正在下载：",filename)
      c = cdsapi.Client() 
      c.retrieve(
          'reanalysis-era5-pressure-levels', 
          {
              'product_type' : 'reanalysis',
              'format'       : 'netcdf', 
              'variable': ['geopotential', 'relative_humidity','temperature','u_component_of_wind', 'v_component_of_wind', 'vertical_velocity'],
              'pressure_level': ['100','150','200','250', '300', '350','400', '450', '500','550', '600', '650','700', '750', '775','800', '825', '850','875', '900', '925','950', '975', '1000'],                      
              'year' : date_file_name[0:4], 
              'month': date_file_name[-4:-2], 
              'day'  : date_file_name[-2:], 
              'time':['00:00','08:00','14:00','20:00'], 
              'area': [70, 90, 30, 130], 
              'grid': [0.5, 0.5], 
          },         
          filename) 
    
if __name__ == '__main__': 
    
    file_numbers_at_same_time=4 
    start_date ='2019-01-01'
    end_date ='2019-01-05'
    start_date_result=dt.datetime.strptime(start_date,'%Y-%m-%d')
    end_date_result=dt.datetime.strptime(end_date,'%Y-%m-%d')
 
    file_gap_time = dt.timedelta(days=1) 
    print('下载文件开始日期 : '+ start_date)

    date_list_download=[]
    while start_date_result <= end_date_result: 
        date_file_name=start_date_result.strftime("%Y%m%d") 
        
        date_list_download.append(str(date_file_name))
        start_date_result =start_date_result +file_gap_time

    single_queue = Queue() 

    for i in range(file_numbers_at_same_time): 
        single_task = DownloadCDS(single_queue)
        single_task.daemon = True
        single_task.start()     

    for ii in date_list_download:
        single_queue.put((ii)) 
    single_queue.join() 
   
end = time.clock()
print('>>> Total running time: %s Seconds'%(end-start))