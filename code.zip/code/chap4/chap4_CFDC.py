#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@毕凯，北京市人工影响天气办公室
@ email: bikai_picard@vip.sina.com 
"""
import os 
import pandas as pd
import shutil 
from glob import glob 

def batch_cfdc_filenames(filenames):
    kk=pd.DataFrame(filenames) 
    kk.columns =['name'] 
    kk['name'].to_string() 
    kk['date_time']=kk['name'] 
    
    for ii in range(len(kk['name'])): 
        kk['date_time'].loc[ii]=kk['name'].iloc[ii][-18:-14]+'-'+kk['name'].iloc[ii][-14:-12]+'-'+kk['name'].iloc[ii][-12:-10]+' '+kk['name'].iloc[ii][-10:-8]+':'+kk['name'].iloc[ii][-8:-6]+':'+kk['name'].iloc[ii][-6:-4] 
    kk['date_time'] = pd.to_datetime(kk['date_time']) 
    kk1 = kk.sort_values(by='date_time') 
    cfdc_file_name= kk1['name'].tolist() 
    return(cfdc_file_name)
    
def cat_csv(files):
    data_cfdc=pd.DataFrame() 
    for i in range(len(files)): 
        data_cfdc1=pd.read_csv(files[i],header=0) 
        data_cfdc=       pd.concat([data_cfdc,data_cfdc1],ignore_index=True) 
    return(data_cfdc) 
    
def batch_copy_combine(data_path,new_file_path):
    all_file_list = glob(os.path.join(data_path, '*')) 
    csv_file_list=[x for x in all_file_list if x[-3:]=='csv'] 
    if len(csv_file_list)==1: 
        shutil.copy(csv_file_list[0], new_file_path) 
    elif len(csv_file_list)>1: 
        kk=batch_cfdc_filenames(csv_file_list) 
        data_cfdc=cat_csv(kk) 
        data_cfdc.to_csv(new_file_path+'/'+kk[0][-26:], index=False) 
    else:
        pass
    
    for ii in range(len(all_file_list)):
        if os.path.isdir(all_file_list[ii]): 
            print('<<< **************************')
            print('<<< doing Date ： '+str(all_file_list[ii][-8:]))
            batch_copy_combine(all_file_list[ii],new_file_path) 
    return()
    
if __name__ == '__main__':
    
    data_path = "E:\\BIKAI_books\\data\\chap4\\inp_cfdc";
    new_file_path="E:\\BIKAI_books\\data\\chap4\\inp_cfdc" 
    batch_copy_combine(data_path,new_file_path) 
