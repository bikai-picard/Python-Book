#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@毕凯，北京市人工影响天气办公室
@ email: bikai_picard@vip.sina.com 
"""
import os
os.chdir("E:\\BIKAI_books\\data\\chap12")
import pandas as pd 
import matplotlib.pyplot as plt
from matplotlib import ticker
import matplotlib
matplotlib.rcParams['font.sans-serif']=['FangSong']
matplotlib.rcParams['axes.unicode_minus']=False 
import time
start =time.clock()
def read_aimms_data(aimms_name):
    '''构造气象数据读取函数，读入AIMMS20文件名，修改时间为标准日期时间格式，提取并返回温度、气压、湿度、垂直速度、高度等信息。'''  
    data_aimms = pd.read_csv(aimms_name,header=0,skiprows=13)
    data_aimms.columns=['Time','Hours','Minutes', 'Seconds', 'Temp(C)','RH(%)', 'Pressure(mBar)','Wind_Flow_N_Comp(m/s)','Wind_Flow_E_Comp(m/s)','Wind_Speed_(m/s)', 'Wind_Direction_(deg)','Wind_Solution','Hours_2','Minutes_2','Seconds_2','Latitude(deg)','Longitude(deg)','Altitude(m)', 'Velocity_N(m/s)','Velocity_E(m/s)', 'Velocity_D(m/s)','Roll_Angle(deg)','Pitch_angle(deg)','Yaw_angle(deg)','True_Airspeed(m/s)' ,'Vertical_Wind','Sideslip_angle(deg)', 'AOA_pres_differential','Sideslip_differential','Status','GPS Time']
    data_aimms['date_time']=pd.to_datetime(aimms_name[9:17])+pd.to_timedelta(data_aimms['Time'].astype(int),unit='s')    
    data_aimms_1=data_aimms.loc[:,['date_time','Altitude(m)','Temp(C)','Vertical_Wind','RH(%)', 'Pressure(mBar)']]   
    return(data_aimms_1)
 
def cal_plot_elements_vertical_mean(a,para_name='Temp(C)'):
    data_aimms=read_aimms_data(aimms_name)
    data_aimms_v=data_aimms[(data_aimms['Altitude(m)']>=40)]
    max_time=data_aimms_v['date_time'][(data_aimms_v['Altitude(m)']==data_aimms_v['Altitude(m)'].max())].tolist()[0]
    index_max_t=data_aimms_v[data_aimms_v['date_time'] == max_time].index[0]
    data_aimms_v_up=data_aimms_v[:index_max_t]
    data_aimms_v_down=data_aimms_v[index_max_t:]
    sort_up = (data_aimms_v_up['Altitude(m)']/a).astype(int).apply(lambda x: x*a)
    data_aimms_v_up_mean=data_aimms_v_up.groupby(sort_up).mean().set_index('Altitude(m)') 
    data_aimms_v_up_std=data_aimms_v_up.groupby(sort_up).std().set_index('Altitude(m)')
    sort_down = (data_aimms_v_down['Altitude(m)']/a).astype(int).apply(lambda x: x*a)
    data_aimms_v_down_mean=data_aimms_v_down.groupby(sort_down).mean().set_index('Altitude(m)')
    data_aimms_v_down_std=data_aimms_v_down.groupby(sort_down).std().set_index('Altitude(m)') 
    fig,ax = plt.subplots()
    fig.set_size_inches(6,8)
    ax.errorbar(data_aimms_v_up_mean[para_name],
                data_aimms_v_up_mean.index,
                xerr=data_aimms_v_up_std[para_name].values,
                yerr=data_aimms_v_up_std.index.values,
                color='r',
                linestyle='-',
                alpha=1,
                fmt='-o',
                ms=3,
                mec='r', 
                mfc='r',
                ecolor = 'r',
                elinewidth=1, 
                capsize=3,
                errorevery=1, 
                capthick=None, 
                label=str(a)+'m平均_上升阶段')
    ax.errorbar(data_aimms_v_down_mean[para_name], data_aimms_v_down_mean.index,xerr=data_aimms_v_down_std[para_name].values,yerr=data_aimms_v_down_std.index.values,color='b',linestyle='-',alpha=1,fmt='-o',ms=3,mec='b',mfc='b',ecolor='b',elinewidth=1,capsize=3,errorevery=1,capthick=None,label=str(a)+'m平均_下降阶段')
        
    ax.yaxis.grid(True,
                  which='major',
                  linestyle=":") 
    ax.xaxis.grid(True,
                  which='major',
                  linestyle=":")  
    
    ax.xaxis.set_minor_locator(ticker.MultipleLocator(1))
    ax.yaxis.set_minor_locator(ticker.MultipleLocator(100))
    ax.legend(loc ='best',fontsize=10)
    ax.set_xlabel('温度($^\circ$C)',fontsize=15)
    ax.set_ylabel('高度(m)',fontsize=15)
    ax.set_ylim(0, 6000)
    ax.set_xlim(-30,21) 
    ax.tick_params(labelsize=15) 
    fig.savefig('图12.6_温度廓线_'+str(a)+'m平均.pdf',
                dpi = 300,
                bbox_inches='tight',pad_inches=0.1)
    plt.close()
    return() 

if __name__ == '__main__':
        
    aimms_name='07AIMMS2020100818093022.csv'
    data_aimms=read_aimms_data(aimms_name) 
    cal_plot_elements_vertical_mean(200,'Temp(C)') 
end = time.clock() 
print('>>> Total running time: %s Seconds'%(end-start))
