#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@毕凯，北京市人工影响天气办公室
@ email: bikai_picard@vip.sina.com 
"""
import os 
os.environ['PROJ_LIB'] = 'D:\\anaconda\\Library\\share' 
os.chdir("E:\\BIKAI_books\\data\\chap12")
os.getcwd()
import matplotlib.colors as clr 
from mpl_toolkits.mplot3d import Axes3D 
import matplotlib as mpl 
import pandas as pd 
import matplotlib.pyplot as plt
from mpl_toolkits.basemap import Basemap 
import numpy as np
import matplotlib
matplotlib.rcParams['font.sans-serif']=['FangSong']
matplotlib.rcParams['axes.unicode_minus']=False 
from collections import OrderedDict
cmaps = OrderedDict()
import time 
start =time.clock() 

def reverse_colourmap(cmap, name='reverse_cmap'):
    turn_color = [] 
    list_t = []
    for j in cmap._segmentdata: 
        list_t.append(j)
        color_pool = cmap._segmentdata[j]
        color_data = []
        for i in color_pool:
            color_data.append((1 - i[0], i[2], i[1]))
        turn_color.append(sorted(color_data))
    new_color_Linear = dict(zip(list_t, turn_color))
    reverse_cmap = mpl.colors.LinearSegmentedColormap(name, new_color_Linear)
    return (reverse_cmap)
			
    #读取数据
def read_aimms_data(aimms_name):  
    data_aimms = pd.read_csv(aimms_name,
                             header=0,
                             skiprows=13)
    data_aimms.columns=['Time','Hours','Minutes', 'Seconds', 'Temp(C)','RH(%)', 'Pressure(mBar)','Wind_Flow_N_Comp(m/s)','Wind_Flow_E_Comp(m/s)','Wind_Speed_(m/s)', 'Wind_Direction_(deg)','Wind_Solution','Hours_2','Minutes_2','Seconds_2','Latitude(deg)','Longitude(deg)','Altitude(m)', 'Velocity_N(m/s)','Velocity_E(m/s)', 'Velocity_D(m/s)','Roll_Angle(deg)','Pitch_angle(deg)','Yaw_angle(deg)','True_Airspeed(m/s)' ,'Vertical_Wind','Sideslip_angle(deg)', 'AOA_pres_differential','Sideslip_differential','Status','GPS_time']
    data_aimms['Date']=aimms_name[9:13]+'-'+aimms_name[13:15]+'-'+aimms_name[15:17]
    data_aimms['Date'] = pd.to_datetime(data_aimms['Date']) 
    data_aimms['date_time']=data_aimms['Date']+pd.to_timedelta(data_aimms['Time'].astype(int),unit='s')  
    
    data_aimms_1=data_aimms.loc[:,['date_time','Latitude(deg)','Longitude(deg)','Altitude(m)','Temp(C)']] 
    
    return(data_aimms_1)

def plot_basemap(ax1,fig,code_map_type):
    m = Basemap(projection='cyl',
                llcrnrlon=114,
                urcrnrlon=119, 
                llcrnrlat=37,
                urcrnrlat=43,
                ax=ax1, 
                resolution='c')

    m.drawparallels(np.arange(37, 43.1, 1),
                    labels=[1, 0, 0, 0],
                    linewidth=0.0,)
    m.drawmeridians(np.arange(114, 119, 2),
                    labels=[0, 0, 0, 1],
                    linewidth=0.0,)
    if code_map_type==1:
        m.arcgisimage(service='ESRI_Imagery_World_2D', xpixels = 1500, verbose= True) 
        m.readshapefile('shp_for_basemap/bou2_4p',
                    'bou2_4p',
                    color='w', 
                    linewidth=1)   
    elif code_map_type==0: 

        m.readshapefile('shp_for_basemap/bou2_4p',
                    'bou2_4p',
                    color='k',
                    linewidth=2) 
        gaolon = np.loadtxt('shp_for_basemap/gaochenglon.txt') 
        gaolat = np.loadtxt('shp_for_basemap/gaochenglat.txt') 
        gaocheng = np.loadtxt('shp_for_basemap/gaocheng.txt') 
        gaolon, gaolat = np.meshgrid(gaolon, gaolat)
        norm = clr.Normalize(vmin=0,vmax=5000)
        cs = m.contourf(gaolon,
                        gaolat, 
                        gaocheng,
                        
                        cmap=reverse_colourmap(plt.cm.gray), 
                        levels=np.arange(0, 3000, 50),
                        alpha=1,
                        norm =norm)
    
        fig.subplots_adjust(left=0.07,right=0.87)
        box_map = ax1.get_position() 
        pad, width = 0.1, 0.01 
        cax_map = fig.add_axes([box_map.xmax - pad,box_map.ymin,width,box_map.height]) 
        cbar_map = fig.colorbar(cs,
                                cax=cax_map,
                                ticks=np.arange(0,3100,500))
        cbar_map.set_label('地形高度(m)',fontsize=15)
        cbar_map.ax.tick_params(labelsize=12) 
    ax1.set_yticks(np.arange(37,43.1,0.5))
    ax1.set_yticklabels([])
    ax1.set_xticks(np.arange(114,119, 0.5)) 
    ax1.set_xticklabels([])
    return(m)
    
def plot_aircraft_track(data_aimms,code_map_type):
    fig,ax1= plt.subplots()
    fig.set_size_inches(12,10) 
    norm = clr.Normalize(vmin=0, vmax=7000)
    if code_map_type==0:
        plot_basemap(ax1,fig,0) 
        type_name='_gray_base_'
        sca=ax1.scatter(data_aimms['Longitude(deg)'],
                                   data_aimms['Latitude(deg)'],
                                   marker='o',
                                   s=1,
                                   c=data_aimms['Altitude(m)'],
                                   label='',
                                   norm =norm,
                                   cmap='jet') 
        cax = fig.add_axes([ 0.45, 0.15,0.25,0.02])
        cbar=fig.colorbar(sca,
                          cax =cax,
                          orientation='horizontal',
                          extend='both') 
        cbar.ax.set_title('飞行高度(m)',fontsize=15) 
        cbar.ax.tick_params(labelsize=12)
    elif code_map_type==1: 
        plot_basemap(ax1,fig,1)
        type_name='_satelite_base_'
        
        sca=ax1.scatter(data_aimms['Longitude(deg)'],
                                   data_aimms['Latitude(deg)'],
                                   marker='o', 
                                   s=1,
                                   c=data_aimms['Altitude(m)'],
                                   label='',
                                   norm =norm,
                                   cmap='jet')  
        fig.subplots_adjust(left=0.07,right=0.87)
        box_map = ax1.get_position()
        pad, width = 0.1, 0.01 
        cax_map = fig.add_axes([box_map.xmax - pad,box_map.ymin,width,box_map.height]) 
        cbar_map = fig.colorbar(sca,
                                cax=cax_map,
                                extend='max')
        cbar_map.set_label('飞行高度(m)',fontsize=15) 
        cbar_map.ax.tick_params(labelsize=12)
    fig.savefig('flight_track'+type_name+aimms_name[9:13]+'-'+aimms_name[13:15]+'-'+aimms_name[15:17]+'.pdf',
                dpi = 300,
                bbox_inches='tight', pad_inches=0.1)
    plt.close()         
    return()

def plot_3D_track(data_aimms):

    fig = plt.figure() 
    fig.set_size_inches(5,5)
    ax = Axes3D(fig)
     
    norm = clr.Normalize(vmin=-20, vmax=20) 
    sca=ax.scatter3D(data_aimms['Longitude(deg)'],
                              data_aimms['Latitude(deg)'],
                              data_aimms['Altitude(m)'],
                              marker='o',
                              s=1, 
                              c=data_aimms['Temp(C)'], 
                              cmap='jet', 
                              norm =norm)
    ax.scatter3D(data_aimms['Longitude(deg)'],data_aimms['Latitude(deg)'],0,marker='o',s=1,c='gray', alpha=0.3 )
    
    ax.set_zlim(0,7000) 
    ax.set_xlabel('经度',fontsize=8) 
    ax.set_ylabel('纬度',fontsize=8) 
    ax.set_zlabel('高度(m)',fontsize=8)
    ax.tick_params(labelsize=10) 
    
    ax.zaxis.labelpad=0
    cax = fig.add_axes([ 0.05, 0.75,0.02,0.2])
    cbar=fig.colorbar(sca,cax =cax,orientation='vertical',extend='both')
    cbar.ax.set_title('温度($^\circ$C)',fontsize=10) 
    cbar.ax.tick_params(labelsize=10)
    fig.savefig('图12.3_3维飞行轨迹_'+aimms_name[9:13]+'-'+aimms_name[13:15]+'-'+aimms_name[15:17]+'.pdf',dpi = 300)  
    plt.close()
    return()
    
if __name__ == '__main__':
        
    aimms_name='07AIMMS2020100818093022.csv' 
    data_aimms=read_aimms_data(aimms_name)
    plot_aircraft_track(data_aimms,0)
    plot_aircraft_track(data_aimms,1) 
    plot_3D_track(data_aimms) 
end = time.clock()
print('>>> Total running time: %s Seconds'%(end-start))