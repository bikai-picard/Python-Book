#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@毕凯，北京市人工影响天气办公室
@ email: bikai_picard@vip.sina.com 
"""
import os
os.chdir("E:\\BIKAI_books\\data\\chap12")
os.getcwd()
import pandas as pd 
import matplotlib.pyplot as plt
import matplotlib.dates as mdate
import matplotlib
matplotlib.rcParams['font.sans-serif']=['FangSong']
matplotlib.rcParams['axes.unicode_minus']=False   
import time 
start =time.clock() 

def read_aimms_data(aimms_name):
    data_aimms = pd.read_csv(aimms_name,header=0,skiprows=13) 
    data_aimms.columns=['Time','Hours','Minutes', 'Seconds', 'Temp(C)','RH(%)', 'Pressure(mBar)','Wind_Flow_N_Comp(m/s)','Wind_Flow_E_Comp(m/s)','Wind_Speed_(m/s)', 'Wind_Direction_(deg)','Wind_Solution','Hours_2','Minutes_2','Seconds_2','Latitude(deg)','Longitude(deg)','Altitude(m)', 'Velocity_N(m/s)','Velocity_E(m/s)', 'Velocity_D(m/s)','Roll_Angle(deg)','Pitch_angle(deg)','Yaw_angle(deg)','True_Airspeed(m/s)' ,'Vertical_Wind','Sideslip_angle(deg)', 'AOA_pres_differential','Sideslip_differential','Status','GPS_time']
    data_aimms['date_time']=pd.to_datetime(aimms_name[9:17])+pd.to_timedelta(data_aimms['Time'].astype(int),unit='s')    
    data_aimms_1=data_aimms.loc[:,['date_time','Altitude(m)','Temp(C)','Vertical_Wind','RH(%)', 'Pressure(mBar)']]
    return(data_aimms_1)

def plot_subplots_elements_timeseries(data):
    fig,(ax1,ax2,ax3,ax4,ax5) = plt.subplots(5,1,sharex=True)
    fig.set_size_inches(8,10)
    ax = [ax1,ax2,ax3,ax4,ax5] 
    ylist = ['Altitude(m)','Temp(C)','Vertical_Wind','RH(%)', 'Pressure(mBar)'] 
    ylabel_list = ['高度（m）','温度($^\circ$C)','垂直速度(m/s)','相对湿度（%）','气压(hpa)'] 
    for i in range(len(ax)): 
        ax[i].plot(data['date_time'],
          data[ylist[i]], 
          c='k',
          ls='-', 
          lw=1,
          alpha=0.7,
										label=ylabel_list[i]) 
        ax[i].grid(True,
          linestyle=":", 
          linewidth=1, 
          alpha=0.5)
        ax[i].set_ylabel(ylabel_list[i],
          fontsize=15)
        ax[i].tick_params(labelsize=15)
        
    ax5.xaxis.set_major_formatter(mdate.DateFormatter('%H:%M'))
    ax5.set_xlabel('时间',
                   fontsize=15) 
    fig.savefig('图12.4_机载气象要素多子图时间序列.pdf',
                dpi = 300, 
                bbox_inches='tight', pad_inches=0.1)
    plt.close()
    return()

def plot_mul_ys_elements_timeseries(data_aimms):
    fig,ax = plt.subplots(1,1)
    fig.set_size_inches(10,5) 
    ax1 = ax.twinx() 
    ax2 = ax.twinx() 
    ax3 = ax.twinx()
    ax4 = ax.twinx() 
    
    f0, =ax.plot(data_aimms['date_time'] 
             data_aimms['Altitude(m)'], 
             c='k',
             ls='', 
             marker='o',
             ms=2, 
             lw=1, 
             mec='k', 
             mfc='k',
             alpha=0.3, 
             label='高度 (m)')    
    f1, =ax1.plot(data_aimms['date_time'] ,
             data_aimms['Temp(C)'],
             c='b',
             ls='',
             marker='o', 
             ms=2, 
             lw=1, 
             mec='b',
             mfc='b',
             alpha=0.3, 
             label='温度 ($^\circ$C)') 

    f2, =ax2.plot(data_aimms['date_time'] ,data_aimms['RH(%)'],c='r',ls='', marker='o', ms=2,lw=1, mec='r',mfc='r',alpha=0.3,label='相对湿度(%)') 
    f3, =ax3.plot(data_aimms['date_time'],data_aimms['Pressure(mBar)'],c='purple',ls='', marker='o',ms=2,lw=1,mec='purple',mfc='purple',alpha=0.3,label='气压(hpa)')
    f4, =ax4.plot(data_aimms['date_time'] , data_aimms['Vertical_Wind'],c='g',ls='',marker='o',ms=2,lw=1,mec='g',mfc='g',alpha=0.3,label='垂直速度（m/s）')

    ax2.spines['right'].set_position(('outward', 50)) 
    ax3.spines['right'].set_position(('outward', 100))
    ax4.spines['right'].set_position(('outward', 170)) 
    ax2.yaxis.set_ticks_position('right')
    ax3.yaxis.set_ticks_position('right')
    ax4.yaxis.set_ticks_position('right')
    ylabel_list = ['高度（m）','温度($^\circ$C)','相对湿度（%）','气压(hpa)','垂直速度(m/s)'] 
    axx=[ax,ax1,ax2,ax3,ax4] 
    ff=[f0,f1,f2,f3,f4]
    
    for i in range(len(axx)): 
        axx[i].set_ylabel(ylabel_list[i],
          fontsize=15)         
        if i==0:
            axx[i].spines['left'].set_color(ff[i].get_color())
        else:
            axx[i].spines['right'].set_color(ff[i].get_color())
        axx[i].yaxis.label.set_color(ff[i].get_color())
        axx[i].tick_params(labelsize=15) 
        axx[i].tick_params(axis='y', colors=ff[i].get_color()) 
    ax.xaxis.set_major_formatter(mdate.DateFormatter('%H:%M')) 
    
    for tick in ax.get_xticklabels(): 
        tick.set_rotation(30)     
    fig.savefig('图12.5_机载气象要素多y轴时间序列.pdf',
                dpi = 300,
                bbox_inches='tight', pad_inches=0.1) 
    plt.close()       
    return()
    
if __name__ == '__main__':
        
    aimms_name='07AIMMS2020100818093022.csv'
    data_aimms=read_aimms_data(aimms_name)
    plot_subplots_elements_timeseries(data_aimms)
    plot_mul_ys_elements_timeseries(data_aimms)
end = time.clock()
print('>>> Total running time: %s Seconds'%(end-start))
