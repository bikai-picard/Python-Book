#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@毕凯，北京市人工影响天气办公室
@ email: bikai_picard@vip.sina.com 
"""
import os
os.chdir("E:\\BIKAI_books\\data\\chap12")
os.getcwd()

import numpy as np 
import pandas as pd 
import matplotlib.pyplot as plt 
import matplotlib.dates as mdate 
import matplotlib
matplotlib.rcParams['font.sans-serif']=['FangSong'] 
matplotlib.rcParams['axes.unicode_minus']=False  
from netCDF4 import Dataset 
from numpy import ma 
import glob2  
import datetime as dt 
import time
start =time.clock() 

def read_height_file(height_file):
    data_m300 =pd.read_csv(height_file,header=0)
    data_m300.columns=['date_time','Altitude']
    data_m300['date_time'] = pd.to_datetime(data_m300['date_time'])
    return(data_m300)
   
def load_single_kpr_data(kpr_file):
    ncfile = Dataset(kpr_file)
    time_nc = [dt.datetime.utcfromtimestamp(i).strftime("%Y-%m-%d %H:%M:%S") for i in ncfile.variables['TIME']] 
    time_nc =pd.to_datetime(pd.Series(time_nc))+pd.to_timedelta('8H',unit='H') 
    height=ncfile.variables['HEIGHT'][:].tolist() 
    height_kpr=[1000*i for i in height]
    height_kpr_df=pd.DataFrame(height_kpr)
    var_nc_kpr_dbz = ncfile.variables['CP'][:] 
    var_nc_kpr_dbz_df=pd.DataFrame(var_nc_kpr_dbz)
    var_nc_kpr_dbz_df['date_time']=time_nc
    var_nc_kpr_dbz_df= var_nc_kpr_dbz_df.resample('1S',on='date_time').mean()
    time_nc_new=time_nc.drop_duplicates(keep='first')
    time_nc_new_df=pd.DataFrame(time_nc_new.values)
    return(height_kpr_df,time_nc_new_df,var_nc_kpr_dbz_df)

def read_kpr_data():
    batch_files = 'kpr*.nc'
    kpr_name=glob2.glob(batch_files)
    if len(kpr_name)>1:
        list_all=pd.DataFrame(kpr_name)
        list_all.columns =['name']
        list_all['name'].to_string()
        list_all['date_time']=list_all['name']
        for ii in range(len(list_all['name'])):
            list_all['date_time'].loc[ii]=list_all['name'].iloc[ii][-18:-10]+list_all['name'].iloc[ii][-9:-3]
        list_all['date_time'] = pd.to_datetime(list_all['date_time'])
        list_all1 = list_all.sort_values(by='date_time')
        sort_file_name= list_all1['name'].tolist()
        data_kpr_t=pd.DataFrame()
        height_kpr_t=pd.DataFrame()
        time_nc_new_df_t=pd.DataFrame()
        for jj in range(len(sort_file_name)):
            kpr_file=sort_file_name[jj]
            height_kpr2,time_nc_new_df2,data_kpr2=load_single_kpr_data(kpr_file)
            data_kpr_t=       pd.concat([data_kpr_t,data_kpr2],ignore_index=True)
            height_kpr_t=       pd.concat([height_kpr_t,height_kpr2],ignore_index=True,axis=1) 
            time_nc_new_df_t=pd.concat([time_nc_new_df_t,time_nc_new_df2],ignore_index=True,axis=0)
            data_kpr_t.index=time_nc_new_df_t
    else:
        height_kpr_t,time_nc_new_df_t,data_kpr_t=load_single_kpr_data(kpr_name[0])
        data_kpr_t.index=time_nc_new_df_t 
    time_nc_new_df_t.columns=['date_time']
    return(height_kpr_t.iloc[:,0],time_nc_new_df_t,data_kpr_t)        

def reshape_kpr_data(data_m300_v1,height_kpr_ori,time_nc_new_df,data_kpr_all):
    data_comb=pd.merge(time_nc_new_df,data_m300_v1,on='date_time',how='left')
    data_comb['Altitude']=data_comb['Altitude'].fillna(29)
    data_comb['code']=data_comb['Altitude']/15+1
    data_comb['code']=data_comb['code'].astype(int)
    list_height=[6956.08+15*(i+1) for i in range(600)]
    height_result=height_kpr_ori.values.tolist()+list_height
    data_new_kpr = pd.DataFrame(np.ones((len(data_kpr_all),1530))*-99) 
    data_new_kpr.index=data_kpr_all.index
    for ii in [i for i in range(930)]: 
        data_new_kpr[ii]=data_kpr_all[ii]
    data_new_kpr1=data_new_kpr.reset_index(drop=True) 
    data_new_kpr_t=data_new_kpr1.T 
    for jj in range(len(data_kpr_all)):
        data_new_kpr_t.loc[:,jj]=data_new_kpr_t.loc[:,jj].shift(data_comb['code'].values[jj]) 
    data_new_kpr_result=data_new_kpr_t.T 
    data_new_kpr_result.index=data_kpr_all.index
    return(height_result,data_new_kpr_result) 
    
def plot_kpr(height_modi,data_kpr):
    x = data_kpr.index
    y = height_modi
    z = data_kpr
    z = ma.masked_where(z <= -35, z) 
    Z = z.T  
    X,Y = np.meshgrid(x,y)    
    fig,ax = plt.subplots()
    fig.set_size_inches(15,6)
    gap_ax = np.arange(-20,10,0.1)
    im=ax.contourf(X,Y,Z,gap_ax,cmap='jet',extend='both') 
    ax.yaxis.grid(False)
    ax.set_ylabel('高度 (m)',fontsize=15) 
    ax.set_xlabel('时间',fontsize=15) 
    ax.tick_params(labelsize=15)
       
    ymin =0 
    ymax =4200
    ax.set_ylim(ymin,ymax) 
				
    ax.xaxis.set_major_formatter(mdate.DateFormatter('%H:%M')) 
   
    fig.subplots_adjust(left=0.07,right=0.87)
    box= ax.get_position()
    pad, width = 0.02, 0.01
    cax = fig.add_axes([box.xmax + pad, box.ymin, width, box.height])
    
    cbar = fig.colorbar(im,cax=cax,
                        extend='both',
                        orientation='vertical') 
    cbar.set_label('(dBZ)',fontsize=12) 
    cbar.ax.tick_params(labelsize=12)      

    fig.savefig('图12.7_机载云雷达垂直回波廓线图.png',dpi = 300, bbox_inches='tight', pad_inches=0.1)
    plt.close() 
    return()

if __name__ == '__main__':
        
    height_file='kpr_20180812_flight_height.csv'  
    data_m300_v1=read_height_file(height_file)
    height_kpr_ori,time_nc_new_df,data_kpr_all=read_kpr_data() 
    height_modi,data_kpr=reshape_kpr_data( data_m300_v1,height_kpr_ori,time_nc_new_df,data_kpr_all)
    plot_kpr(height_modi,data_kpr)

end = time.clock()
print('>>> Total running time: %s Seconds'%(end-start))