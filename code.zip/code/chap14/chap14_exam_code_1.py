#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@毕凯，北京市人工影响天气办公室
@ email: bikai_picard@vip.sina.com 
"""
import os 
os.chdir("E:\\BIKAI_books\\data\\chap14")
os.getcwd() 
import matplotlib.pyplot as plt
import pandas as pd 
from matplotlib import ticker 
import matplotlib.dates as mdate 
import numpy as np 
import glob2 
from matplotlib.backends.backend_pdf import PdfPages
import matplotlib
matplotlib.rcParams['font.sans-serif']=['FangSong']
matplotlib.rcParams['axes.unicode_minus']=False 
import time
start =time.clock() 

def batch_MWR_filenames(batch_files):
    filenames = glob2.glob(batch_files) 
    kk=pd.DataFrame(filenames) 
    kk.columns =['name'] 
    kk['name'].to_string() 
    kk['date_time']=kk['name'] 
    for ii in range(len(kk['name'])):
        kk['date_time'].loc[ii]=kk['name'].iloc[ii][2:12]   
    kk['date_time'] = pd.to_datetime(kk['date_time'])
    kk1 = kk.sort_values(by='date_time') 
    MWR_file_name= kk1['name'].tolist() 
    return(MWR_file_name) 

def read_single_MWR_plot(filename):
    data_MWR=pd.read_csv(filename,
                         skiprows=3,
                         header=None)
    data_MWR.columns = ['Record','date_time','code','Tamb(C)','Rh(%)','Pres(hPa)','Tir(℃)','Rain','Vint(cm)','Lqint(mm)','CloudBase(km)','0.000km','0.050km','0.100km','0.150km','0.200km','0.250km','0.300km','0.350km','0.400km','0.450km','0.500km','0.600km','0.700km','0.800km','0.900km','1.000km','1.100km','1.200km','1.300km','1.400km','1.500km','1.600km','1.700km','1.800km','1.900km','2.000km','2.250km','2.500km','2.750km','3.000km','3.250km','3.500km','3.750km','4.000km','4.250km','4.500km','4.750km','5.000km','5.250km','5.500km','5.750km','6.000km','6.250km','6.500km','6.750km','7.000km','7.250km','7.500km','7.750km','8.000km','8.250km','8.500km','8.750km','9.000km','9.250km','9.500km','9.750km','10.000km']
    data_MWR['date_time'] = pd.to_datetime(data_MWR['date_time'])
    data_MWR['code'] = data_MWR['code'].apply(str) 
    data_MWR_group = data_MWR.groupby(['code'])
    data_MWR_Tamb = data_MWR_group.get_group('11')       
    data_MWR_WaterVapor = data_MWR_group.get_group('12')
    data_MWR_RH = data_MWR_group.get_group('13')         
    data_MWR_LWC = data_MWR_group.get_group('14')        
    headerpsd=['0.000km','0.050km','0.100km','0.150km','0.200km','0.250km','0.300km','0.350km','0.400km','0.450km','0.500km','0.600km','0.700km','0.800km','0.900km','1.000km','1.100km','1.200km','1.300km','1.400km','1.500km','1.600km','1.700km','1.800km','1.900km','2.000km','2.250km','2.500km','2.750km','3.000km','3.250km','3.500km','3.750km','4.000km','4.250km','4.500km','4.750km','5.000km','5.250km','5.500km','5.750km','6.000km','6.250km','6.500km','6.750km','7.000km','7.250km','7.500km','7.750km','8.000km','8.250km','8.500km','8.750km','9.000km','9.250km','9.500km','9.750km','10.000km']
    data_MWR_Tamb_psd = pd.DataFrame()
    for i in headerpsd:
        data_MWR_Tamb_psd[i]=data_MWR_Tamb[i]
    data_MWR_Tamb_psd.index = data_MWR_Tamb['date_time'] 
    z_Tamb = data_MWR_Tamb_psd
    Z_Tamb_psd = z_Tamb.T
    data_MWR_WaterVapor_psd = pd.DataFrame()
    for i in headerpsd:
        data_MWR_WaterVapor_psd[i]=data_MWR_WaterVapor[i]
    data_MWR_WaterVapor_psd.index = data_MWR_WaterVapor['date_time']
    z_WaterVapor = data_MWR_WaterVapor_psd
    Z_WaterVapor_psd = z_WaterVapor.T 
    data_MWR_RH_psd = pd.DataFrame()
    for i in headerpsd:
        data_MWR_RH_psd[i]=data_MWR_RH[i]
    data_MWR_RH_psd.index = data_MWR_RH['date_time']
    z_RH = data_MWR_RH_psd
    Z_RH_psd = z_RH.T 
    data_MWR_LWC_psd = pd.DataFrame()
    for i in headerpsd:
        data_MWR_LWC_psd[i]=data_MWR_LWC[i]
    data_MWR_LWC_psd.index = data_MWR_LWC['date_time'] 
    z_LWC = data_MWR_LWC_psd
    Z_LWC_psd = z_LWC.T 
    x = data_MWR_Tamb['date_time'].tolist()
    y =[0.000,0.050,0.100,0.150,0.200,0.250,0.300,0.350,0.400,0.450,0.500,0.600,0.700,0.800,0.900,1.000,1.100,1.200,1.300,1.400,1.500,1.600,1.700,1.800,1.900,2.000,2.250,2.500,2.750,3.000,3.250,3.500,3.750,4.000,4.250,4.500,4.750,5.000,5.250,5.500,5.750,6.000,6.250,6.500,6.750,7.000,7.250,7.500,7.750,8.000,8.250,8.500,8.750,9.000,9.250,9.500,9.750,10.000]
    X,Y = np.meshgrid(x,y) 

    fig,(ax12,ax1,ax22,ax2,ax32,ax3,ax42,ax4) = plt.subplots(8,1,sharex=True) 
    fig.set_size_inches(16,16)
    gap_ax_Tamb = np.linspace(-50,0,50,endpoint=True)
    gap_cb_Tamb= np.linspace(-50,0,6,endpoint=True) 
    gap_ax_RH = np.linspace(0,100,50,endpoint=True) 
    gap_cb_RH= np.linspace(0,100,6,endpoint=True) 
    gap_ax_LWC = np.linspace(0,0.3,50,endpoint=True)  
    gap_cb_LWC= np.linspace(-0,0.3,6,endpoint=True) 
    gap_ax_WaterVapor = np.linspace(0,3,50,endpoint=True) 
    gap_cb_WaterVapor= np.linspace(0,3,6,endpoint=True) 
    ax12.plot(data_MWR_Tamb['date_time'],
             data_MWR_Tamb['Tamb(C)'], 
             c='k', 
             ls='',
             lw=1, 
             marker='.',
             ms=2, 
             alpha=1,
             label='地面温度($^\circ$C)')
    ax22.plot(data_MWR_RH['date_time'],data_MWR_RH['Rh(%)'],c='r',ls='',lw=1,marker='.',ms=2,alpha=1,label='相对湿度（%）')
    ax32.plot(data_MWR_WaterVapor['date_time'],data_MWR_WaterVapor['Vint(cm)'],c='b',ls='',lw=1,marker='.',ms=2,alpha=1,label='积分水汽量(cm)')  
    ax42.plot(data_MWR_LWC['date_time'],data_MWR_LWC['Lqint(mm)'],c='g',ls='',lw=1,marker='.',ms=2,alpha=1,label='积分液水量(mm)')

    CS1 = ax1.contourf(X,Y,
                       Z_Tamb_psd,
                       gap_ax_Tamb,
                       cmap='jet',
                       origin='lower',
                       extend='both') 
    cbar1 = fig.colorbar(CS1,
                         shrink=1.0,
                         aspect=20,
                         pad=0.05, 
                         fraction=0.05,ticks=gap_cb_Tamb,ax=[ax1,ax12]) 
    cbar1.set_label('温度($^\circ$C)',fontsize=8)
    
    CS2 =ax2.contourf(X,Y,Z_RH_psd,gap_ax_RH,cmap='jet',origin='lower',extend='both')
    cbar2 = fig.colorbar(CS2,shrink=1.0,aspect=20,pad=0.05,fraction=0.05,ticks=gap_cb_RH,ax=[ax2,ax22]) 
    cbar2.set_label('湿度(%)',fontsize=8)
    CS3 =ax3.contourf(X,Y,Z_WaterVapor_psd,gap_ax_WaterVapor,cmap='jet',origin='lower',extend='both')
    cbar3 = fig.colorbar(CS3,shrink=1.0,aspect=20,pad=0.05,fraction=0.05,ticks=gap_cb_WaterVapor,ax=[ax3,ax32]) 
    cbar3.set_label('水汽密度(g/m^3)',fontsize=8) 
    CS4 =ax4.contourf(X,Y,Z_LWC_psd,gap_ax_LWC,cmap='jet',origin='lower',extend='both')
    cbar4 = fig.colorbar(CS4,shrink=1.0,aspect=20,pad=0.05,fraction=0.05,ticks=gap_cb_LWC,ax=[ax4,ax42])
    cbar4.set_label('液水含量(g/m^3)',fontsize=8)

    ax12.grid(True,
             linestyle=":", 
             linewidth=1, 
             alpha=0.5) 
    ax22.grid(True,linestyle=":",linewidth=1,alpha=0.5)
    ax32.grid(True,linestyle=":",linewidth=1,alpha=0.5)
    ax42.grid(True,linestyle=":",linewidth=1,alpha=0.5)

    ax1.set_ylabel('高度(km)')
    ax2.set_ylabel('高度(km)')
    ax3.set_ylabel('高度(km)')
    ax4.set_ylabel('高度(km)')
    ax12.set_ylabel('温度($^\circ$C)') 
    ax22.set_ylabel('湿度(%)') 
    ax32.set_ylabel('积分水汽(cm)') 
    ax42.set_ylabel('积分液水(mm)')     
    
    ax4.set_xlabel('时间',fontsize=10)  
    ax4.xaxis.set_major_formatter(mdate.DateFormatter('%H:%M'))
    ax4.xaxis.set_minor_locator(mdate.HourLocator(interval=1))
    ax4.yaxis.set_major_locator(ticker.MultipleLocator(2))

    ax12.set_title('微波辐射计时间序列 '+str(data_MWR_Tamb['date_time'][0])[0:10],fontsize=12)
    return()

if __name__ == '__main__':  
    batch_files = 'ZP*LV2.CSV' 
    filenames=batch_MWR_filenames(batch_files)
    with PdfPages('图14.1微波辐射计综合图.pdf') as pdf: 
        for i in filenames:
            read_single_MWR_plot(i)
            pdf.savefig() 
            print('I am BK! plot '+i[2:12]+'  done!!!')
            plt.close() 

end = time.clock() 
print('>>> Total running time: %s Seconds'%(end-start))
