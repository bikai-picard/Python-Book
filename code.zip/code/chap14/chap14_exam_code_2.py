#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@毕凯，北京市人工影响天气办公室
@ email: bikai_picard@vip.sina.com 
"""
import os
os.chdir("E:\\BIKAI_books\\data\\chap14")
os.getcwd() 
import matplotlib.pyplot as plt 
import pandas as pd 
import matplotlib.dates as mdate
from matplotlib import ticker
import matplotlib
matplotlib.rcParams['font.sans-serif']=['FangSong'] 
matplotlib.rcParams['axes.unicode_minus']=False 
import numpy as np 
import glob2 
import time
start =time.clock() 

def batch_MWR_filenames(batch_files):
    filenames = glob2.glob(batch_files) 
    kk=pd.DataFrame(filenames)
    kk.columns =['name'] 
    kk['name'].to_string()
    kk['date_time']=kk['name'] 
    for ii in range(len(kk['name'])):
        kk['date_time'].loc[ii]=kk['name'].iloc[ii][2:12]  
    kk['date_time'] = pd.to_datetime(kk['date_time'])
    kk1 = kk.sort_values(by='date_time') 
    MWR_file_name= kk1['name'].tolist()
    return(MWR_file_name) 

def read_comb_group_MWR_file(filenames): 
    data_MWR= pd.DataFrame()
    for i in range(len(filenames)): 
        data_MWR_single=pd.read_csv(filenames[i],
                         skiprows=3,
                         header=None)
        data_MWR= pd.concat([data_MWR,data_MWR_single],ignore_index=True)
    data_MWR.columns = ['Record','date_time','code','Tamb(C)','Rh(%)','Pres(hPa)','Tir(℃)','Rain','Vint(cm)','Lqint(mm)','CloudBase(km)','0.000km','0.050km','0.100km','0.150km','0.200km','0.250km','0.300km','0.350km','0.400km','0.450km','0.500km','0.600km','0.700km','0.800km','0.900km','1.000km','1.100km','1.200km','1.300km','1.400km','1.500km','1.600km','1.700km','1.800km','1.900km','2.000km','2.250km','2.500km','2.750km','3.000km','3.250km','3.500km','3.750km','4.000km','4.250km','4.500km','4.750km','5.000km','5.250km','5.500km','5.750km','6.000km','6.250km','6.500km','6.750km','7.000km','7.250km','7.500km','7.750km','8.000km','8.250km','8.500km','8.750km','9.000km','9.250km','9.500km','9.750km','10.000km']
    data_MWR['date_time'] = pd.to_datetime(data_MWR['date_time']) 
    data_MWR['code'] = data_MWR['code'].apply(str)
    data_MWR_group = data_MWR.groupby(['code'])
    return(data_MWR_group)
        
def plot_RH_psd_timeseries(data_MWR_group):   
    data_MWR_RH = data_MWR_group.get_group('13')          
    headerpsd=['0.000km','0.050km','0.100km','0.150km','0.200km','0.250km','0.300km','0.350km','0.400km','0.450km','0.500km','0.600km','0.700km','0.800km','0.900km','1.000km','1.100km','1.200km','1.300km','1.400km','1.500km','1.600km','1.700km','1.800km','1.900km','2.000km','2.250km','2.500km','2.750km','3.000km','3.250km','3.500km','3.750km','4.000km','4.250km','4.500km','4.750km','5.000km','5.250km','5.500km','5.750km','6.000km','6.250km','6.500km','6.750km','7.000km','7.250km','7.500km','7.750km','8.000km','8.250km','8.500km','8.750km','9.000km','9.250km','9.500km','9.750km','10.000km']

    data_MWR_RH_psd = pd.DataFrame()
    for i in headerpsd:
        data_MWR_RH_psd[i]=data_MWR_RH[i]
    data_MWR_RH_psd.index = data_MWR_RH['date_time']
    z_RH = data_MWR_RH_psd
    Z_RH_psd = z_RH.T
    x = data_MWR_RH['date_time'].tolist()
    y =[0.000,0.050,0.100,0.150,0.200,0.250,0.300,0.350,0.400,0.450,0.500,0.600,0.700,0.800,0.900,1.000,1.100,1.200,1.300,1.400,1.500,1.600,1.700,1.800,1.900,2.000,2.250,2.500,2.750,3.000,3.250,3.500,3.750,4.000,4.250,4.500,4.750,5.000,5.250,5.500,5.750,6.000,6.250,6.500,6.750,7.000,7.250,7.500,7.750,8.000,8.250,8.500,8.750,9.000,9.250,9.500,9.750,10.000]
    X,Y = np.meshgrid(x,y)

    fig,(ax22,ax2) = plt.subplots(2,1,sharex=True)
    fig.set_size_inches(8,5)
    gap_ax_RH = np.linspace(0,100,50,endpoint=True)
    gap_cb_RH= np.linspace(0,100,6,endpoint=True) 
    ax22.plot(data_MWR_RH['date_time'],
             data_MWR_RH['Rh(%)'],
             c='k',
             ls='', 
             lw=1,  
             marker='.',
             ms=2, 
             alpha=1,
             label='相对湿度（%）') 
    
    CS2 =ax2.contourf(X,Y,Z_RH_psd,gap_ax_RH,cmap='jet',origin='lower',extend='both')
    box2 = ax2.get_position() 
    pad, width = 0.01, 0.01   
    cax2 = fig.add_axes([box2.xmax + pad, box2.ymin, width, box2.height])  
    cbar2 = fig.colorbar(CS2,ticks=gap_cb_RH,cax=cax2)
    cbar2.set_label('湿度(%)',fontsize=8)
    cax2.tick_params(labelsize=8) 
    ax22.grid(True,
             linestyle=":", 
             linewidth=1, 
             alpha=0.5) 

    ax2.set_ylabel('高度(km)')
    ax22.set_ylabel('湿度(%)')    
    
    ax22.set_xlabel('时间',fontsize=10) 
    ax2.xaxis.set_major_formatter(mdate.DateFormatter('%m/%d'))
    ax2.xaxis.set_major_locator(mdate.DayLocator(interval=1))
    ax2.xaxis.set_minor_locator(mdate.HourLocator(interval=12))

    fig.savefig('图14.2_相对湿度及廓线时间序列.pdf',
                dpi = 300, 
                bbox_inches='tight',pad_inches=0.1)
    print('绘制完毕相对湿度时间序列图！！！')
    plt.close()     
    return()
    
def plot_RH_psd_mean(data_MWR_group,time_list,color_list):

    data_MWR_RH = data_MWR_group.get_group('13')          
    headerpsd=['0.000km','0.050km','0.100km','0.150km','0.200km','0.250km','0.300km','0.350km','0.400km','0.450km','0.500km','0.600km','0.700km','0.800km','0.900km','1.000km','1.100km','1.200km','1.300km','1.400km','1.500km','1.600km','1.700km','1.800km','1.900km','2.000km','2.250km','2.500km','2.750km','3.000km','3.250km','3.500km','3.750km','4.000km','4.250km','4.500km','4.750km','5.000km','5.250km','5.500km','5.750km','6.000km','6.250km','6.500km','6.750km','7.000km','7.250km','7.500km','7.750km','8.000km','8.250km','8.500km','8.750km','9.000km','9.250km','9.500km','9.750km','10.000km']
    data_MWR_RH_psd = pd.DataFrame()
    for i in headerpsd:
        data_MWR_RH_psd[i]=data_MWR_RH[i]
    data_MWR_RH_psd.index = data_MWR_RH['date_time'] 
    y =[ 0.000,0.050,0.100,0.150,0.200,0.250,0.300,0.350,0.400,0.450,0.500,0.600,0.700,0.800,0.900,1.000,1.100,1.200,1.300,1.400,1.500,1.600,1.700,1.800,1.900,2.000,2.250,2.500,2.750,3.000,3.250,3.500,3.750,4.000,4.250,4.500,4.750,5.000,5.250,5.500,5.750,6.000,6.250,6.500,6.750,7.000,7.250,7.500,7.750,8.000,8.250,8.500,8.750,9.000,9.250,9.500,9.750,10.000]
    
    fig,ax = plt.subplots()
    fig.set_size_inches(7,5) 
    for i in range(len(time_list)): 
        RS_X_RH= data_MWR_RH_psd.loc[time_list[i][0]:time_list[i][1],:].mean()  
        RS_X_RH_std = data_MWR_RH_psd.loc[time_list[i][0]:time_list[i][1],:].std()   
        df = pd.DataFrame()
        df['RH']=RS_X_RH.T 
        df['RH_std']=RS_X_RH_std.T 

        ax.errorbar(RS_X_RH, 
                    y, 
                    xerr=RS_X_RH_std,
                    color=color_list[i],
                    linestyle=':', 
                    alpha=1,
                    fmt='-o', 
                    ms=4, 
                    mec=color_list[i], 
                    mfc=color_list[i],
                    ecolor =color_list[i], 
                    elinewidth=1,
                    capsize=3, 
                    errorevery=1,capthick=None,
                    label=time_list[i][0]+'——'+time_list[i][1]) 
        ax.grid(True,linestyle=":",linewidth=1,alpha=0.5) 
        ax.legend(loc ='best',fontsize=6) 
        ax.set_xlabel('相对湿度(%)',fontsize=15) 
        ax.set_ylabel('高度（km）',fontsize=15) 
        ax.set_ylim(0, 10) 
        ax.yaxis.set_major_locator(ticker.MultipleLocator(2))
        ax.yaxis.set_minor_locator(ticker.MultipleLocator(1))
        ax.set_xlim(0, 100) 
        ax.xaxis.set_major_locator(ticker.MultipleLocator(20))
        ax.xaxis.set_minor_locator(ticker.MultipleLocator(10))
        ax.tick_params(labelsize=15) 
    fig.savefig('图14.3_相对湿度廓线.pdf',
                dpi = 300, 
                bbox_inches='tight', pad_inches=0.1)
    print('绘制完毕相对湿度垂直廓线图！！！')
    plt.close() 
    return()    
    
if __name__ == '__main__':
    batch_files = 'ZP*LV2.CSV'

    filenames=batch_MWR_filenames(batch_files)
    data_MWR_group=read_comb_group_MWR_file(filenames) 
				
    plot_RH_psd_timeseries(data_MWR_group) 
    
    time_list=[['2019-02-21 11:00:00','2019-02-21 13:00:00'],
               ['2019-02-22 23:00:00','2019-02-23 01:00:00'],
               ['2019-02-24 18:00:00','2019-02-24 20:00:00']] 
    color_list=['g','r','b',] 
    plot_RH_psd_mean(data_MWR_group,time_list,color_list)  

end = time.clock()
print('>>> Total running time: %s Seconds'%(end-start))
