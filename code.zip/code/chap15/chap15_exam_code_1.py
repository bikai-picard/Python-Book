#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@毕凯，北京市人工影响天气办公室
@ email: bikai_picard@vip.sina.com 
"""
import os 
os.chdir("E:\\BIKAI_books\\data\\chap15")
os.getcwd() 
import pandas as pd  
import glob2 
import time
start =time.clock()   

def batch_fm120_filenames(batch_files): 
    filenames = glob2.glob(batch_files) 
    kk=pd.DataFrame(filenames)
    kk.columns =['name'] 
    kk['name'].to_string()
    kk['date_time']=kk['name']
    for ii in range(len(kk['name'])):
        kk['date_time'].loc[ii]=kk['name'].iloc[ii][8:12]+'-'+kk['name'].iloc[ii][12:14]+'-'+kk['name'].iloc[ii][14:16]+' '+kk['name'].iloc[ii][16:18]+':'+kk['name'].iloc[ii][16:18]+':'+kk['name'].iloc[ii][18:20] 
    kk['date_time'] = pd.to_datetime(kk['date_time'])
    kk1 = kk.sort_values(by='date_time') 
    fog_file_name= kk1['name'].tolist() 
    return(fog_file_name) 

def load_data(fog_file):
    data_fog = pd.read_csv(fog_file,
                           skiprows=96,
                           header=0)
    data_fog['Date'] = pd.to_datetime(data_fog['Date']) 
    data_fog['Time'] = pd.to_timedelta(data_fog['Time'])  
    data_fog['date_time']=data_fog['Date'] +pd.to_timedelta(data_fog['Time'].astype(str))
    data_fog['date_time'] = pd.to_datetime(data_fog['date_time'],format='%Y-%m-%d %H:%M:%S') 

    data_fog1 =data_fog.resample('60S',on='date_time').mean()
    data_fog_1m_all=data_fog1.reset_index(['date_time'])
    return(data_fog_1m_all)
if __name__ == '__main__': 
    
    batch_files = '00FM*.csv' 
    fog_files_names=batch_fm120_filenames(batch_files

    data_fog_all=pd.DataFrame()
    for i in range(len(fog_files_names)):
        fog_file=fog_files_names[i]
        data_fog2=load_data(fog_file) 
        data_fog_all=       pd.concat([data_fog_all,data_fog2],ignore_index=True)
    data_fog_all.to_csv('雾滴谱.csv',  
                        index=False,
                        encoding='gbk') 
print('数据处理完毕，已经输出数据！！！')
end = time.clock() 
print('>>> Total running time: %s Seconds'%(end-start))

