#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@毕凯，北京市人工影响天气办公室
@ email: bikai_picard@vip.sina.com 
"""
import os
os.chdir("E:\\BIKAI_books\\data\\chap15")
os.getcwd()
import matplotlib.pyplot as plt
import matplotlib.colors as clr
import pandas as pd
import numpy as np 
from numpy import ma 
from matplotlib import ticker 
import matplotlib.dates as mdate
import math
import matplotlib
matplotlib.rcParams['font.sans-serif']=['FangSong']
matplotlib.rcParams['axes.unicode_minus']=False 
matplotlib.rcParams.update({'text.usetex': False,'mathtext.fontset': 'cm',}) 
import time
start =time.clock() 

def cbar_ticks(start,end):
    cbar_lib_list=[0.00000000001,0.0000000001,0.000000001,0.00000001,0.0000001,0.000001,0.00001,0.0001,0.001,0.01,0.1,1,10,100,1000,10000,100000,1000000,10000000] 
    id_start=[]
    id_end=[]
    
    for i in range(len(cbar_lib_list)): 
        if  cbar_lib_list[i]<= start:
            id_start=i
        if cbar_lib_list[i]<=end :
            id_end=i+1
    result_start=id_start
    result_end=id_end
    cbar_list=cbar_lib_list[result_start:result_end+1]
    return(cbar_list)

def load_data_select_to_dnddp(fog_file,Xmin,Xmax): 
    data_fog = pd.read_csv(fog_file,
                           header=0,	 engine='python',
                           encoding='gbk')
    data_fog['date_time']=pd.to_datetime(data_fog['date_time'],format='%Y-%m-%d %H:%M:%S') 
    data_fog =data_fog.set_index('date_time') 
    data_fog_select_time = data_fog.loc[Xmin:Xmax,:]
    headerlist=['Fog Monitor Bin 1','Fog Monitor Bin 2','Fog Monitor Bin 3','Fog Monitor Bin 4','Fog Monitor Bin 5','Fog Monitor Bin 6','Fog Monitor Bin 7','Fog Monitor Bin 8','Fog Monitor Bin 9','Fog Monitor Bin 10','Fog Monitor Bin 11','Fog Monitor Bin 12','Fog Monitor Bin 13','Fog Monitor Bin 14','Fog Monitor Bin 15','Fog Monitor Bin 16','Fog Monitor Bin 17','Fog Monitor Bin 18','Fog Monitor Bin 19','Fog Monitor Bin 20','Fog Monitor Bin 21','Fog Monitor Bin 22','Fog Monitor Bin 23','Fog Monitor Bin 24','Fog Monitor Bin 25','Fog Monitor Bin 26','Fog Monitor Bin 27','Fog Monitor Bin 28','Fog Monitor Bin 29','Fog Monitor Bin 30']
    data_psd_N = pd.DataFrame() 
    for i in headerlist:
        data_psd_N[i]=data_fog_select_time[i]
    data_psd_N.index=data_fog_select_time.index
    
    bin_list_low_upper = [3,4,5,6,7,8,9,10,11,12,13,14,16,18,20,22,24,26,28,30,32,34,36,38,40,42,44,46,48,50]
    dDp_list = []
    for kk in range(len(bin_list_low_upper)):
        c=bin_list_low_upper[kk]-bin_list_low_upper[kk-1]
        dDp_list.append(c)
    dDp_list[0]=1 
    data_fog_select_time['sample_volumn'] = data_fog_select_time['Applied PAS (m/s)'].map(lambda x: 0.388*x)
    data_psd_CN = data_psd_N.div(data_fog_select_time['sample_volumn'],axis=0)
    dDp_df = pd.DataFrame(np.random.rand(data_psd_CN.shape[0],data_psd_CN.shape[1]))
    dDp_df1= pd.DataFrame(dDp_list).T
    dDp_df.columns=data_psd_CN.columns 
    dDp_df.index=data_psd_CN.index  
    
    for iii in range(data_psd_CN.shape[0]):
        dDp_df.iloc[iii] = dDp_df1.values
    data_fm_dn_ddp = data_psd_CN / dDp_df
    print('分档数据计算完毕！！！')
    return(data_fm_dn_ddp)

def plot_psd_timeseries(data_fog):
    x = data_fog.index.tolist() 
    y=[3,4,5,6,7,8,9,10,11,12,13,14,16,18,20,22,24,26,28,30,32,34,36,38,40,42,44,46,48,50] 
    X,Y = np.meshgrid(x,y) 

    z_tem =  data_fog.values
    z_tem=ma.masked_where(z_tem <= 0, z_tem) 
				
    start_list=z_tem.min()
    end_list=z_tem.max()
    cbar_ticks_list=cbar_ticks(start_list,end_list) 
    gap_ax = np.logspace(math.log10(start_list),math.log10(end_list),30,endpoint=True)
    z =  data_fog.values
    Z = z.T
    fig,ax = plt.subplots()
    fig.set_size_inches(7.2,2)
    im = ax.contourf(X,Y,Z,gap_ax,norm=clr.LogNorm(),cmap='jet',origin='lower')
    ax.yaxis.grid(False)
    ax.set_xlabel('时间',fontsize=10) 
    ax.set_ylabel('直径 (μm)',fontsize=10)

    ymin =3
    ymax =50
    ax.set_ylim(ymin,ymax)
    ax.tick_params(labelsize=12) 
    ax.xaxis.set_major_formatter(mdate.DateFormatter('%H:%M'))
    ax.xaxis.set_minor_locator(mdate.HourLocator(interval=1))
    ax.yaxis.set_minor_locator(ticker.MultipleLocator(5)) 
    ax.yaxis.set_major_locator(ticker.MultipleLocator(10)) 
    fig.subplots_adjust(left=0.07, right=0.87) 
    box = ax.get_position() 
    pad, width = 0.02, 0.02 
    cax = fig.add_axes([box.xmax + pad, box.ymin, width, box.height]) 
    cbar= fig.colorbar(im,cax=cax,extend='both',ticks=cbar_ticks_list)
    cbar.set_label('(cm$^{-3}$μm$^{-1}$)',fontsize=10)
    cbar.ax.tick_params(labelsize=10) 
    fig.savefig('图15.3_云雾滴谱时间序列.png', 
                dpi = 300,
                bbox_inches='tight',pad_inches=0.1)
    plt.close()
    print('雾滴谱时间序列图绘制完毕！！！')
    return()

def plot_psd_mean(data_fog,time_list,color_c):
    x=[3,4,5,6,7,8,9,10,11,12,13,14,16,18,20,22,24,26,28,30,32,34,36,38,40,42,44,46,48,50]    
    fig,ax = plt.subplots() 
    fig.set_size_inches(7,5)
    data_fog_mean_dp = pd.DataFrame()
    for i in range(len(time_list)): 
        data_fog_mean_dp= data_fog.loc[time_list[i][0]:time_list[i][1],:].mean()   
        df_ave_dNdDp_fog = pd.DataFrame()
        df_ave_dNdDp_fog['dp']=x
        df_ave_dNdDp_fog['dN']=data_fog_mean_dp.T.values 
								
        ax.plot(df_ave_dNdDp_fog['dp'],df_ave_dNdDp_fog['dN'],color=color_c[i],label=time_list[i][0][-8:-3]+'-'+time_list[i][1][-8:-3],linestyle='-',lw=1,alpha=1,marker='o',ms=4,mec=color_c[i],mfc=color_c[i]) 
        ax.set_xlabel('直径(μm)',fontsize=15)
        ax.set_ylabel('分档数浓度（cm$^{-3}$μm$^{-1}$）',fontsize=15)
        ax.set_yscale('log') 
        ax.grid(True,linestyle=":",linewidth=1,alpha=0.5)
        ax.set_xlim(2, 50)
        ax.xaxis.set_major_locator(ticker.MultipleLocator(5))
        ax.xaxis.set_minor_locator(ticker.MultipleLocator(1))
        ax.legend(loc ='best',fontsize=10)  
        ax.tick_params(labelsize=15) 
    fig.savefig('图15.4_雾滴谱平均谱.png',
                dpi = 300, 
                bbox_inches='tight', pad_inches=0.1)
    plt.close()
    print('分段平均谱绘制完毕！！！')
    return()

if __name__ == '__main__':
    fog_file = '雾滴谱.csv' 

    Xmin='2019-04-24 00:00:00'  
    Xmax='2019-04-25 00:00:00'  
    
    time_list=[['2019-04-24 01:00:00','2019-04-24 02:00:00'],
               ['2019-04-24 05:00:00','2019-04-24 06:00:00'],
               ['2019-04-24 14:00:00','2019-04-24 15:00:00']]
    color_list=['g','r','b',]    
    data_fog=load_data_select_to_dnddp(fog_file,Xmin,Xmax)   
    plot_psd_timeseries(data_fog)    
    plot_psd_mean(data_fog,time_list,color_list)
end = time.clock()
print('>>> Total running time: %s Seconds'%(end-start))