#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@毕凯，北京市人工影响天气办公室
@ email: bikai_picard@vip.sina.com 
"""
import os 
os.chdir("E:\\BIKAI_books\\data\\chap15")
os.getcwd()
import matplotlib.pyplot as plt
import pandas as pd
import time
start =time.clock() 
def load_data_select(fog_file,Xmin,Xmax): 
    data_fog = pd.read_csv(fog_file,
                           header=0,	engine='python',
                           encoding='gbk')
    data_fog['date_time']=pd.to_datetime(data_fog['date_time'],format='%Y-%m-%d %H:%M:%S') 
    data_fog =data_fog.set_index('date_time')
    data_fog_select_time = data_fog.loc[Xmin:Xmax,:]
    headerlist=['Status','DOF Reject Counts','Sizer Noise Bandwidth','Sizer Baseline Threshold','Qualifier Noise Bandwidth','Qualifier Baseline Threshold','Over Range','Laser Current (mA)','Laser Power','Laser Block Temp (C)','Window Temp (C)','Unused','Static Press (mbar)','Dynamic Press (mbar)','Electronics Temp (C)','Power Supply Temp (C)','Top Plate Temp (C)','Recovery Temp (C)','Detector Temp (C)','Inlet Horn Temp (C)','T Ambient (C)','PAS (m/s)','Number Conc (#/cm^3)','LWC (g/m^3)','MVD (um)','ED (um)','Applied PAS (m/s)','Fog Monitor Bin 1','Fog Monitor Bin 2','Fog Monitor Bin 3','Fog Monitor Bin 4','Fog Monitor Bin 5','Fog Monitor Bin 6','Fog Monitor Bin 7','Fog Monitor Bin 8','Fog Monitor Bin 9','Fog Monitor Bin 10','Fog Monitor Bin 11','Fog Monitor Bin 12','Fog Monitor Bin 13','Fog Monitor Bin 14','Fog Monitor Bin 15','Fog Monitor Bin 16','Fog Monitor Bin 17','Fog Monitor Bin 18','Fog Monitor Bin 19','Fog Monitor Bin 20','Fog Monitor Bin 21','Fog Monitor Bin 22','Fog Monitor Bin 23','Fog Monitor Bin 24','Fog Monitor Bin 25','Fog Monitor Bin 26','Fog Monitor Bin 27','Fog Monitor Bin 28','Fog Monitor Bin 29','Fog Monitor Bin 30']
    data_result_log = pd.DataFrame()
    for i in headerlist:
        data_result_log[i]=data_fog_select_time[i] 
    data_result_log.index=data_fog_select_time.index 
    return(data_result_log)
    
def plot_log(data_result_log):
    fig,ax = plt.subplots() 
    fig.set_size_inches(10,100) 
    data_result_log.plot(subplots=True,ax=ax)
    fig.savefig('图15.2_雾滴谱仪信号通道时间序列图.pdf', 
                dpi = 300, 
                bbox_inches='tight',pad_inches=0.1)
    plt.close() 
    return()

if __name__ == '__main__': 
    fog_file = '雾滴谱.csv' 

    Xmin='2019-04-24 00:00:00'  
    Xmax='2019-04-25 00:00:00'  
				
    data_fog=load_data_select(fog_file,Xmin,Xmax) 
    plot_log(data_fog)

end = time.clock() 
print('>>> Total running time: %s Seconds'%(end-start))