#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@毕凯，北京市人工影响天气办公室
@ email: bikai_picard@vip.sina.com 
"""
import os
os.chdir("E:\\BIKAI_books\\data\\chap15") 
os.getcwd()
import matplotlib.pyplot as plt
import pandas as pd 
import matplotlib.dates as mdate 
import math 
import matplotlib
matplotlib.rcParams['font.sans-serif']=['FangSong'] 
matplotlib.rcParams['axes.unicode_minus']=False 
import time
start =time.clock()
def load_data_select_to_dnddp(fog_file,Xmin,Xmax): 
    data_fog = pd.read_csv(fog_file,
                           header=0, engine='python',
                           encoding='gbk') 
    data_fog['date_time']=pd.to_datetime(data_fog['date_time'],format='%Y-%m-%d %H:%M:%S')
    data_fog =data_fog.set_index('date_time')
    data_fog_select_time = data_fog.loc[Xmin:Xmax,:]
    headerlist=['Fog Monitor Bin 1','Fog Monitor Bin 2','Fog Monitor Bin 3','Fog Monitor Bin 4','Fog Monitor Bin 5','Fog Monitor Bin 6','Fog Monitor Bin 7','Fog Monitor Bin 8','Fog Monitor Bin 9','Fog Monitor Bin 10','Fog Monitor Bin 11','Fog Monitor Bin 12','Fog Monitor Bin 13','Fog Monitor Bin 14','Fog Monitor Bin 15','Fog Monitor Bin 16','Fog Monitor Bin 17','Fog Monitor Bin 18','Fog Monitor Bin 19','Fog Monitor Bin 20','Fog Monitor Bin 21','Fog Monitor Bin 22','Fog Monitor Bin 23','Fog Monitor Bin 24','Fog Monitor Bin 25','Fog Monitor Bin 26','Fog Monitor Bin 27','Fog Monitor Bin 28','Fog Monitor Bin 29','Fog Monitor Bin 30']
    data_psd_N = pd.DataFrame()
    for i in headerlist:
        data_psd_N[i]=data_fog_select_time[i]
    data_psd_N.index=data_fog_select_time.index 
    
    data_fog_select_time['sample_volumn'] = data_fog_select_time['Applied PAS (m/s)'].map(lambda x: 0.388*x) 
    data_psd_CN = data_psd_N.div(data_fog_select_time['sample_volumn'],axis=0)  
    return(data_psd_CN)
        
def cal_para(data_psd_CN): 
 
    data_tot_con= data_psd_CN.sum(axis=1)
    data_tot_con_temp=pd.DataFrame(data_tot_con ).reset_index()
    data_tot_con_temp.columns=['date_time','fm_conc']
    FM_Bin=[3,4,5,6,7,8,9,10,11,12,13,14,16,18,20,22,24,26,28,30,32,34,36,38,40,42,44,46,48,50] 
    headerlist=['Fog Monitor Bin 1','Fog Monitor Bin 2','Fog Monitor Bin 3','Fog Monitor Bin 4','Fog Monitor Bin 5','Fog Monitor Bin 6','Fog Monitor Bin 7','Fog Monitor Bin 8','Fog Monitor Bin 9','Fog Monitor Bin 10','Fog Monitor Bin 11','Fog Monitor Bin 12','Fog Monitor Bin 13','Fog Monitor Bin 14','Fog Monitor Bin 15','Fog Monitor Bin 16','Fog Monitor Bin 17','Fog Monitor Bin 18','Fog Monitor Bin 19','Fog Monitor Bin 20','Fog Monitor Bin 21','Fog Monitor Bin 22','Fog Monitor Bin 23','Fog Monitor Bin 24','Fog Monitor Bin 25','Fog Monitor Bin 26','Fog Monitor Bin 27','Fog Monitor Bin 28','Fog Monitor Bin 29','Fog Monitor Bin 30'] 
    data_fm_dm_psd = pd.DataFrame() 
    for mm in range(len(headerlist)): 
        data_fm_dm_psd[headerlist[mm]]=data_psd_CN[headerlist[mm]]*(math.pi/6)*(FM_Bin[mm])**3*(10**-6)
    data_fm_lwc= data_fm_dm_psd.sum(axis=1) 
    data_tot_lwc_temp=pd.DataFrame(data_fm_lwc).reset_index()
    data_tot_lwc_temp.columns=['date_time','fm_lwc']
    data_fm_ed0_psd = pd.DataFrame()
    data_fm_ed1_psd = pd.DataFrame()
    data_fm_ed2_psd = pd.DataFrame()
    data_fm_ed3_psd = pd.DataFrame()
    for edi in range(len(headerlist)):
        data_fm_ed3_psd[headerlist[edi]]=data_psd_CN[headerlist[edi]]*(FM_Bin[edi])**3
        data_fm_ed2_psd[headerlist[edi]]=data_psd_CN[headerlist[edi]]*(FM_Bin[edi])**2
        data_fm_ed1_psd[headerlist[edi]]=data_psd_CN[headerlist[edi]]*(FM_Bin[edi])**1
        data_fm_ed0_psd[headerlist[edi]]=data_psd_CN[headerlist[edi]]*(FM_Bin[edi])**0
        
    data_fm_ed3= data_fm_ed3_psd.sum(axis=1)
    data_fm_ed2= data_fm_ed2_psd.sum(axis=1) 
    data_fm_ed1= data_fm_ed1_psd.sum(axis=1)
    data_fm_ed0= data_fm_ed0_psd.sum(axis=1)
    
    data_ED_fm=data_fm_ed3/data_fm_ed2
    data_ED_fm=pd.DataFrame(data_ED_fm).reset_index() 
    data_ED_fm.columns=['date_time','ED']
    data_MD_fm=data_fm_ed1/data_fm_ed0
    data_MD_fm=pd.DataFrame(data_MD_fm).reset_index()
    data_MD_fm.columns=['date_time','MD']
    data_fm_MD_simga_psd = pd.DataFrame()
    for edi in range(len(headerlist)):
        data_fm_MD_simga_psd[headerlist[edi]]=data_psd_CN[headerlist[edi]]*(FM_Bin[edi]-data_MD_fm['MD'].values)**2       
    data_fm_MD_simga_0= data_fm_MD_simga_psd.sum(axis=1)    
    data_fm_MD_simga=data_fm_MD_simga_0/data_fm_ed0
    data_fm_MD_simga=pd.DataFrame(data_fm_MD_simga).reset_index()    
    data_fm_MD_simga.columns=['日期时间','sigma2']
    data_fm_MD_simga['谱宽(μm)']=data_fm_MD_simga['sigma2'].map(lambda x: math.sqrt(x)/2)
    data_fm_MD_simga.drop(['sigma2'],axis=1,inplace=True) 
    data_fm_MD_simga['平均半径(μm)']=data_MD_fm['MD']/2 
    data_fm_MD_simga['有效半径(μm)']=data_ED_fm['ED']/2 
    data_fm_MD_simga['散度']=data_fm_MD_simga['谱宽(μm)']/data_fm_MD_simga['平均半径(μm)']
    data_fm_MD_simga['数浓度(#/cm^3)']=data_tot_con_temp['fm_conc']
    data_fm_MD_simga['液水含量(g/m^3)']=data_tot_lwc_temp['fm_lwc']

    data_fm_MD_simga.to_csv('雾滴谱微物理量.csv',
                        index=False, 
                        encoding='gbk') 
    print('微观物理参量计算并输出完毕！！！')
    return(data_fm_MD_simga)

def plot_para(data_fog):  
    fig,(ax1,ax2,ax3,ax4,ax5,ax6) = plt.subplots(6,1,sharex=True)
    fig.set_size_inches(8,10) 
    ax1.plot(data_fog['日期时间'],
            data_fog['数浓度(#/cm^3)'],
                    c='k', 
                    ls='-',
                    lw=1,
                    alpha=0.7, 
                    label='数浓度', 
                    marker='o',
                    ms=1, 
                    mfc='k',
                    mec='k') 
    ax2.plot(data_fog['日期时间'],data_fog['液水含量(g/m^3)'],c='k',ls='-',lw=1,alpha=0.7,marker='o',ms=1,mfc='k',mec='k')
    ax3.plot(data_fog['日期时间'],data_fog['平均半径(μm)'],c='k',ls='-',lw=1,alpha=0.7,marker='o',ms=1,mfc='k',mec='k')
    ax4.plot(data_fog['日期时间'],data_fog['有效半径(μm)'],c='k',ls='-',lw=1,alpha=0.7,marker='o',ms=1,mfc='k',mec='k') 
    ax5.plot(data_fog['日期时间'],data_fog['谱宽(μm)'],c='k',ls='-',lw=1,alpha=0.7,marker='o',ms=1,mfc='k',mec='k')
    ax6.plot(data_fog['日期时间'],data_fog['散度'],c='k',ls='-',lw=1,alpha=0.7,marker='o',ms=1,mfc='k',mec='k')
    ax1.grid(True, 
            linestyle=":",
            linewidth=1, 
            alpha=0.5) 
    ax2.grid(True,linestyle=":",linewidth=1,alpha=0.5) 
    ax3.grid(True,linestyle=":",linewidth=1,alpha=0.5) 
    ax4.grid(True,linestyle=":",linewidth=1,alpha=0.5) 
    ax5.grid(True,linestyle=":",linewidth=1,alpha=0.5) 
    ax6.grid(True,linestyle=":",linewidth=1,alpha=0.5) 
    ax1.set_ylabel('数浓度(个/cm$^{3}$)',fontsize=10) 
    ax2.set_ylabel('液水含量(g/m$^{3}$)',fontsize=10) 
    ax3.set_ylabel('平均半径(μm)',fontsize=10) 
    ax4.set_ylabel('有效半径(μm)',fontsize=10) 
    ax5.set_ylabel('谱宽(μm)',fontsize=10) 
    ax6.set_ylabel('散度',fontsize=10) 
    ax6.xaxis.set_major_formatter(mdate.DateFormatter('%H:%M'))
    ax6.set_xlabel('时间',fontsize=10) 
    fig.savefig('图15.5_微物理参量时间序列图.png',
                dpi = 300,
                bbox_inches='tight',pad_inches=0.1) 
    print('微物理量时间序列图绘制完毕！！！')
    plt.close()         
    return()

if __name__ == '__main__': 
    fog_file = '雾滴谱.csv'  

    Xmin='2019-04-24 00:00:00' 
    Xmax='2019-04-25 00:00:00'      
    data_fog=load_data_select_to_dnddp(fog_file,Xmin,Xmax)    
    data_result=cal_para(data_fog)
    plot_para(data_result) 
end = time.clock() 
print('>>> Total running time: %s Seconds'%(end-start))