#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@毕凯，北京市人工影响天气办公室
@ email: bikai_picard@vip.sina.com 
"""
import os 
os.chdir("E:\\BIKAI_books\\data\\chap15")
os.getcwd() 
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.dates as mdate
import matplotlib
matplotlib.rcParams['font.sans-serif']=['FangSong'] 
matplotlib.rcParams['axes.unicode_minus']=False 
import time
start =time.clock()
def load_data(fog_file): 
    data_fog = pd.read_csv(fog_file,
                           header=0,engine='python',
                           encoding='gbk')
    data_fog['date_time']=pd.to_datetime(data_fog['date_time'],format='%Y-%m-%d %H:%M:%S') 
    return(data_fog)
def fog_nc_plot(data_fog):
    fig,ax = plt.subplots()
    fig.set_size_inches(10,5)
    ax.plot(data_fog['date_time'], 
            data_fog['Number Conc (#/cm^3)'],
                    c='k', 
                    ls='-',
                    lw=1,
                    alpha=0.7, 
                    marker='o', 
                    ms=1,
                    mfc='k',
                    mec='k') 
    ax.grid(True,
            linestyle=":",
            linewidth=1,
            alpha=0.5)

    ax.xaxis.set_major_formatter(mdate.DateFormatter('%m/%d %H:%M'))
    ax.set_xlabel('时间',fontsize=15) 
    ax.set_ylabel('数浓度(个/cm$^{3}$)',fontsize=15)
    fig.savefig('图15.1_雾滴数浓度时间序列图.eps',
                dpi = 300,
                bbox_inches='tight',pad_inches=0.1) 
    plt.close() 
    return()

if __name__ == '__main__': 
    fog_file = '雾滴谱.csv' 
    data_fog=load_data(fog_file)
    fog_nc_plot(data_fog)
print('图15.1_雾滴数浓度时间序列图  绘制完毕！！！')
end = time.clock()
print('>>> Total running time: %s Seconds'%(end-start))