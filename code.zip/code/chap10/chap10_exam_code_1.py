#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@毕凯，北京市人工影响天气办公室
@ email: bikai_picard@vip.sina.com 
"""
import os
os.chdir("E:\\BIKAI_books\\data\\chap10") 
os.getcwd()
import pandas as pd 
import glob2
import time
start =time.clock() 
batch_aps_filenames = '2018*.txt'
file_aps_names = glob2.glob(batch_aps_filenames) 
print(file_aps_names)
data_aps= pd.DataFrame()
for i in range(len(file_aps_names)): 
    data_aps_single=pd.read_table(file_aps_names[i],
                                  sep='\t',
                                  header=None,
                                  skiprows=7)
    data_aps= pd.concat([data_aps,data_aps_single],ignore_index=True)
data_aps.columns=['Sample','Date','Start Time','Aerodynamic Diameter','0.3','0.542','0.583','0.626','0.673','0.723','0.777','0.835','0.898','0.965','1.037','1.114','1.197','1.286','1.382','1.486','1.596','1.715','1.843','1.981','2.129','2.288','2.458','2.642','2.839','3.051','3.278','3.523','3.786','4.068','4.371','4.698','5.048','5.425','5.829','6.264','6.732','7.234','7.774','8.354','8.977','9.647','10.37','11.14','11.97','12.86','13.82','14.86','15.96','17.15','18.43','19.81','Event 1','Event 3','Event 4','Dead Time','Inlet Pressure','Total Flow','Sheath Flow','Analog Input Voltage 0','Analog Input Voltage 1','Digital Input Level 0','Digital Input Level 1','Digital Input Level 2','Laser Power','Laser Current','Sheath Pump Voltage','Total Pump Voltage','Box Temperature','Avalanch Photo Diode Temperature','Avalanch Photo Diode Voltage','Status Flags','Median(µm)','Mean(µm)','Geo. Mean(µm)','Mode(µm)','Geo. Std. Dev.','Total Conc.']
data_aps['Date'] = pd.to_datetime(data_aps['Date']) 
data_aps['Start Time'] = pd.to_timedelta(data_aps['Start Time'])  
data_aps['date_time']=data_aps['Date'] +pd.to_timedelta(data_aps['Start Time'].astype(str))
data_aps['date_time'] = pd.to_datetime(data_aps['date_time'],format='%Y-%m-%d %H:%M:%S')

data_aps=data_aps.sort_values(by='date_time')
data_aps.to_csv('result_2018aps_combine.csv', index=False)

end = time.clock() 
print('>>> Total running time: %s Seconds'%(end-start))