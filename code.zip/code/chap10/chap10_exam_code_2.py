#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@毕凯，北京市人工影响天气办公室
@ email: bikai_picard@vip.sina.com 
"""
import os 
os.chdir("E:\\BIKAI_books\\data\\chap10") 
os.getcwd()
import pandas as pd 
import matplotlib
matplotlib.rcParams['font.sans-serif']=['FangSong'] 
matplotlib.rcParams['axes.unicode_minus']=False  
import matplotlib.pyplot as plt 
import matplotlib.dates as mdate
import datetime as dt
import time 
start =time.clock()

def read_cal_n500(file_aps):   
    data_aps = pd.read_csv(file_aps,header=0) 
    data_aps['date_time'] = pd.to_datetime(data_aps['date_time'],
            format='%Y-%m-%d %H:%M:%S')
    headerpsd=['0.3','0.542','0.583','0.626','0.673','0.723','0.777','0.835','0.898','0.965','1.037','1.114','1.197','1.286','1.382','1.486','1.596','1.715','1.843','1.981','2.129','2.288','2.458','2.642','2.839','3.051','3.278','3.523','3.786','4.068','4.371','4.698','5.048','5.425','5.829','6.264','6.732','7.234','7.774','8.354','8.977','9.647','10.37','11.14','11.97','12.86','13.82','14.86','15.96','17.15','18.43','19.81'] 
    data_aps_dn_psd = pd.DataFrame()
    for i in headerpsd:
        data_aps_dn_psd[i]=data_aps[i]
    data_aps_dn_psd = data_aps_dn_psd.set_index(data_aps['date_time'])
    data_aps_n_psd = pd.DataFrame()
    data_aps_n_psd = data_aps_dn_psd*0.03125 
    data_aps_n_psd['0.3']=data_aps_dn_psd['0.3']*0.25
    data_aps_total_con = pd.Series() 
    col_list= list(data_aps_n_psd) 
    col_list.remove('0.3') 
    data_aps_total_con = data_aps_n_psd[col_list].sum(axis=1)
    return(data_aps_total_con)

def plot_aps_n500(data_aps_total_con):
    fig,ax = plt.subplots()
    fig.set_size_inches(10,6)
    data_aps = pd.DataFrame()
    data_aps['date_time']=data_aps_total_con.index 

    ax.plot(data_aps_total_con.index, 
             data_aps_total_con,
             color='k',
             linestyle='', 
             marker='o',
             alpha=0.9,
             ms=4, 
             mec='k',
             mfc='w') 
				
    ax.grid(True,
             linestyle=":",
             linewidth=1,
             alpha=0.5)
				
    ax.set_xlabel('日期时间')
    ax.set_ylabel('数浓度 (个/$cm^3$)')
    ax.xaxis.set_major_formatter(mdate.DateFormatter('%m/%d')) 
    ax.set_xticks(pd.date_range(data_aps['date_time'][0] - dt.timedelta(hours=data_aps['date_time'][0].hour, minutes=data_aps['date_time'][0].minute, seconds=data_aps['date_time'][0].second,microseconds=data_aps['date_time'][0].microsecond),data_aps['date_time'].iloc[-1],freq='2d')) 
    fig.savefig('图10.1_气溶胶数浓度时间序列图.png',
                dpi = 300,
                bbox_inches='tight',pad_inches=0.1)
    plt.close()
    return()
    
if __name__ == '__main__':
    file_aps = 'result_2018aps_combine.csv' 
    data_aps=read_cal_n500(file_aps) 
    plot_aps_n500(data_aps) 
    
end = time.clock() 
print('>>> Total running time: %s Seconds'%(end-start))