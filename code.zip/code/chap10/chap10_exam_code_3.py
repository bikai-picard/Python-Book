#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@毕凯，北京市人工影响天气办公室
@ email: bikai_picard@vip.sina.com 
"""
import os
os.chdir("E:\\BIKAI_books\\data\\chap10")
os.getcwd() 
import pandas as pd 
import numpy as np 
from numpy import ma 
import matplotlib.colors as clr
import math
import matplotlib
matplotlib.rcParams['font.sans-serif']=['FangSong']
matplotlib.rcParams['axes.unicode_minus']=False  
matplotlib.rcParams.update({'text.usetex': False,'mathtext.fontset': 'cm',})
import matplotlib.pyplot as plt 
import matplotlib.dates as mdate
import time 
start =time.clock()
def cbar_ticks(start,end):
    cbar_lib_list=[0.00000000001,0.0000000001,0.000000001,0.00000001,0.0000001,0.000001,0.00001,0.0001,0.001,0.01,0.1,1,10,100,1000,10000,100000,1000000,10000000] 
    id_start=[]
    id_end=[]
    
    for i in range(len(cbar_lib_list)):
        if  cbar_lib_list[i]<= start:
            id_start=i
        if cbar_lib_list[i]<=end :
            id_end=i+1
    result_start=id_start
    result_end=id_end
    cbar_list=cbar_lib_list[result_start:result_end+1]
    return(cbar_list)
    
def aps_read_cal__dn_ds_dm_psd(file_aps):
    data_aps = pd.read_csv(file_aps,header=0)
    data_aps.columns=['Sample','Date','Start Time','Aerodynamic Diameter','0.3','0.542','0.583','0.626','0.673','0.723','0.777','0.835','0.898','0.965','1.037','1.114','1.197','1.286','1.382','1.486','1.596','1.715','1.843','1.981','2.129','2.288','2.458','2.642','2.839','3.051','3.278','3.523','3.786','4.068','4.371','4.698','5.048','5.425','5.829','6.264','6.732','7.234','7.774','8.354','8.977','9.647','10.37','11.14','11.97','12.86','13.82','14.86','15.96','17.15','18.43','19.81','Event 1','Event 3','Event 4','Dead Time','Inlet Pressure','Total Flow','Sheath Flow','Analog Input Voltage 0','Analog Input Voltage 1','Digital Input Level 0','Digital Input Level 1','Digital Input Level 2','Laser Power','Laser Current','Sheath Pump Voltage','Total Pump Voltage','Box Temperature','Avalanch Photo Diode Temperature','Avalanch Photo Diode Voltage','Status Flags','Median(µm)','Mean(µm)','Geo. Mean(µm)','Mode(µm)','Geo. Std. Dev.','Total Conc.','date_time']
        
    data_aps['date_time'] = pd.to_datetime(data_aps['date_time'],format='%Y-%m-%d %H:%M:%S')
    headerpsd=['0.542','0.583','0.626','0.673','0.723','0.777','0.835','0.898','0.965','1.037','1.114','1.197','1.286','1.382','1.486','1.596','1.715','1.843','1.981','2.129','2.288','2.458','2.642','2.839','3.051','3.278','3.523','3.786','4.068','4.371','4.698','5.048','5.425','5.829','6.264','6.732','7.234','7.774','8.354','8.977','9.647','10.37','11.14','11.97','12.86','13.82','14.86','15.96','17.15','18.43','19.81'] 
    data_aps_dn_dlogdp = pd.DataFrame()
    for i in headerpsd:
        data_aps_dn_dlogdp[i]=data_aps[i]
    data_aps_dn_dlogdp = data_aps_dn_dlogdp.set_index(data_aps['date_time'])
    data_aps_ds_psd = pd.DataFrame()
    for j in headerpsd:
        data_aps_ds_psd[j]=data_aps_dn_dlogdp[j]*math.pi*float(j)**2
    data_aps_ds_psd = data_aps_ds_psd.set_index(data_aps['date_time'])
    data_aps_dm_psd = pd.DataFrame()
    for k in headerpsd:
        data_aps_dm_psd[k]=data_aps_dn_dlogdp[k]*(math.pi/6)*float(k)**3*0.001 
    data_aps_dm_psd = data_aps_dm_psd.set_index(data_aps['date_time'])
    return(data_aps_dn_dlogdp,data_aps_ds_psd,data_aps_dm_psd)
    
def plot_dn_ds_dm_psd_timeseries(data_aps_dn_dlogdp,data_aps_ds_dlogdp,data_aps_dm_dlogdp):
    fig,(ax1,ax2,ax3) = plt.subplots(3,1,sharex=True) 
    fig.set_size_inches(12,8)
    x_aps_dn = data_aps_dn_dlogdp.index.tolist()
    y_aps_dn = [float(x) for x in     data_aps_dn_dlogdp.columns.tolist()]
    X_aps_dn,Y_aps_dn = np.meshgrid(x_aps_dn,y_aps_dn)
    z_aps_dn_tem =  data_aps_dn_dlogdp.values 
    z_aps_dn_tem=ma.masked_where(z_aps_dn_tem <= 0, z_aps_dn_tem)
    start_list_dn=z_aps_dn_tem.min()
    end_list_dn=z_aps_dn_tem.max() 
    cbar_ticks_list_dn=cbar_ticks(start_list_dn,end_list_dn)
    gap_ax_dn = np.logspace(math.log10(start_list_dn),math.log10(end_list_dn),30,endpoint=True)
    z_aps_dn = data_aps_dn_dlogdp
    Z_aps_dn = z_aps_dn.T 
    for ii in range(len(x_aps_dn)-1):
        if (x_aps_dn[ii+1]-x_aps_dn[ii]).seconds>1200 :
            z_aps_dn.loc[x_aps_dn[ii]:x_aps_dn[ii+1],:]= np.nan  
    print('>>> Hi, X,Y,Z for aps dn plot psd  is finished!    done!!!')
    im_aps_dn = ax1.contourf(X_aps_dn,Y_aps_dn,Z_aps_dn,gap_ax_dn,norm=clr.LogNorm(),cmap='jet',origin='lower')
    ax1.yaxis.grid(False)
    ax1.set_ylabel('尺度(μm)')
    ax1.set_yscale('log')
    ax1.tick_params(labelsize=12) 
    fig.subplots_adjust(left=0.07, right=0.87)
    box_aps_dn = ax1.get_position()
    pad, width = 0.01, 0.01 
    cax_aps_dn = fig.add_axes([box_aps_dn.xmax + pad, box_aps_dn.ymin, width, box_aps_dn.height])
    cbar_aps_dn = fig.colorbar(im_aps_dn,cax=cax_aps_dn,ticks=cbar_ticks_list_dn,extend='max')
    cbar_aps_dn.set_label('数浓度(个/cm${^3}$)')
    cbar_aps_dn.ax.tick_params(labelsize=10)

    x_aps_ds = data_aps_ds_dlogdp.index.tolist()
    y_aps_ds = [float(x) for x in     data_aps_ds_dlogdp.columns.tolist()]
    X_aps_ds,Y_aps_ds = np.meshgrid(x_aps_ds,y_aps_ds)
    z_aps_ds_tem =  data_aps_ds_dlogdp.values 
    z_aps_ds_tem=ma.masked_where(z_aps_ds_tem <= 0, z_aps_ds_tem)
    start_list_ds=z_aps_ds_tem.min()
    end_list_ds=z_aps_ds_tem.max() 
    cbar_ticks_list_ds=cbar_ticks(start_list_ds,end_list_ds)
    gap_ax_ds = np.logspace(math.log10(start_list_ds),math.log10(end_list_ds),30,endpoint=True) 
    z_aps_ds = data_aps_ds_dlogdp
    Z_aps_ds = z_aps_ds.T 
    for ii in range(len(x_aps_ds)-1):
        if (x_aps_ds[ii+1]-x_aps_ds[ii]).seconds>1200 :
            z_aps_ds.loc[x_aps_ds[ii]:x_aps_ds[ii+1],:]= np.nan  
    print('>>> Hi, X,Y,Z for aps ds plot psd  is finished!    done!!!')
    im_aps_ds = ax2.contourf(X_aps_ds,Y_aps_ds,Z_aps_ds,gap_ax_ds,norm=clr.LogNorm(),cmap='jet',origin='lower')
    ax2.yaxis.grid(False)
    ax2.set_ylabel('尺度(μm)')
    ax2.set_yscale('log')
    ax2.tick_params(labelsize=12)
    fig.subplots_adjust(left=0.07, right=0.87)
    box_aps_ds = ax2.get_position()
    pad, width = 0.01, 0.01
    cax_aps_ds = fig.add_axes([box_aps_ds.xmax + pad, box_aps_ds.ymin, width, box_aps_ds.height]) 
    cbar_aps_ds = fig.colorbar(im_aps_ds,cax=cax_aps_ds,ticks=cbar_ticks_list_ds,extend='max') 
    cbar_aps_ds.set_label('表面积浓度($μm^2$/$cm^3$)')
    cbar_aps_ds.ax.tick_params(labelsize=10)

    x_aps_dm = data_aps_dm_dlogdp.index.tolist() 
    y_aps_dm = [float(x) for x in     data_aps_dm_dlogdp.columns.tolist()]
    X_aps_dm,Y_aps_dm = np.meshgrid(x_aps_dm,y_aps_dm)
    z_aps_dm_tem =  data_aps_dm_dlogdp.values 
    z_aps_dm_tem=ma.masked_where(z_aps_dm_tem <= 0, z_aps_dm_tem) 
    start_list_dm=z_aps_dm_tem.min()
    end_list_dm=z_aps_dm_tem.max()
    cbar_ticks_list_dm=cbar_ticks(start_list_dm,end_list_dm) 
    gap_ax_dm = np.logspace(math.log10(start_list_dm),math.log10(end_list_dm),30,endpoint=True)
    z_aps_dm = data_aps_dm_dlogdp
    Z_aps_dm = z_aps_dm.T
    for ii in range(len(x_aps_dm)-1):
        if (x_aps_dm[ii+1]-x_aps_dm[ii]).seconds>1200 :
            z_aps_dm.loc[x_aps_dm[ii]:x_aps_dm[ii+1],:]= np.nan  
    print('>>> Hi, X,Y,Z for aps dm plot psd  is finished!    done!!!') 
    
    im_aps_dm = ax3.contourf(X_aps_dm,Y_aps_dm,Z_aps_dm,gap_ax_dm,norm=clr.LogNorm(),cmap='jet',origin='lower')
    ax3.yaxis.grid(False)
    ax3.set_ylabel('尺度(μm)')
    ax3.set_yscale('log') 
    ax3.tick_params(labelsize=12)
    fig.subplots_adjust(left=0.07, right=0.87)
    box_aps_dm = ax3.get_position()
    pad, width = 0.01, 0.01 
    cax_aps_dm = fig.add_axes([box_aps_dm.xmax + pad, box_aps_dm.ymin, width, box_aps_dm.height]) 
    cbar_aps_dm = fig.colorbar(im_aps_dm,cax=cax_aps_dm,ticks=cbar_ticks_list_dm,extend='max') 
    cbar_aps_dm.set_label('质量浓度(mg/$m^3$)')
    cbar_aps_dm.ax.tick_params(labelsize=10) 
    
    ax3.xaxis.set_major_formatter(mdate.DateFormatter('%m/%d')) 
    ax3.set_xlabel('时间',fontsize=15) 
    fig.savefig('图10.2_APS气溶胶粒子谱时间序列图.pdf', 
                dpi = 300, 
                bbox_inches=None, pad_inches=1.5)
    plt.close()  
    return()

def plot_psd_mean(data_aps_dn_dlogdp,data_aps_ds_dlogdp,data_aps_dm_dlogdp,time_list,color_c):
    fig,(ax1,ax2,ax3) = plt.subplots(1,3,sharex=True)
    fig.set_size_inches(15,6)
    x_aps_dn = [float(x) for x in     data_aps_dn_dlogdp.columns.tolist()] 
    data_aps_mean_dn = pd.DataFrame() 
    for i in range(len(time_list)):  
        data_aps_mean_dn= data_aps_dn_dlogdp.loc[time_list[i][0]:time_list[i][1],:].mean() 
        df_ave_dNdDp = pd.DataFrame() 
        df_ave_dNdDp['dp']=x_aps_dn
        df_ave_dNdDp['dN']=data_aps_mean_dn.T.values  
								
        ax1.plot(df_ave_dNdDp['dp'],df_ave_dNdDp['dN'],color=color_c[i],label=time_list[i][0]+'-'+time_list[i][1],linestyle='-',lw=1,alpha=1,marker='o',ms=4,mec=color_c[i],mfc=color_c[i])  
        ax1.set_xlabel('尺度(μm)',fontsize=15) 
        ax1.set_ylabel('数浓度(个/cm${^3}$)',fontsize=15)
        ax1.set_yscale('log') 
        ax1.set_xscale('log') 
        ax1.grid(True,linestyle=":",linewidth=1,alpha=0.5)
        ax1.set_xlim(0.35, 25)
        ax1.legend(loc ='best',fontsize=6)
        ax1.tick_params(labelsize=15) 
    x_aps_ds = [float(x) for x in     data_aps_ds_dlogdp.columns.tolist()]   
    data_aps_mean_ds = pd.DataFrame()   
    for i in range(len(time_list)):    
        data_aps_mean_ds= data_aps_ds_dlogdp.loc[time_list[i][0]:time_list[i][1],:].mean()    
        df_ave_dsdDp = pd.DataFrame() 
        df_ave_dsdDp['dp']=x_aps_ds
        df_ave_dsdDp['dN']=data_aps_mean_ds.T.values 
								
        ax2.plot(df_ave_dsdDp['dp'],df_ave_dsdDp['dN'],color=color_c[i],label=time_list[i][0]+'-'+time_list[i][1],linestyle='-',lw=1,alpha=1,marker='o',ms=4,mec=color_c[i],mfc=color_c[i])   
        ax2.set_xlabel('尺度(μm)',fontsize=15)
        ax2.set_ylabel('表面积浓度($μm^2$/$cm^3$)',fontsize=15)
        ax2.set_yscale('log')
        ax2.set_xscale('log') 
        ax2.grid(True,linestyle=":",linewidth=1,alpha=0.5)
        ax2.set_xlim(0.35, 25)
        ax2.legend(loc ='best',fontsize=6)  
        ax2.tick_params(labelsize=15) 
    x_aps_dm = [float(x) for x in     data_aps_dm_dlogdp.columns.tolist()] 
    data_aps_mean_dm = pd.DataFrame() 
    for i in range(len(time_list)):     
        data_aps_mean_dm= data_aps_dm_dlogdp.loc[time_list[i][0]:time_list[i][1],:].mean()   
								
        df_ave_dmdDp = pd.DataFrame()
        df_ave_dmdDp['dp']=x_aps_dm
        df_ave_dmdDp['dN']=data_aps_mean_dm.T.values 
								
        ax3.plot(df_ave_dmdDp['dp'],df_ave_dmdDp['dN'],color=color_c[i],label=time_list[i][0]+'-'+time_list[i][1],linestyle='-',lw=1,alpha=1,marker='o',ms=4,mec=color_c[i],mfc=color_c[i])    
        ax3.set_xlabel('尺度(μm)',fontsize=15)
        ax3.set_ylabel('质量浓度(mg/$m^3$)',fontsize=15)
        ax3.set_yscale('log') 
        ax3.set_xscale('log')
        ax3.grid(True,linestyle=":",linewidth=1,alpha=0.5)
        ax3.set_xlim(0.35, 25)
        ax3.legend(loc ='best',fontsize=6)
        ax3.tick_params(labelsize=15) 
    fig.subplots_adjust(wspace=0.3)            
    fig.savefig('图10.3_APS浓度平均谱.pdf',
                dpi = 300, 
                bbox_inches='tight', pad_inches=0.1) 
    plt.close()    
    return()

if __name__ == '__main__': 
    file_aps = 'result_2018aps_combine.csv' 
    data_aps_dn_psd,data_aps_ds_psd,data_aps_dm_psd=aps_read_cal__dn_ds_dm_psd(file_aps)
    plot_dn_ds_dm_psd_timeseries(data_aps_dn_psd,data_aps_ds_psd,data_aps_dm_psd)
    time_list=[['2018-05-16 00:00:00','2018-05-16 12:00:00'],
               ['2018-05-18 00:00:00','2018-05-18 12:00:00'],
               ['2018-05-22 20:00:00','2018-05-23 08:00:00']]	
    color_list=['g','r','b',]
    plot_psd_mean(data_aps_dn_psd,data_aps_ds_psd,data_aps_dm_psd,time_list,color_list)
end = time.clock() 
print('>>> Total running time: %s Seconds'%(end-start))



