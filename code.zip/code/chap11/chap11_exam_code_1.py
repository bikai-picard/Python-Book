#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@毕凯，北京市人工影响天气办公室
@ email: bikai_picard@vip.sina.com 
"""
import os
os.environ['PROJ_LIB'] = 'D:\\anaconda3\\Library\\share' 
os.chdir("E:\\BIKAI_books\\data\\chap11") 
os.getcwd()
from wrf import getvar 
from netCDF4 import Dataset 
import pandas as pd
import matplotlib.pyplot as plt 
from mpl_toolkits.basemap import Basemap
from matplotlib import ticker
import numpy as np
import math 
import subprocess
import matplotlib.colors as colors 
import matplotlib
matplotlib.rcParams['font.sans-serif']=['FangSong'] 
matplotlib.rcParams['axes.unicode_minus']=False  
from collections import OrderedDict
cmaps = OrderedDict() 
import time 
start =time.clock() 

def colormap():
    cdict = [(1,1,1),
             (0,1,1),
             (0,157/255,1),
             (0,0,1),
             (9/255,130/255,175/255),
             (0,1,0),
             (8/255,175/255,20/255),
             (1,214/255,0),
             (1,152/255,0),
             (1,0,0), 
             (221/255,0,27/255),
             (188/255,0,54/255), 
             (121/255,0,109/255), 
             (121/255, 51/255,160/255),
             (195/255,163/255,212/255), 
             ]
    return colors.ListedColormap(cdict, 'indexed')

def plot_basemap(ax1):
    m = Basemap(projection='cyl', 
                llcrnrlon=lon.min(), 
                urcrnrlon=lon.max(), 
                llcrnrlat=lat.min(), 
                urcrnrlat=lat.max(),
                ax=ax1, 
                resolution='c')
    m.readshapefile('shp_for_basemap/bou2_4p',
                    'bou2_4p',
                    color='k',
                    linewidth=2) 
    m.drawparallels(np.arange(math.ceil(lat.min()),
                              math.ceil(lat.max()),1),
                    labels=[1, 0, 0, 0],
                    linewidth=0.0,
                    fontsize=15) 
    m.drawmeridians(np.arange(math.ceil(lon.min()),
                              math.ceil(lon.max()), 1),
                    labels=[0, 0, 0, 1],
                    linewidth=0.0,
                    fontsize=15)
    ax1.set_yticks(np.arange(math.ceil(lat.min()),lat.max(),1))
    ax1.yaxis.set_major_formatter(ticker.FormatStrFormatter('%2.1f'))
    ax1.set_yticklabels([])
    ax1.set_xticks(np.arange(math.ceil(lon.min()),lon.max(), 1))
    ax1.set_xticklabels([])
    ax1.xaxis.set_ticks_position("bottom") 
    return(m) 

def make_gif(gif_name):
    batch_input='dbz_rainfall_%02d.png'
    file_output=gif_name+'.gif' 
    alive=os.path.exists(file_output)   
    if alive==0:
        pass
    else:
        os.unlink(file_output)

    fps=2
    shell_input = ['D:\\ffmpeg-20200626-7447045-win64-static\\bin\\ffmpeg', 
               '-r',
               str(fps),
               '-i',
               batch_input, 
               file_output]
    gif=subprocess.Popen(args=shell_input,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,universal_newlines=True)
    if gif.wait()==0:
        print('--------------------------')
        print('make gif file done!!!')
        print('--------------------------')
    else:
        print('--------------------------')
        print('can not make gif !!!')
        print('--------------------------')
    
    for filename in os.listdir():
        if filename.startswith('dbz') and filename.endswith('.png'): 
            os.unlink(filename)    
    return()
  
def plot_nc(ax1,m,z,i,gap_ax,gap_cb,cmap,cbar_name):
    im=m.contourf(X,Y,z,
                  gap_ax,
                  cmap=cmap,
                  extend='both') 
    fig.subplots_adjust(left=0.07,right=0.87)
    box= ax1.get_position()
    pad, height = 0.1, 0.04 
    cax = fig.add_axes([box.xmin,box.ymin-pad,box.width,height])
    cbar = fig.colorbar(im,cax=cax,ticks=gap_cb,extend='both',orientation='horizontal') 
    cbar.set_label(cbar_name,fontsize=20)
    return()
    
if __name__ == '__main__':
    
    filename='chap11_WRF.nc'
    var_name='mdbz' 
    var_name_1='RAINC'
    var_name_2='RAINNC' 
    ncfile = Dataset(filename) 
    time_nc = [str(i, encoding = "utf-8") for i in ncfile.variables['Times']]  
    time_nc =pd.to_datetime(pd.Series(time_nc),format = '%Y-%m-%d_%H:%M:%S')
    lat=ncfile.variables['XLAT'][0,:,0]
    lon=ncfile.variables['XLONG'][0,0,:]
    x=lon.tolist() 
    y=lat.tolist()
    X,Y = np.meshgrid(x,y) 
    for i in range(len(time_nc)):		
        time_name= str(time_nc[i])
        time_name_1= str(time_nc[i])[0:4]+str(time_nc[i])[5:7]+str(time_nc[i])[8:10]+'_'+str(time_nc[i])[11:13]+str(time_nc[i])[14:16]+str(time_nc[i])[17:19]
        var_nc = getvar(ncfile,var_name,timeidx=i)
        var_nc_rain_1 = getvar(ncfile,var_name_1,timeidx=i) 
        var_nc_rain_2 = getvar(ncfile,var_name_2,timeidx=i)
        var_nc_1=var_nc_rain_1+var_nc_rain_2
        
        if i==0:
            var_nc_2=var_nc_1
        else:
            var_nc_rain_1_2 = getvar(ncfile,var_name_1,timeidx=i-1)
            var_nc_rain_2_2 = getvar(ncfile,var_name_2,timeidx=i-1)
            var_nc_2=var_nc_1-(var_nc_rain_1_2+var_nc_rain_2_2)
        fig,(ax1,ax2,ax3) = plt.subplots(1,3,sharex=True)
        fig.set_size_inches(21,6)
        fig.suptitle(str(time_nc[i]),fontsize=30,y=0.9)
        m1=plot_basemap(ax1)
        m2=plot_basemap(ax2) 
        m3=plot_basemap(ax3) 
        gap_ax = np.arange(-5,75,5)
        gap_cb= np.arange(-5,75,5)
        plot_nc(ax1,
                m1,
                var_nc,
                i,
                gap_ax,
                gap_cb,
                colormap(),
                'dBZ') 
        ax1.set_title('最大雷达回波反射率',fontsize=20)
        gap_ax_1 = np.arange(0,2,0.1)
        gap_cb_1= np.arange(0,2,0.2)     
        plot_nc(ax2,
                m2,
                var_nc_2,
                i,
                gap_ax_1,
                gap_cb_1,
                'YlGn',
                'mm')
        ax2.set_title('当前时刻降水',fontsize=20)
        gap_ax_2 = np.arange(0,2,0.1) 
        gap_cb_2= np.arange(0,2,0.2)
        plot_nc(ax3,
                m3,
                var_nc_1,
                i,
                gap_ax_2,
                gap_cb_2,
                'YlGn',
                'mm')
        ax3.set_title('累积降水量',fontsize=20)
        plt.savefig('radar_rainfall_'+time_name_1,
                    dpi = 300,bbox_inches='tight',
                    pad_inches=0.1) 
        plt.savefig('dbz_rainfall_%02d'%i,
                    dpi = 300, bbox_inches='tight', 
                    pad_inches=0.1) 
        plt.close()
        print('plotted '+time_name+'. Done '+str(int((i+1)/len(time_nc)*100))+' %')

    gif_name='fig11_radar_rainfall'+time_nc[0].strftime('%Y-%m-%d %H:%M:%S')[0:4]+time_nc[0].strftime('%Y-%m-%d %H:%M:%S')[5:7]+time_nc[0].strftime('%Y-%m-%d %H:%M:%S')[8:10]
    make_gif(gif_name) 

end = time.clock() 
print('>>> Total running time: %s Seconds'%(end-start))

