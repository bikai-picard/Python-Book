#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@毕凯，北京市人工影响天气办公室
@ email: bikai_picard@vip.sina.com 
"""
import os
os.environ['PROJ_LIB'] = 'D:\\anaconda\\Library\\share'
os.chdir("E:\\BIKAI_books\\data\\chap11")
os.getcwd()
from wrf import getvar,to_np,latlon_coords,vertcross,interpline, CoordPair 
from netCDF4 import Dataset 
import xarray as xr 
import pandas as pd 
import matplotlib.pyplot as plt
from mpl_toolkits.basemap import Basemap 
import numpy as np 
import math 
import matplotlib.colors as colors 
import matplotlib
matplotlib.rcParams['font.sans-serif']=['FangSong']
matplotlib.rcParams['axes.unicode_minus']=False  
from collections import OrderedDict
cmaps = OrderedDict()
import time
start =time.clock() 

def colormap():
    cdict = [(1,1,1),
             (0,1,1),
             (0,157/255,1),
             (0,0,1),
             (9/255,130/255,175/255),
             (0,1,0),
             (8/255,175/255,20/255),
             (1,214/255,0),
             (1,152/255,0),
             (1,0,0), 
             (221/255,0,27/255),
             (188/255,0,54/255), 
             (121/255,0,109/255), 
             (121/255, 51/255,160/255),
             (195/255,163/255,212/255), 
             ]
    return colors.ListedColormap(cdict, 'indexed')

def plot_basemap(lon,lat,z,var,ax1):
    x=lon.tolist()
    y=lat.tolist()
    X,Y = np.meshgrid(x,y)
    m = Basemap(projection='cyl',
                llcrnrlon=lon.min(), 
                urcrnrlon=lon.max(), 
                llcrnrlat=lat.min(),
                urcrnrlat=lat.max(), 
                ax=ax1, 
                resolution='c')
    m.readshapefile('shp_for_basemap/bou2_4p','bou2_4p',
                    color='k',linewidth=2)
    m.drawparallels(np.arange(math.ceil(lat.min()),math.ceil(lat.max()),1),labels=[1, 0, 0, 0],linewidth=0.0,fontsize=15)
    m.drawmeridians(np.arange(math.ceil(lon.min()), math.ceil(lon.max()), 1),labels=[0, 0, 0, 1],linewidth=0.0,fontsize=15) 
    ax1.set_yticks(np.arange(math.ceil(lat.min()),lat.max(),1))
    ax1.set_yticklabels([])
    ax1.set_xticks(np.arange(math.ceil(lon.min()),lon.max(),1))
    ax1.set_xticklabels([])
    ax1.xaxis.set_ticks_position("bottom")
    
    gap_ax = np.arange(-5,75,5)
    gap_cb= np.arange(-5,75,5) 
    
    im=m.contourf(X,Y,z,gap_ax,cmap=colormap())
    fig.subplots_adjust(left=0.07,right=0.87)
    box= ax1.get_position()
    pad, height = 0.1, 0.04
    cax = fig.add_axes([box.xmin,box.ymin-pad,box.width,height]) 
    cbar = fig.colorbar(im,cax=cax,ticks=gap_cb,extend='max',orientation='horizontal')
    cbar.set_label('(dBZ)',fontsize=20)  
    ax1.set_title('最大雷达回波反射率',fontsize=20)
    return(m)

if __name__ == '__main__':

    filename='chap11_WRF.nc'
    water_var=['QCLOUD','QGRAUP','QICE','QRAIN','QSNOW','QVAPOR']
    water_var_chn=['云水比质量浓度','霰比质量浓度','冰晶比质量浓度','雨水比质量浓度','雪晶比质量浓度','水汽混合比']
    water_var_qn=['QNICE','QNRAIN']
    water_var_qn_chn=['冰晶数浓度','雨滴数浓度']
    time_point= 1
    lat1,lon1=39.8,114.5 
    lat2,lon2= 39.8,115.5 
    ncfile = Dataset(filename) 
    ds = xr.open_dataset(filename) 

    time_nc = [str(i, encoding = "utf-8") for i in ncfile.variables['Times']]
    time_nc =pd.to_datetime(pd.Series(time_nc), format = '%Y-%m-%d_%H:%M:%S')
    time_name= str(time_nc[time_point]) 
    lat=ncfile.variables['XLAT'][0,:,0] 
    lon=ncfile.variables['XLONG'][0,0,:] 

    start_point = CoordPair(lat=lat1, lon=lon1) #
    end_point = CoordPair(lat=lat2, lon=lon2)

    var_nc = getvar(ncfile,'mdbz',timeidx=time_point) 
    ht = getvar(ncfile,"z",timeidx=time_point)
    ter = getvar(ncfile,"ter", timeidx=time_point)
    dbz = getvar(ncfile,"dbz",timeidx=time_point)
    temp = getvar(ncfile,"tc",timeidx=time_point)
    Z = 10**(dbz/10.)
    z_cross = vertcross(Z,ht,wrfin=ncfile,start_point=start_point,end_point=end_point,latlon=True,meta=True) 
    dbz_cross = 10.0 * np.log10(z_cross)
    dbz_cross_filled = np.ma.copy(to_np(dbz_cross))
    for i in range(dbz_cross_filled.shape[-1]):
        column_vals = dbz_cross_filled[:,i]
        first_idx = int(np.transpose((column_vals > -200).nonzero())[0])
        dbz_cross_filled[0:first_idx, i] = dbz_cross_filled[first_idx, i]
    temp_cross = vertcross(temp,ht, wrfin=ncfile,start_point=start_point,end_point=end_point,latlon=True,meta=True) 
    temp_cross_filled = np.ma.copy(to_np(temp_cross))        
    for i in range(temp_cross_filled.shape[-1]):
        column_vals = temp_cross_filled[:,i]
        first_idx = int(np.transpose((column_vals > -200).nonzero())[0])
        temp_cross_filled[0:first_idx, i] = temp_cross_filled[first_idx, i]        
        
    ter_line =  interpline(ter, wrfin=ncfile, start_point=start_point,end_point=end_point)
    fig,(ax1,ax2) = plt.subplots(1,2,sharex=True)
    fig.set_size_inches(17,5) 
    gap_ax = np.arange(-5,75,5)
    gap_cb= np.arange(-5,75,5)     
    m=plot_basemap(lon,lat,var_nc,'mdbz',ax1)
    point_x, point_y = m([start_point.lon, end_point.lon],
                         [start_point.lat, end_point.lat])
    m.plot(point_x,point_y,latlon=True,color="r",marker="o",alpha=1,lw=3,ls='--',zorder=3)
   
    xs = np.arange(0, dbz_cross.shape[-1], 1) 
    gap_temp= np.arange(-50,30,5)
    gap_temp_minus= np.arange(-50,0,5)
    gap_temp_p= np.arange(0,30,5)
    
    im=ax2.contourf(xs,to_np(dbz_cross.coords["vertical"]),to_np(dbz_cross_filled),gap_ax,cmap=colormap(),extend="both")
    im2=ax2.contour(xs,to_np(temp_cross.coords["vertical"]),to_np(temp_cross_filled),gap_temp_p,extend='both',linewidths=0.5,linestyles='solid',colors='k')
    ax2.clabel(im2,fontsize=12,inline=False)
    im3=ax2.contour(xs,to_np(temp_cross.coords["vertical"]),to_np(temp_cross_filled),gap_temp_minus,extend='both',linewidths=0.5,linestyles='dashed',colors='k')
    ax2.clabel(im3,fontsize=12,inline=False) 
    im4=ax2.contour(xs,to_np(temp_cross.coords["vertical"]),to_np(temp_cross_filled),[0],origin='lower',extend='both',linewidths=2,linestyles='solid', colors='k') 
    ax2.clabel(im3, fontsize=12, inline=False)

    ax2.fill_between(xs,0,to_np(ter_line),facecolor="k")   
    coord_pairs = to_np(dbz_cross.coords["xy_loc"])
    x_ticks = np.arange(coord_pairs.shape[0])
    x_labels = [pair.latlon_str() for pair in to_np(coord_pairs)]

    num_ticks = 4
    thin = int((len(x_ticks) / num_ticks) + .5)
    ax2.set_xticks(x_ticks[::thin])
    ax2.set_xticklabels(x_labels[::thin], rotation=45, fontsize=8,ha="right")
    ax2.set_ylim(0,12000)
    ax2.set_xlabel("纬度，经度",fontsize=15)
    ax2.set_ylabel("高度(m)",fontsize=15)
    ax2.set_title("反射率截面(dBZ)",fontsize=20)
    fig.savefig('图11.2_'+time_name[:4]+time_name[5:7]+time_name[8:10]+time_name[11:13]+time_name[14:16]+time_name[17:19]+'雷达反射率截面.pdf',dpi =300,bbox_inches='tight',pad_inches=0.1)
    plt.close()
 
    for ii in range(len(water_var)):        
        title_name_water=ncfile.variables[water_var[ii]].description
        cloud_var = ds[water_var[ii]][time_point,:]
        w_cross = vertcross(cloud_var,ht, wrfin=ncfile,start_point=start_point,end_point=end_point,latlon=True,meta=True)
        w_cross_filled = np.ma.copy(to_np(w_cross)) 
        for i in range(w_cross_filled.shape[-1]):
            column_vals = w_cross_filled[:,i]
            first_idx = int(np.transpose((column_vals > -200).nonzero())[0])
            w_cross_filled[0:first_idx, i] = w_cross_filled[first_idx, i] 
        w_cross_filled1   =   w_cross_filled*1000 
                                      
        fig2,ax3= plt.subplots()
        fig2.set_size_inches(8,6)
        gap_cb_3= np.linspace(0,to_np(w_cross_filled1).max(),10)
        im30=ax3.contourf(xs,to_np(w_cross.coords["vertical"]),to_np(w_cross_filled1),30,cmap='YlGn',)
        fig2.subplots_adjust(left=0.07, right=0.87)
        box= ax3.get_position()
        pad, width = 0.02, 0.02 
        cax = fig2.add_axes([box.xmax+pad,box.ymin, width,box.height])
        cbar = fig2.colorbar(im30,cax=cax,ticks=gap_cb_3,extend='max',orientation='vertical')
        cbar.set_label('g/kg',fontsize=20)
        im31=ax3.contour(xs,to_np(temp_cross.coords["vertical"]),to_np(temp_cross_filled),gap_temp_p,extend='both',linewidths=0.5,linestyles='solid',colors='k')
        ax3.clabel(im31, fontsize=12, inline=False)
        im32=ax3.contour(xs,to_np(temp_cross.coords["vertical"]),to_np(temp_cross_filled), gap_temp_minus,extend='both',linewidths=0.5,linestyles='dashed',olors='k')
        ax3.clabel(im32, fontsize=12, inline=False)
        im33=ax2.contour(xs,to_np(temp_cross.coords["vertical"]),to_np(temp_cross_filled),[0],origin='lower',extend='both',linewidths=2,linestyles='solid', colors='k') 
        ax3.clabel(im33, fontsize=12, inline=False)
        ax3.fill_between(xs,0,to_np(ter_line),facecolor="k")
        ax3.set_xticks(x_ticks[::thin])
        ax3.set_xticklabels(x_labels[::thin],rotation=45,fontsize=8,ha="right")
        ax3.set_ylim(0,12000)
        ax3.set_xlabel("纬度，经度",fontsize=15)
        ax3.set_ylabel("高度(m)",fontsize=15)
        fig2.savefig('图11.2_'+time_name[:4]+time_name[5:7]+time_name[8:10]+time_name[11:13]+time_name[14:16]+time_name[17:19]+water_var_chn[ii]+'.pdf',dpi =300, bbox_inches='tight',pad_inches=0.1)
        plt.close()
        print('plot '+title_name_water+' done!')
    for ii in range(len(water_var_qn)):        
        title_name_water=ncfile.variables[water_var_qn[ii]].description
        cloud_var = ds[water_var_qn[ii]][time_point,:]
        w_cross = vertcross(cloud_var,ht, wrfin=ncfile,start_point=start_point,end_point=end_point,latlon=True,meta=True)
        w_cross_filled = np.ma.copy(to_np(w_cross)) 
        for i in range(w_cross_filled.shape[-1]):
            column_vals = w_cross_filled[:,i]
            first_idx = int(np.transpose((column_vals > -200).nonzero())[0])
            w_cross_filled[0:first_idx, i] = w_cross_filled[first_idx, i] 
        w_cross_filled1   =   w_cross_filled
        fig2,ax3= plt.subplots()
        fig2.set_size_inches(8,6)
        gap_cb_3= np.linspace(0,to_np(w_cross_filled1).max(),10)
        im30=ax3.contourf(xs,to_np(w_cross.coords["vertical"]),to_np(w_cross_filled1),30,cmap='YlGn')
        fig2.subplots_adjust(left=0.07, right=0.87)
        box= ax3.get_position()
        pad, width = 0.02, 0.02 
        cax = fig2.add_axes([box.xmax+pad, box.ymin,width,box.height])    
        cbar = fig2.colorbar(im30,cax=cax,ticks=gap_cb_3,extend='max',orientation='vertical') 
        cbar.set_label('个/kg', fontsize=20) 
        
        im31=ax3.contour(xs,to_np(temp_cross.coords["vertical"]),to_np(temp_cross_filled),gap_temp_p,extend='both',linewidths=0.5,linestyles='solid',colors='k')
        ax3.clabel(im31, fontsize=12, inline=False)
        im32=ax3.contour(xs,to_np(temp_cross.coords["vertical"]),to_np(temp_cross_filled),gap_temp_minus,extend='both',linewidths=0.5,linestyles='dashed',colors='k')
        ax3.clabel(im32, fontsize=12, inline=False) 
        im33=ax2.contour(xs,to_np(temp_cross.coords["vertical"]),to_np(temp_cross_filled),[0],origin='lower',extend='both',linewidths=2,linestyles='solid',colors='k') 
        ax3.clabel(im33, fontsize=12, inline=False)          
        ax3.fill_between(xs,0,to_np(ter_line),facecolor="k")
        ax3.set_xticks(x_ticks[::thin])
        ax3.set_xticklabels(x_labels[::thin],rotation=45,fontsize=8,ha="right") 
        ax3.set_ylim(0,12000)
        ax3.set_xlabel("纬度，经度",fontsize=15)
        ax3.set_ylabel("高度(m)",fontsize=15)
        fig2.savefig('图11.2_'+time_name[:4]+time_name[5:7]+time_name[8:10]+time_name[11:13]+time_name[14:16]+time_name[17:19]+water_var_qn_chn[ii]+'.pdf',dpi =300, bbox_inches='tight',pad_inches=0.1)
        print('plot '+title_name_water+' done!')
        plt.close()
end = time.clock()
print('>>> Total running time: %s Seconds'%(end-start))

