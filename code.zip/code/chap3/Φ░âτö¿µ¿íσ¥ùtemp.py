#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
作者：毕凯，bikai_picard@vip.sina.com
日期：2019年11月
"""
import temp_cal 
Celsius_degree=50 
Fahr_T = temp_cal.Celsius_to_Fahrenheit(Celsius_degree) 
print(' 摄氏温度{0:-4d} = 华氏温度{1:8.2f}'.format(Celsius_degree,Fahr_T))
Kelvin_T = temp_cal.Celsius_to_Kelvin(Celsius_degree)
print(' 摄氏温度{0:-4d} = 绝对温度{1:8.2f}'.format(Celsius_degree,Kelvin_T))   
