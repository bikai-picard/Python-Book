#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
temp_cal.py
演示python中函数的使用
作者：毕凯，bikai_picard@vip.sina.com
日期：2019年11月
"""
def Celsius_to_Fahrenheit(Celsius_degree): 

    Fahrenheit=Celsius_degree*1.8+32 
    return(Fahrenheit) 
    
def Celsius_to_Kelvin(Celsius_degree):   
    Kelvin_T=Celsius_degree+273.15    
    return(Kelvin_T)
    
if __name__ == '__main__': 
    
    Celsius_degree=35     
    Fahr_T = Celsius_to_Fahrenheit(Celsius_degree) 
    print(' 摄氏温度{0:-4d} = 华氏温度{1:8.2f}'.format(Celsius_degree,Fahr_T)) 
    Kelvin_T = Celsius_to_Kelvin(Celsius_degree) 
    print(' 摄氏温度{0:-4d} = 绝对温度{1:8.2f}'.format(Celsius_degree,Kelvin_T))
    
    