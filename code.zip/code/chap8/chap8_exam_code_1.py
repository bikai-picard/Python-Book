#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@毕凯，北京市人工影响天气办公室
@ email: bikai_picard@vip.sina.com 
"""
import os
os.chdir("E:\\BIKAI_books\\data\\chap8") 
os.getcwd()
import pandas as pd 
import matplotlib
matplotlib.rcParams['font.sans-serif']=['FangSong']
matplotlib.rcParams['axes.unicode_minus']=False  
import matplotlib.pyplot as plt 
import matplotlib.dates as mdate 
import time
start =time.clock() 
def cal_specific_humidity(pressure,water_vapor_pressure): 
     specific_humidity=622*water_vapor_pressure/(pressure - 0.378*water_vapor_pressure) 
     return(specific_humidity)

def read_file(file_name): 
    data_weather=pd.read_table(file_name,
                                  sep='\s+',
                                  header=None)
    data_weather.columns = ['date','time','visibility','RH','Temp','Pressure','wind_S','wind_D','water_vapor_pressure','dew_point','rainfall']

    data_weather['date'] = pd.to_datetime(data_weather['date'])
    time_list= data_weather['time'].values.tolist()
    time_list1=[str(i)+':00' for i in time_list] 
    data_weather['time'] = pd.to_timedelta(time_list1) 
        
    data_weather['date_time']=data_weather['date'] +pd.to_timedelta(data_weather['time'].astype(str))
    data_weather['specific_humidity']=data_weather.apply(lambda x: cal_specific_humidity(x['Pressure'],x['water_vapor_pressure']),axis=1)
    print( data_weather.dtypes) 
    data2 = data_weather.loc[:,['date_time','visibility','RH','specific_humidity']] 
    return(data2)

def plot_weather_info(data_weather):
	
    fig,ax = plt.subplots()
    fig.set_size_inches(10,5)
    ax1 = ax.twinx()
    ax2 = ax.twinx() 
       
    f0, =ax.plot(data_weather['date_time'] ,
             data_weather['visibility'], 
             c='k',
             ls='', 
             marker='o', 
             ms=2,
             lw=1, 
             mec='k',
             mfc='k',
             alpha=0.3,
             label='能见度 (m)') 

    f1, =ax1.plot(data_weather['date_time'] ,data_weather['RH'],c='r',ls='', marker='o', ms=2,lw=1, mec='r',mfc='r',alpha=0.3,label='相对湿度(%)')
    f2, =ax2.plot(data_weather['date_time'],data_weather['specific_humidity'],c='b',ls='', marker='o',ms=2,lw=1,mec='b',mfc='b',alpha=0.3,label='比湿(g/kg)') 
    ax.set_ylabel('能见度 (m)',fontsize=15)
    ax1.set_ylabel('相对湿度(%)',fontsize=15) 
    ax2.set_ylabel('比湿(g/kg)',fontsize=15) 
    ax.set_ylim(100, 10000)
    ax.set_yscale('log')
       
    ax1.grid(True,linestyle=":", linewidth=1,alpha=0.5)
    ax1.yaxis.grid(True,which='minor',linestyle=":")  
   
    ax.xaxis.set_major_formatter(mdate.DateFormatter('%m/%d %H:%M')) 

    ax2.spines['right'].set_position(('outward', 60)) 
    ax.spines['left'].set_color(f0.get_color()) 
    ax1.spines['right'].set_color(f1.get_color())
    ax2.spines['right'].set_color(f2.get_color())
    ax2.yaxis.set_ticks_position('right')
    ax.yaxis.label.set_color(f0.get_color())
    ax1.yaxis.label.set_color(f1.get_color())
    ax2.yaxis.label.set_color(f2.get_color())

    ax.tick_params(labelsize=15) 
    ax1.tick_params(labelsize=15)
    ax2.tick_params(labelsize=15)

    ax.tick_params(axis='y', colors=f0.get_color())  
    ax1.tick_params(axis='y', colors=f1.get_color())    
    ax2.tick_params(axis='y', colors=f2.get_color())

    for tick in ax.get_xticklabels():
        tick.set_rotation(30)     
        
    fig.savefig('图8.1_比湿时间序列.pdf',
                dpi = 300,
                bbox_inches='tight', pad_inches=0.1) 
    plt.close()  
    return()

if __name__ == '__main__': 
    file_name = 'chap8_200912.txt'
    data_weather=read_file(file_name)
    plot_weather_info(data_weather)
end = time.clock() 
print('>>> Total running time: %s Seconds'%(end-start))#

