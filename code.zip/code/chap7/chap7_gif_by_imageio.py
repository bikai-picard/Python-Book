#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@毕凯，北京市人工影响天气办公室
@ email: bikai_picard@vip.sina.com 
"""
import os 
os.chdir("E:\\BIKAI_books\\data\\chap7\\gif_maker_python") 
os.getcwd()
import imageio 
import glob 
fig_filenames = glob.glob("*.png") 
gif_single_image=[]
for fig_name in fig_filenames:
    gif_single_image.append(imageio.imread(fig_name)) 
imageio.mimsave('图7.9_gif_by_imageio_radar_rainfall1.gif',  
                gif_single_image,
                duration = 1) 
