#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@毕凯，北京市人工影响天气办公室
@ email: bikai_picard@vip.sina.com 
"""
import os
os.chdir("E:\\BIKAI_books\\data\\chap7")
os.getcwd()
import matplotlib.pyplot as plt
import pandas as pd 
import matplotlib
matplotlib.rcParams['font.sans-serif']=['FangSong']
matplotlib.rcParams['axes.unicode_minus']=False 
data=pd.read_csv('chap7_INP_Scatter.csv',header=0)
data_15=pd.DataFrame()
data_15['in_conc_sample']=data['INP_measure'][(data['temp']<=-13)&(data['temp']>=-17)]
data_20=pd.DataFrame()
data_20['in_conc_sample']=data['INP_measure'][(data['temp']<=-19)&(data['temp']>=-21)] 
data_25=pd.DataFrame()
data_25['in_conc_sample']=data['INP_measure'][(data['temp']<=-24)&(data['temp']>=-26)] 
data_30=pd.DataFrame()
data_30['in_conc_sample']=data['INP_measure'][(data['temp']<=-29)&(data['temp']>=-31)] 
data_35=pd.DataFrame()
data_35['in_conc_sample']=data['INP_measure'][(data['temp']<=-33)&(data['temp']>=-37)] 

fig,ax = plt.subplots()
fig.set_size_inches(8,6) 

inp_box=[data_15['in_conc_sample'],
         data_20['in_conc_sample'],
         data_25['in_conc_sample'],
         data_30['in_conc_sample'],
         data_35['in_conc_sample']]

ax.boxplot(inp_box, 
           sym='k+', 
           vert=True, 
           showmeans=True,
           meanline=False, 
           meanprops=dict(linestyle='solid',
                          marker='o',
                          markersize=8,
                          markerfacecolor='w',
                          markeredgecolor='r',
                          markeredgewidth=2),
           showfliers=True,
           flierprops={'color':'gray','marker':'.','markersize':3,'markeredgecolor':'gray'},
           boxprops=dict(color='k'),
           medianprops=dict(linestyle='solid',
                            color='k',
                            linewidth=2),
           whis=(10, 90) )
ax.set_xticks([1,2,3,4,5]) 
ax.set_xticklabels([-15,-20,-25,-30,-35])  
ax.set_ylabel('冰核数浓度/L$^{-1}$',fontsize=15) 
ax.grid(True,linestyle=":",linewidth=1,alpha=0.5)
ax.set_yscale('log') 
ax.set_xlabel('活化温度/$^{\circ}C$',fontsize=15)
ax.tick_params(labelsize=15)

fig.savefig('图7.6_箱线图.png',dpi = 300) 
