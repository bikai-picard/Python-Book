#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@毕凯，北京市人工影响天气办公室
@ email: bikai_picard@vip.sina.com 
"""
import os
os.chdir("E:\\BIKAI_books\\data\\chap7\\gif_maker_python") 
os.getcwd()
import subprocess

fps=1 
shell_input = ['D:\\ffmpeg-20200626-7447045-win64-static\\bin\\ffmpeg', 
               '-r',
               str(fps),
               '-i',
               '%d.png',
               '图7.10_gif_by_ffmpeg_radar_rainfall1.gif'] 
gif=subprocess.Popen(args=shell_input,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,universal_newlines=True)
