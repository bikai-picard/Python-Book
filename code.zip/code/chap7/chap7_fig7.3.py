#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@毕凯，北京市人工影响天气办公室
@ email: bikai_picard@vip.sina.com 
"""
import os 
os.chdir("E:\\BIKAI_books\\data\\chap7")
os.getcwd()
import matplotlib.pyplot as plt 
import pandas as pd 
import numpy as np 
import matplotlib
matplotlib.rcParams['font.sans-serif']=['FangSong'] 
matplotlib.rcParams['axes.unicode_minus']=False  
data=pd.read_csv('chap7_INP_Scatter.csv',header=0)
fig,ax = plt.subplots() 
fig.set_size_inches(8,6) 

sca=ax.scatter(data['INP_measure'],
               data['INP_Cal'],
               alpha=0.8,
               c=data['temp'], 
               edgecolors='k',
               s=[x/2 for x in data['aps_conc'].tolist()], 
               linewidths=0.2, 
               cmap='bwr') 

ax.set_xscale('log') 
ax.set_yscale('log') 
ax.set_ylabel(' 冰核浓度计算值(个/L)',fontsize=12) 
ax.set_xlabel(' 冰核浓度测量值(个/L)',fontsize=12) 
ax.grid(True,linestyle=":",linewidth=1,alpha=0.5)
gap_cb = np.linspace(-40,-10,7, endpoint=True) 
fig.subplots_adjust(left=0.07, right=0.87) 
box = ax.get_position() 
pad, width = 0.02, 0.015 
cax = fig.add_axes([box.xmax + pad, box.ymin, width, box.height])
cbar = fig.colorbar(sca,cax = cax,ticks = gap_cb,extend = 'both') 
fig.text(0.93, 0.87, '$^{\circ}$C', fontsize=12,color='k',ha='right', va='bottom', alpha=1)

fig.savefig('图7.3_散点图.pdf',dpi = 300, bbox_inches=None, pad_inches=1.5)
