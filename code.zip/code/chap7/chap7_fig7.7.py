#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@毕凯，北京市人工影响天气办公室
@ email: bikai_picard@vip.sina.com 
"""
import os 
os.chdir("E:\\BIKAI_books\\data\\chap7") 
os.getcwd()
import matplotlib.pyplot as plt 
import pandas as pd 
import matplotlib
matplotlib.rcParams['font.sans-serif']=['FangSong']
matplotlib.rcParams['axes.unicode_minus']=False  
import matplotlib.colors as clr 
import matplotlib.dates as mdate 
import numpy as np 
from numpy import ma
import math

data=pd.read_csv('chap7_PSD.csv',header=0)
data['date_time'] = pd.to_datetime(data['date_time'],format='%Y-%m-%d %H:%M:%S') 
data= data.set_index('date_time')

x = data.index.tolist() 
y= [float(a) for a in  data.columns.tolist()] 
X,Y = np.meshgrid(x,y)

z =  data.values 
z_tem=ma.masked_where(z <= 0, z)
z_tem2=pd.DataFrame(z_tem)
z_tem2.index=data.index  

for ii in range(len(x)-1):
    if (x[ii+1]-x[ii]).seconds>1200 :
        z_tem2.loc[x[ii]:x[ii+1],:]= np.nan  
Z_dn = z_tem2.T 

gap_ax_dn = np.logspace(math.log10(0.1),math.log10(800),30,endpoint=True) 

fig,(ax1,ax2) = plt.subplots(2,1,sharex=True) 
fig.set_size_inches(8,6)

im1 = ax1.contourf(X,
                   Y, 
                   Z_dn,
                   gap_ax_dn,
                   norm=clr.LogNorm(), 
                   cmap='jet',
                   ) 

im2 = ax2.pcolormesh(x,
                     y,
                     Z_dn,
                     norm=clr.LogNorm(),
                     cmap='jet',
                     vmin=0.1,
                     vmax=800)

ax1.set_ylabel('尺度(μm)')
ax2.set_ylabel('尺度(μm)')
ax1.set_yscale('log')
ax2.set_yscale('log') 
ax1.tick_params(labelsize=15) 
ax2.tick_params(labelsize=15)
ax1.set_title('contourf绘图粒子谱',fontsize=16)
ax2.set_title('pcolormesh绘图粒子谱',fontsize=16)
ax2.xaxis.set_major_formatter(mdate.DateFormatter('%H:%M'))

fig.subplots_adjust(left=0.07, right=0.87)

box_aps_dn1 = ax1.get_position()
pad, width = 0.01, 0.01 
cax_aps_dn1 = fig.add_axes([box_aps_dn1.xmax + pad, box_aps_dn1.ymin, width, box_aps_dn1.height]) 
cbar_aps_dn1 = fig.colorbar(im1,cax=cax_aps_dn1,ticks=[0.1,1,10,100,1000],extend='max')
cbar_aps_dn1.set_label('数浓度(个/$cm^3$)')
cbar_aps_dn1.ax.tick_params(labelsize=10)

box_aps_dn2 = ax2.get_position()
cax_aps_dn2 = fig.add_axes([box_aps_dn2.xmax + pad, box_aps_dn2.ymin, width, box_aps_dn2.height]) 
cbar_aps_dn2 = fig.colorbar(im2,cax=cax_aps_dn2,ticks=[0.1,1,10,100,1000],extend='max')
cbar_aps_dn2.set_label('数浓度(个/$cm^3$)')
cbar_aps_dn2.ax.tick_params(labelsize=10)
   
fig.savefig('图7.7粒子谱时间序列.pdf',dpi = 300)
