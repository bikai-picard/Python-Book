#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@毕凯，北京市人工影响天气办公室
@ email: bikai_picard@vip.sina.com 
"""
import os 
os.chdir("E:\\BIKAI_books\\data\\chap7")
os.getcwd()
import matplotlib.pyplot as plt 
import pandas as pd 
import matplotlib
matplotlib.rcParams['font.sans-serif']=['FangSong']
matplotlib.rcParams['axes.unicode_minus']=False
os.environ['PROJ_LIB'] = 'D:\\anaconda3\\Library\\share'
import numpy as np 
from mpl_toolkits.basemap import Basemap 
data_back = pd.read_table('chap7_19042513', sep='\s+',skiprows=12,header=None) 
data_back.columns = ['a','b','year','month','day','hour','min','code','time','lat','lon','height','p_height'] 

fig,ax1= plt.subplots()  
fig.set_size_inches(8,6) 

m = Basemap(projection='cyl', 
            llcrnrlon=100,  
            urcrnrlon=131, 
            llcrnrlat=30,  
            urcrnrlat=51,  
            ax=ax1, 
            resolution='c') 

m.drawcoastlines(linewidth=0.72, color='gray') 
m.arcgisimage(service='ESRI_Imagery_World_2D', xpixels = 1500, verbose= True)
m.readshapefile('shp_for_basemap/bou2_4p', 
            'bou2_4p',    
            color='w',     
            linewidth=0.5)  

m.drawparallels(np.arange(30, 51, 10),  
                labels=[1, 0, 0, 0],  
                linewidth=0.0,)     
m.drawmeridians(np.arange(100, 131, 10),  
                labels=[0, 0, 0, 1],  
                linewidth=0.0,) 

ax1.set_yticks(np.arange(30, 51, 10)) 
ax1.set_yticklabels([]) 
ax1.set_xticks(np.arange(100, 131, 10))  
ax1.set_xticklabels([])
ax1.set_title("36小时后向轨迹路径",fontsize=20)

m.plot(data_back.lon, data_back.lat, lw=2, color='r') 
fig.savefig('图7.8_后向轨迹.png',dpi = 300)
