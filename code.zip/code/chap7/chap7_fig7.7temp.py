#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@毕凯，北京市人工影响天气办公室
@ email: bikai_picard@vip.sina.com 
"""
import os
os.chdir("E:\\BIKAI_books\\data\\chap7") 
os.getcwd()
import matplotlib.pyplot as plt 
import pandas as pd
import matplotlib
matplotlib.rcParams['font.sans-serif']=['FangSong']
matplotlib.rcParams['axes.unicode_minus']=False  
import matplotlib.colors as clr 
import matplotlib.dates as mdate 
import numpy as np 
from numpy import ma
import math 
import datetime as dt

data=pd.read_csv('chap7_粒子谱.csv',header=0)

data['date_time'] = pd.to_datetime(data['date_time'],format='%Y-%m-%d %H:%M:%S')

data['date_number']=data['date_time'].dt.hour*60+data['date_time'].dt.minute

data= data.set_index('date_number')

data1=pd.DataFrame()
data1['date_time'] = data['date_time']
data1['date_time1'] = data['date_time'].timestamp()
data=data.drop(['date_time'],axis=1) 

print(data.dtypes)

x = data.index.tolist()
y= [float(i) for i in  data.columns.tolist()] 
print(x[600])

z =  data.values 
z_tem=ma.masked_where(z <= 0, z)
z_tem2=pd.DataFrame(z_tem)
z_tem2.index=data.index  

for ii in range(len(x)-1):
    if x[ii+1]-x[ii]>20 :
        z_tem2.loc[x[ii]:x[ii+1],:]= np.nan  
Z_dn = z_tem2.T 

gap_ax_dn = np.logspace(math.log10(0.1),math.log10(200),30,endpoint=True)

x1 =range(len( data.index.tolist()))
X,Y = np.meshgrid(x,y)

fig,(ax1,ax2) = plt.subplots(2,1,sharex=True) 
fig.set_size_inches(8,6)

im1 = ax1.contourf(X, 
                   Y, 
                   Z_dn,
                   gap_ax_dn,
                   norm=clr.LogNorm(),
                   cmap='jet',
                   origin='lower',extend='both') 

im2 = ax2.pcolormesh(x,
                     y,
                     Z_dn,
                     norm=clr.LogNorm(),
                     cmap='jet',
                     vmin=0.1,
                     vmax=200)
ax1.set_ylabel('尺度(μm)')
ax2.set_ylabel('尺度(μm)')
ax1.set_yscale('log') 
ax2.set_yscale('log') 
ax1.tick_params(labelsize=15) 
ax2.tick_params(labelsize=15) 
ax1.set_title('contourf绘图粒子谱',fontsize=16)
ax2.set_title('pcolormesh绘图粒子谱',fontsize=16)
fig.subplots_adjust(left=0.07, right=0.87)
box_aps_dn1 = ax1.get_position()
pad, width = 0.01, 0.01 
cax_aps_dn1 = fig.add_axes([box_aps_dn1.xmax + pad, box_aps_dn1.ymin, width, box_aps_dn1.height]) 
cbar_aps_dn1 = fig.colorbar(im1,cax=cax_aps_dn1,ticks=[0.1,1,10,100,1000],extend='max') 
cbar_aps_dn1.set_label('数浓度(#/$cm^3$)')
cbar_aps_dn1.ax.tick_params(labelsize=10) 
box_aps_dn2 = ax2.get_position()
cax_aps_dn2 = fig.add_axes([box_aps_dn2.xmax + pad, box_aps_dn2.ymin, width, box_aps_dn2.height]) 
cbar_aps_dn2 = fig.colorbar(im2,cax=cax_aps_dn2,ticks=[0.1,1,10,100,1000],extend='max') 
cbar_aps_dn2.set_label('数浓度(#/$cm^3$)')
cbar_aps_dn2.ax.tick_params(labelsize=10) 
ax2.set_yticks(x)
ax2.set_yticklabels(data1['date_time'].values.tolist()) 
fig.savefig('粒子谱时间序列.png',dpi = 300)
