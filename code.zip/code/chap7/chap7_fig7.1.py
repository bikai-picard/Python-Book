#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@ BI Kai
@ email: bikai_picard@vip.sina.com 
"""
import os 
os.chdir("E:\\BIKAI_books\\data\\chap7")
os.getcwd()
import matplotlib.pyplot as plt
import matplotlib.dates as mdate
import pandas as pd
import matplotlib
matplotlib.rcParams['font.sans-serif']=['FangSong']
matplotlib.rcParams['axes.unicode_minus']=False
data = pd.read_csv('chap7_weather.csv',header=0)
data['date_time'] = pd.to_datetime(data['date_time']) 
fig,(ax1,ax2) = plt.subplots(2,1,sharex=True)
ax1.plot(data['date_time'] , 
        data['Temp'],      
        c='k', 
        ls='-',
        marker='o', 
        markevery = 60,  
        ms=4,
        lw=1,
        mec='k',
        mfc='k',
        alpha=0.3, 
        label='温度 ($^\circ$C)')

ax2.plot(data['date_time'] ,
        data['RH'],         
        c='k', 
        ls='', 
        marker='v', 
        markevery = 20,
        ms=6, 
        lw=1,
        mec='k', 
        mfc='k',
        alpha=0.3,
        label='温度 ($^\circ$C)') 
ax1.set_ylabel('温度($^\circ$C)',fontsize=15) 
ax2.set_ylabel('湿度(%)',fontsize=15)
ax2.set_xlabel('时间',fontsize=15) 
ax2.xaxis.set_major_formatter(mdate.DateFormatter('%H:%M'))  
fig.savefig('图7.1_温湿度变化图.png',dpi = 300)
