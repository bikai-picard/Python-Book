#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@ BI Kai
@ email: bikai_picard@vip.sina.com 
"""
import os 
os.chdir("E:\\BIKAI_books\\data\\chap7") 
os.getcwd()
import matplotlib.pyplot as plt
import pandas as pd 
import numpy as np 
import matplotlib
matplotlib.rcParams['font.sans-serif']=['FangSong']
matplotlib.rcParams['axes.unicode_minus']=False 

from windrose import WindroseAxes 

data=pd.read_csv('chap7_windrose.csv',header=0)
data_wd= np.array(data['WIND_D'])
data_ws= np.array(data['WIND_S']) 

ax = WindroseAxes.from_ax()
ax.bar(data_wd, 
       data_ws, 
       nsector=16, 
       bins=6, 
       normed=True,
       opening=0.8, 
       edgecolor='white',
       alpha=1)

ax.set_legend(loc='best',fontsize=12)
plt.savefig('图7.4_风玫瑰图.pdf', 
            dpi = 300) 