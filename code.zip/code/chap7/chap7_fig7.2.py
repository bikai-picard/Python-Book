#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@ BI Kai
@ email: bikai_picard@vip.sina.com 
"""
import os 
os.chdir("E:\\BIKAI_books\\data\\chap7") 
os.getcwd()
import matplotlib.pyplot as plt
import matplotlib.dates as mdate 
import pandas as pd 
import matplotlib
matplotlib.rcParams['font.sans-serif']=['FangSong']  
matplotlib.rcParams['axes.unicode_minus']=False    
data = pd.read_csv('chap7_weather.csv',header=0) 
data['date_time'] = pd.to_datetime(data['date_time']) 
data_mean =data.resample('1H',on='date_time').mean() 
data_std =data.resample('1H',on='date_time').std() 
data_result = pd.DataFrame()  
data_result['Temp_mean'] = data_mean['Temp'] 
data_result['Temp_std'] = data_std['Temp']
data_result.index=data_mean.index
data_result.eval('lowv=Temp_mean-2*Temp_std',inplace=True) 
data_result.eval('upv=Temp_mean+2*Temp_std',inplace=True)  

fig,ax = plt.subplots()
ax.errorbar(data_result.index,
            data_result['Temp_mean'],
            yerr=data_result['Temp_std'], 
            color='k', 
            linestyle=':', 
            alpha=1, 
            fmt='-o', 
            ms=4, 
            mec='k',
            mfc='k',
            ecolor = 'k',
            elinewidth=1, 
            capsize=3,
            errorevery=1)

ax.fill_between(data_result.index,
                data_result['lowv'],
                data_result['upv'], 
                color='gray',
                alpha=0.2) 

ax.set_ylabel('温度($^\circ$C)',fontsize=15)
ax.set_xlabel('时间',fontsize=15) 
ax.xaxis.set_major_formatter(mdate.DateFormatter('%H:%M')) 
fig.savefig('图7.2_带误差棒的温度变化图.png',dpi = 300)