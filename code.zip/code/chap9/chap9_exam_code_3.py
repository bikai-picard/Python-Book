#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@毕凯，北京市人工影响天气办公室
@ email: bikai_picard@vip.sina.com 
"""
import os
os.chdir("E:\\BIKAI_books\\data\\chap9")
os.getcwd() 
import pandas as pd 
import matplotlib
matplotlib.rcParams['font.sans-serif']=['FangSong'] 
matplotlib.rcParams['axes.unicode_minus']=False
import matplotlib.pyplot as plt
from windrose import WindroseAxes
import numpy as np
import time 
start =time.clock()
weather_filename = 'result_weather.csv'
data= pd.read_csv(weather_filename, header=0)
data['date_time'] = pd.to_datetime(data['date_time']) 
data.columns =['date_time','Temp','RH','Pressure','wind_D_2m','wind_S_2m','Rainfall_1h']
wd= np.array(data['wind_D_2m']) 
ws= np.array(data['wind_S_2m']) 

binw=[0.0,0.3,1.6,3.4,5.5,8.0,10.8]
ax = WindroseAxes.from_ax()
ax.bar(wd,
       ws,
       nsector=16, 
       bins=binw, 
       normed=True, 
       opening=0.8,
       edgecolor='white',
       alpha=1)

ax.grid(True,
        linestyle=":",
        linewidth=1, 
        alpha=0.5) 
ax.set_legend(loc=1,
              bbox_to_anchor=(1.15,1),
              title="风速",
              edgecolor='k',
														  fontsize=12) 
plt.savefig('图9.3_%s.pdf'%(ax.get_title()), 
            dpi = 300,
            bbox_inches='tight', pad_inches=0.1) 
plt.close()
end = time.clock() 
print('>>> Total running time: %s Seconds'%(end-start))