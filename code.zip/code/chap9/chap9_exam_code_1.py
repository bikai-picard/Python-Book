#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@毕凯，北京市人工影响天气办公室
@ email: bikai_picard@vip.sina.com 
"""
import os
os.chdir("E:\\BIKAI_books\\data\\chap9") 
os.getcwd() 
import pandas as pd 
import glob2 
import matplotlib
matplotlib.rcParams['font.sans-serif']=['FangSong'] 
matplotlib.rcParams['axes.unicode_minus']=False  
import matplotlib.pyplot as plt  
import matplotlib.dates as mdate 
from matplotlib import ticker
from matplotlib.backends.backend_pdf import PdfPages
import time
start =time.clock() 

def batch_weather_filenames(batch_files):    
    filenames = glob2.glob(batch_files)
    print(filenames)
    kk=pd.DataFrame(filenames) 
    kk.columns =['name']
    kk['name'].to_string() 
    kk['date_time']=kk['name']
    for ii in range(len(kk['name'])):
        kk['date_time'].loc[ii]=kk['name'].iloc[ii][:-4]
    kk['date_time'] = pd.to_datetime(kk['date_time'])
    kk1 = kk.sort_values(by='date_time') 
    weather_file_name= kk1['name'].tolist() 
    return(weather_file_name) 

def read_single_weather(filename):
    data_weather=pd.read_table(filename,
                                  sep=',',
                                  header=0)
    data_weather.columns = ['date_time','wind_D_2m','wind_S_2m','wind_D_10m','wind_S_10m','Max_Wind_D','Max_Wind_S','Max_Wind_Time','Ins_Wind_D','Ins_Wind_s','Peak_Wind_D','Peak_Wind_S','Peak_Wind_Time','max_Wind_D_1m','max_Wind_s_1m','rain_1m','Temp','Max_Temp','Max_Temp_Time','Min_Temp','Min_Temp_Time','RH','Min_RH','Min_RH_Time','Pressure','Max_Pressure','Max_Pressure_Time','Min_Pressure','Min_Pressure_Time','Rainfall_1h','min_rainfall_1h','battery_P','board_T']
    data_weather['date_time'] = pd.to_datetime(data_weather['date_time']) 
    data_weather['wind_S_2m'] = data_weather['wind_S_2m'].map(lambda x: x*0.1) 
    data_weather['Temp'] = data_weather['Temp'].map(lambda x: x*0.1) 
    data_weather['Pressure'] = data_weather['Pressure'].map(lambda x: x*0.1)
    data_weather['Rainfall_1h'] = data_weather['Rainfall_1h'].map(lambda x: x*0.1)
    data2 = data_weather.loc[:,['date_time','Temp','RH','Pressure','wind_D_2m','wind_S_2m','Rainfall_1h']]
    return(data2)

def read_comb_batch_weather(file_weather_names):
    data_weather= pd.DataFrame()
    for i in range(len(file_weather_names)): 
        data_weather_single=read_single_weather(file_weather_names[i])
        data_weather= pd.concat([data_weather,data_weather_single],ignore_index=True)
    print(data_weather.dtypes)
    return(data_weather)

def plot_single_weather_plot(data_weather):
    data=data_weather.set_index('date_time')
    
    fig,(ax1,ax2,ax3,ax4,ax5,ax6) = plt.subplots(6,1,sharex=True)  
    fig.set_size_inches(10,10)
    ax1.plot(data.index,
             data['wind_D_2m'], 
             c='k',
             ls='-',
             lw=1,
             alpha=0.7,
             marker=".",
             ms=1,
             ) 
    ax1.grid(True, 
             linestyle=":", 
             linewidth=1,
             alpha=0.5)
    ax1.set_ylabel('风向') 
    ax1.set_yticks([0,90,180,270,360])
    ax1.set_yticklabels(['N','E','S','W','N']) 
    ax2.plot(data.index, data['wind_S_2m'],c='orange',ls='-',lw=1) 
    ax2.grid(True,linestyle=":",linewidth=1,alpha=0.5)
    ax2.set_ylabel('风速(m/s)') 
    ax2.yaxis.set_major_locator(ticker.MultipleLocator(5)) 
    ax2.yaxis.set_minor_locator(ticker.MultipleLocator(1)) 
    ax2.yaxis.set_major_formatter(ticker.FormatStrFormatter('%2.1f')) 
    ax3.plot(data.index,data['Temp'],c='k',ls='-',lw=1)                                               
    ax3.grid(True,linestyle=":",linewidth=1,alpha=0.5)
    ax3.set_ylabel('温度 ($^\circ$C)') 
    ax3.yaxis.set_major_locator(ticker.MultipleLocator(5)) 
    ax3.yaxis.set_minor_locator(ticker.MultipleLocator(1)) 
    ax4.plot(data.index,data['Pressure'],c='k',ls='-',lw=1) 
    ax4.grid(True,linestyle=":",linewidth=1,alpha=0.5) 
    ax4.set_ylabel('气压 (hpa)')
    ax5.plot(data.index, data['RH'],c='r',ls='-',lw=1)                                                
    ax5.grid(True,linestyle=":",linewidth=1,alpha=0.5)
    ax5.set_ylabel('相对湿度(%)') 
    ax5.yaxis.set_major_locator(ticker.MultipleLocator(10)) 
    data2 = data.resample('1H').last()
    ax6.plot(data2.index, data2['Rainfall_1h'],c='g',ls='-',lw=1)
    ax6.grid(True,linestyle=":",linewidth=1,alpha=0.5)
    ax6.set_ylabel('降水量(mm)')
    ax6.yaxis.set_major_formatter(ticker.FormatStrFormatter('%2.1f'))

    ax1.set_title('气象要素时间序列图 '+file_weather_names[i][:-4],fontsize=20) 
    ax6.set_xlabel('时间',fontsize=15) 
    ax6.xaxis.set_major_formatter(mdate.DateFormatter('%H:%M'))    
    return()

if __name__ == '__main__':
    batch_files = '2019*.txt'
    file_weather_names=batch_weather_filenames(batch_files)
    data_weather=read_comb_batch_weather(file_weather_names)
    data_weather.to_csv('result_weather.csv', index=False)
    with PdfPages('result_weather.pdf') as pdf:
        for i in range(len(file_weather_names)):
            data_weather_single=read_single_weather(file_weather_names[i])

            plot_single_weather_plot(data_weather_single) 
            pdf.savefig()
            print('I am BK! plot '+file_weather_names[i]+'  done!!!')
            plt.close() 
    
end = time.clock()
print('>>> Total running time: %s Seconds'%(end-start))