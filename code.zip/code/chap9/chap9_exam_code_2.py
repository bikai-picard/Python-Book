#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@毕凯，北京市人工影响天气办公室
@ email: bikai_picard@vip.sina.com 
"""
import os  
os.chdir("E:\\BIKAI_books\\data\\chap9") 
os.getcwd()
import pandas as pd 
import matplotlib
matplotlib.rcParams['font.sans-serif']=['FangSong'] 
matplotlib.rcParams['axes.unicode_minus']=False
import matplotlib.pyplot as plt
import matplotlib.dates as mdate
import time
start =time.clock() 

def plot_weather_subplots(data_weather):
    fig,ax = plt.subplots() 
    fig.set_size_inches(10,5)
    ax1 = ax.twinx() 
    ax2 = ax.twinx()
    ax3 = ax.twinx() 
      
    f0, =ax.plot(data_weather['date_time'] , 
             data_weather['Temp'], 
             c='k',
             ls='',
             marker='o',
             ms=2,
             lw=1, 
             mec='k', 
             mfc='k',
             alpha=0.3,
             label='温度 ($^\circ$C)') 

    f1, =ax1.plot(data_weather['date_time'] ,data_weather['wind_S_2m'],c='r',ls='', marker='o', ms=2,lw=1, mec='r',mfc='r',alpha=0.3,label='风速（m/s）')
    f2, =ax2.plot(data_weather['date_time'],data_weather['Pressure'],c='b',ls='', marker='o',ms=2,lw=1,mec='b',mfc='b',alpha=0.3,label='气压(hpa)') 
    f3, =ax3.plot(data_weather['date_time'] , data_weather['RH'],c='g',ls='',marker='o',ms=2,lw=1,mec='g',mfc='g',alpha=0.3,label='相对湿度(%)')
    ax.set_ylabel('温度($^\circ$C)',fontsize=15) 
    ax1.set_ylabel('风速（m/s）',fontsize=15) 
    ax2.set_ylabel('气压(hpa)',fontsize=15)
    ax3.set_ylabel('相对湿度(%)',fontsize=15) 
    ax1.grid(True,linestyle=":", linewidth=1,alpha=0.5)
    ax1.yaxis.grid(True,which='minor',linestyle=":")  
   
    ax.xaxis.set_major_formatter(mdate.DateFormatter('%m/%d %H:%M'))
    ax2.spines['right'].set_position(('outward', 50)) 
    ax3.spines['right'].set_position(('outward', 120))
    ax.spines['left'].set_color(f0.get_color()) 
    ax1.spines['right'].set_color(f1.get_color())
    ax2.spines['right'].set_color(f2.get_color())
    ax3.spines['right'].set_color(f3.get_color())
    ax2.yaxis.set_ticks_position('right') 
    ax3.yaxis.set_ticks_position('right') 
    ax.yaxis.label.set_color(f0.get_color())
    ax1.yaxis.label.set_color(f1.get_color())
    ax2.yaxis.label.set_color(f2.get_color())
    ax3.yaxis.label.set_color(f3.get_color())
    
    ax.tick_params(labelsize=15)
    ax1.tick_params(labelsize=15)
    ax2.tick_params(labelsize=15)
    ax3.tick_params(labelsize=15)
    ax.tick_params(axis='y', colors=f0.get_color())  
    ax1.tick_params(axis='y', colors=f1.get_color())    
    ax2.tick_params(axis='y', colors=f2.get_color())
    ax3.tick_params(axis='y', colors=f3.get_color())

    for tick in ax.get_xticklabels():
        tick.set_rotation(30)     
        
    fig.savefig('图9.2_气象要素温度湿度气压风速时间序列.pdf',
                dpi = 300, 
                bbox_inches='tight', pad_inches=0.1) 
    plt.close()
    return()

if __name__ == '__main__': 
	
    weather_filename = 'result_weather.csv' 
    data_weather = pd.read_csv(weather_filename, header=0) 
    data_weather['date_time'] = pd.to_datetime(data_weather['date_time'])
    plot_weather_subplots(data_weather)
    
end = time.clock()
print('>>> Total running time: %s Seconds'%(end-start))