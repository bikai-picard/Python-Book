#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@毕凯，北京市人工影响天气办公室
@ email: bikai_picard@vip.sina.com 
"""
import os 
os.chdir("E:\\BIKAI_books\\data\\chap9") 
os.getcwd()
import pandas as pd 
import matplotlib
matplotlib.rcParams['font.sans-serif']=['FangSong']
matplotlib.rcParams['axes.unicode_minus']=False
import matplotlib.pyplot as plt
import time
start =time.clock() 
import numpy as np 
import time
start =time.clock()

def plot_single_meterial_boxplot_1png(data_all,name) :
    data_all=data_all.set_index('date_time') 
    data_all_1h =data_all.resample('1H').mean() 
    data_all_1h=data_all_1h.reset_index()
    fig,ax = plt.subplots() 
    fig.set_size_inches(8,4) 
    ax.tick_params(labelsize=10) 
    start_1=[]
    end_1=[]

    data_all_houly_result=pd.DataFrame()
    for i in range(0,24):
        data_all_houly=data_all_1h[data_all_1h['date_time'].dt.hour.isin(np.arange(i, i+1))] 
        data_all_houly.reset_index(drop=True, inplace=True)
        data_all_houly['time']=pd.Series([i for i in range(100)]) 
        data_all_houly=data_all_houly.set_index('time')            
        box_i=data_all_houly[name]
        
        data_all_houly_result=pd.concat([data_all_houly_result,box_i], axis=1) 
    data_all_houly_result.columns=['A'+str(i) for i in range(24)] 
    dropnan_data=data_all_houly_result[data_all_houly_result>-99]
    
    ma_box=[data_all_houly_result['A'+str(i)].dropna() for i in range(24)] 
    ax.boxplot(ma_box,
               vert=True, 
               showmeans=True,
               meanline=False, 
               meanprops=dict(linestyle='solid',
                              marker='o',
                              markersize=8,
                              markerfacecolor='w',
                              markeredgecolor='r',
                              markeredgewidth=2),
               showfliers=True,
               flierprops={'color':'gray','marker':'.','markersize':3,'markeredgecolor':'gray'},
               boxprops=dict(color='k'),
               medianprops=dict(linestyle='solid',
                                color='k',
                                linewidth=2),
               whis=(10, 90), 
               )

    start_0=dropnan_data.stack().min()
    end_0=dropnan_data.stack().max()
    start_1.append(start_0)
    end_1.append(end_0) 
    
    start=min(start_1)
    end=max(end_1)

    ax.set_ylim(start,end)
                       
    ax.grid(True,linestyle=":",linewidth=1,alpha=0.5)
    ax.set_xticks([i+0.5 for i in range(24)])
    ax.set_xticklabels([i for i in range(24)],fontsize=10) 
    ax.set_xlabel('时间',fontsize=10)
    ax.set_ylabel('温度',fontsize=10)
    ax.set_title('温度日变化图',fontsize=20) 
    fig.savefig('图9.4_'+name+'_日变化箱线图.png',dpi = 300, bbox_inches='tight',pad_inches=0.1) 
    plt.close()    
    return()

if __name__ == '__main__': 
    weather_filename = 'chap9_weather_temp.csv'
    data_weather = pd.read_csv(weather_filename, header=0) 
    data_weather['date_time'] = pd.to_datetime(data_weather['date_time'])
    plot_single_meterial_boxplot_1png(data_weather,'Temp')
end = time.clock()
print('>>> Total running time: %s Seconds'%(end-start))