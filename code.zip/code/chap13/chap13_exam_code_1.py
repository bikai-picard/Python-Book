#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@毕凯，北京市人工影响天气办公室
@ email: bikai_picard@vip.sina.com 
"""
import os 
os.chdir("E:\\BIKAI_books\\data\\chap13") 
os.getcwd() 
import pandas as pd
import numpy as np 
import matplotlib.pyplot as plt 
import matplotlib.colors as clr 
import matplotlib.dates as mdate 
from numpy import ma 
import math 
import matplotlib
matplotlib.rcParams['font.sans-serif']=['FangSong'] 
matplotlib.rcParams['axes.unicode_minus']=False   
import time 
start =time.clock() 

def cbar_ticks(start,end):
    cbar_lib_list=[0.00000000001,0.0000000001,0.000000001,0.00000001,0.0000001,0.000001,0.00001,0.0001,0.001,0.01,0.1,1,10,100,1000,10000,100000,1000000,10000000]
    id_start=[]
    id_end=[]
    
    for i in range(len(cbar_lib_list)): 
        if  cbar_lib_list[i]<= start:
            id_start=i
        if cbar_lib_list[i]<=end :
            id_end=i+1
    result_start=id_start
    result_end=id_end
    cbar_list=cbar_lib_list[result_start:result_end+1]
    return(cbar_list)
    
def read_aimms_data(aimms_name)
    data_aimms = pd.read_csv(aimms_name,header=0,skiprows=13) 
    data_aimms.columns=['Time','Hours','Minutes', 'Seconds', 'Temp(C)','RH(%)', 'Pressure(mBar)','Wind_Flow_N_Comp(m/s)','Wind_Flow_E_Comp(m/s)','Wind_Speed_(m/s)', 'Wind_Direction_(deg)','Wind_Solution','Hours_2','Minutes_2','Seconds_2','Latitude(deg)','Longitude(deg)','Altitude(m)', 'Velocity_N(m/s)','Velocity_E(m/s)', 'Velocity_D(m/s)','Roll_Angle(deg)','Pitch_angle(deg)','Yaw_angle(deg)','True_Airspeed(m/s)' ,'Vertical_Wind','Sideslip_angle(deg)', 'AOA_pres_differential','Sideslip_differential','Status']
    data_aimms['date_time']=pd.to_datetime(aimms_name[9:17])+pd.to_timedelta(data_aimms['Time'].astype(int),unit='s')    
    data_aimms_1=data_aimms.loc[:,['date_time','Temp(C)','RH(%)','Pressure(mBar)','Latitude(deg)','Longitude(deg)','Vertical_Wind','Altitude(m)','True_Airspeed(m/s)']]
    data_2=data_aimms_1[data_aimms_1['Altitude(m)']>40]      
    return(data_2)

def pcasp_plot_log(df):
    headerlist=['Status', 'Number_Conc(cts/cm^3)', 'Volume_Conc(um^3/cm^3)', 'SSP200_MVD(um)', 'SSP200_ED(um)','Sample_Flow(std cm^3/s)', 'Hi_Gain_Baseline(V)', 'Mid_Gain_Baseline(V)', 'Lo_Gain_Baseline(V)', 'Sheath_Flow(std cm^3/s)','Sample_Flow_(vol cm^3/s)', 'Sheath_Flow_(vol cm^3/s)', 'Pressure_(mb)', 'Ambient Temp_(C)', 'SPP_200_OPC_ch0', 'SPP_200_OPC_ch1', 'SPP_200_OPC_ch2', 'SPP_200_OPC_ch3', 'SPP_200_OPC_ch4', 'SPP_200_OPC_ch5', 'SPP_200_OPC_ch6', 'SPP_200_OPC_ch7', 'SPP_200_OPC_ch8', 'SPP_200_OPC_ch9', 'SPP_200_OPC_ch10', 'SPP_200_OPC_ch11', 'SPP_200_OPC_ch12', 'SPP_200_OPC_ch13', 'SPP_200_OPC_ch14', 'SPP_200_OPC_ch15', 'SPP_200_OPC_ch16', 'SPP_200_OPC_ch17', 'SPP_200_OPC_ch18', 'SPP_200_OPC_ch19', 'SPP_200_OPC_ch20', 'SPP_200_OPC_ch21', 'SPP_200_OPC_ch22', 'SPP_200_OPC_ch23', 'SPP_200_OPC_ch24', 'SPP_200_OPC_ch25', 'SPP_200_OPC_ch26', 'SPP_200_OPC_ch27', 'SPP_200_OPC_ch28', 'SPP_200_OPC_ch29', 'Laser_Ref_Voltage', 'Aux_Analog_1',  'Electronics_Temp(C)', 'Avg_Transit', 'FIFO_Full', 'Reset_Flag', 'Sync_Err_A', 'Sync_Err_B', 'Sync_Err_C', 'ADC_Overflow(cts)',  'date_time'] 
    data_result_log = pd.DataFrame()
    for i in headerlist:
        data_result_log[i]=df[i] 
    fig,ax = plt.subplots() 
    fig.set_size_inches(10,100)
    data_result_log = data_result_log.set_index('date_time')
    data_result_log.plot(subplots=True,ax=ax) 
    fig.savefig('图13.1_pcasp_通道信息.pdf',dpi = 300, bbox_inches='tight', pad_inches=0.1) 
    print('>>> pcasp 通道信号已经绘制完毕!!!') 
    plt.close()     
    return()

def read_cal_pcasp_data(file_name,code):
    data = pd.read_csv(file_name,
                       header=0,
                       skiprows=19) 
    data.columns=['Time', 'Hi_Gain_Baseline(V)', 'Mid_Gain_Baseline(V)', 'Lo_Gain_Baseline(V)', 'Sample_Flow(std cm^3/s)', 'Laser_Ref_Voltage', 'Aux_Analog_1', 'Sheath_Flow(std cm^3/s)', 'Electronics_Temp(C)', 'Avg_Transit', 'FIFO_Full', 'Reset_Flag', 'Sync_Err_A', 'Sync_Err_B', 'Sync_Err_C', 'ADC_Overflow(cts)', 'SPP_200_OPC_ch0', 'SPP_200_OPC_ch1', 'SPP_200_OPC_ch2', 'SPP_200_OPC_ch3', 'SPP_200_OPC_ch4', 'SPP_200_OPC_ch5', 'SPP_200_OPC_ch6', 'SPP_200_OPC_ch7', 'SPP_200_OPC_ch8', 'SPP_200_OPC_ch9', 'SPP_200_OPC_ch10', 'SPP_200_OPC_ch11', 'SPP_200_OPC_ch12', 'SPP_200_OPC_ch13', 'SPP_200_OPC_ch14', 'SPP_200_OPC_ch15', 'SPP_200_OPC_ch16', 'SPP_200_OPC_ch17', 'SPP_200_OPC_ch18', 'SPP_200_OPC_ch19', 'SPP_200_OPC_ch20', 'SPP_200_OPC_ch21', 'SPP_200_OPC_ch22', 'SPP_200_OPC_ch23', 'SPP_200_OPC_ch24', 'SPP_200_OPC_ch25', 'SPP_200_OPC_ch26', 'SPP_200_OPC_ch27', 'SPP_200_OPC_ch28', 'SPP_200_OPC_ch29', 'Number_Conc(cts/cm^3)', 'Volume_Conc(um^3/cm^3)', 'SSP200_MVD(um)', 'SSP200_ED(um)', 'Sample_Flow_(vol cm^3/s)', 'Sheath_Flow_(vol cm^3/s)', 'Pressure_(mb)', 'Ambient Temp_(C)', 'Status', 'GPS_Time']
    data['Date'] = pd.to_datetime(file_name[-18:-10])     
    data['date_time']=data['Date']+pd.to_timedelta(data['Time'].astype(int),unit='s')
    if code==1:
        pcasp_plot_log(data) 
    else:
        pass

    data_aimms_start=str(data_aimms['date_time'].iloc[0])
    data_aimms_end=str(data_aimms['date_time'].iloc[-1])
    index_sp=data[data['date_time'] == data_aimms_start].index[0] 
    index_ep=data[data['date_time'] == data_aimms_end].index[0] 
    
    data_pcasp=data.loc[index_sp:index_ep,:]
    headerpsd_pcasp=['SPP_200_OPC_ch2', 'SPP_200_OPC_ch3', 'SPP_200_OPC_ch4', 'SPP_200_OPC_ch5', 'SPP_200_OPC_ch6', 'SPP_200_OPC_ch7', 'SPP_200_OPC_ch8', 'SPP_200_OPC_ch9', 'SPP_200_OPC_ch10', 'SPP_200_OPC_ch11', 'SPP_200_OPC_ch12', 'SPP_200_OPC_ch13', 'SPP_200_OPC_ch14', 'SPP_200_OPC_ch15', 'SPP_200_OPC_ch16', 'SPP_200_OPC_ch17', 'SPP_200_OPC_ch18', 'SPP_200_OPC_ch19', 'SPP_200_OPC_ch20', 'SPP_200_OPC_ch21', 'SPP_200_OPC_ch22', 'SPP_200_OPC_ch23', 'SPP_200_OPC_ch24', 'SPP_200_OPC_ch25', 'SPP_200_OPC_ch26', 'SPP_200_OPC_ch27', 'SPP_200_OPC_ch28', 'SPP_200_OPC_ch29']
    data_c_psd_pcasp = pd.DataFrame() 
    for kk in headerpsd_pcasp:
        data_c_psd_pcasp[kk]=data_pcasp[kk] 
    data_pcasp['sample_volumn'] = data_pcasp['Sample_Flow(std cm^3/s)'].map(lambda x: 1*x)    

    data_con_psd_pcasp = data_c_psd_pcasp.div(data_pcasp['sample_volumn'],axis=0)   

    data_tot_con= data_con_psd_pcasp.sum(axis=1)
    pcasp_min_size=[0.115,0.125,0.135,0.145,0.155,0.165,0.175,0.19,0.21,0.23,0.25,0.27,0.29,0.35,0.45,0.55,0.7,0.9,1.1,1.3,1.5,1.7,1.9,2.1,2.3,2.5,2.7,2.9]
    pcasp_max_size=[0.125,0.135,0.145,0.155,0.165,0.175,0.19,0.21,0.23,0.25,0.27,0.29,0.35,0.45,0.55,0.7,0.9,1.1,1.3,1.5,1.7,1.9,2.1,2.3,2.5,2.7,2.9,3.1]

    dlogDp_pcasp = []
    for jj in range(len(pcasp_min_size)):
        kk_pcasp=math.log10(pcasp_max_size[jj]/pcasp_min_size[jj])
        dlogDp_pcasp.append(kk_pcasp)

    dlogDp_df_pcasp = pd.DataFrame(np.random.rand(data_con_psd_pcasp.shape[0],data_con_psd_pcasp.shape[1]))
    dlogDp_df_pcasp.columns=data_con_psd_pcasp.columns 
    dlogDp_df_pcasp.index=data_con_psd_pcasp.index
    dlogDp_df_pcasp_1= pd.DataFrame(dlogDp_pcasp).T 
    for i in range(data_con_psd_pcasp.shape[0]):
        dlogDp_df_pcasp.iloc[i] = dlogDp_df_pcasp_1.values     
    data_dn_dlogdp_pcasp = data_con_psd_pcasp / dlogDp_df_pcasp
    data_dn_dlogdp_pcasp.index=data_pcasp['date_time']

    pcasp_mid_size=[0.12,0.13,0.14,0.15,0.16,0.17,0.18,0.2,0.22,0.24,0.26,0.28,0.3,0.4,0.5,0.6,0.8,1,1.2,1.4,1.6,1.8,2,2.2,2.4,2.6,2.8,3]      
    data_pcasp_ed3_psd = pd.DataFrame()
    data_pcasp_ed2_psd = pd.DataFrame() 
    data_pcasp_ed1_psd = pd.DataFrame()
    data_pcasp_ed0_psd = pd.DataFrame()    
    for edi in range(len(headerpsd_pcasp)):
        data_pcasp_ed3_psd[headerpsd_pcasp[edi]]=data_con_psd_pcasp[headerpsd_pcasp[edi]]*(pcasp_mid_size[edi])**3 
        data_pcasp_ed2_psd[headerpsd_pcasp[edi]]=data_con_psd_pcasp[headerpsd_pcasp[edi]]*(pcasp_mid_size[edi])**2 
        data_pcasp_ed1_psd[headerpsd_pcasp[edi]]=data_con_psd_pcasp[headerpsd_pcasp[edi]]*(pcasp_mid_size[edi])**1 
        data_pcasp_ed0_psd[headerpsd_pcasp[edi]]=data_con_psd_pcasp[headerpsd_pcasp[edi]]*(pcasp_mid_size[edi])**0        
    data_pcasp_ed3= data_pcasp_ed3_psd.sum(axis=1)
    data_pcasp_ed2= data_pcasp_ed2_psd.sum(axis=1)
    data_pcasp_ed1= data_pcasp_ed1_psd.sum(axis=1) 
    data_pcasp_ed0= data_pcasp_ed0_psd.sum(axis=1) 
    
    data_ed_pcasp=data_pcasp_ed3/data_pcasp_ed2 
    data_md_pcasp=data_pcasp_ed1/data_pcasp_ed0 
    data_MD_pcasp=pd.DataFrame(data_md_pcasp)
    data_MD_pcasp.index= data_pcasp['date_time']
    data_MD_pcasp.columns=['MD(um)'] 
    
    data_ED_pcasp=pd.DataFrame(data_ed_pcasp)
    data_ED_pcasp.index= data_pcasp['date_time'] 
    data_ED_pcasp.columns=['ED(um)']  

    data_result_pcasp=pd.DataFrame(data_tot_con)
    data_result_pcasp.index= data_pcasp['date_time']
    data_result_pcasp.columns=['PCASP_con(#/cm^3)'] 
            
    data_result_pcasp['PCASP_ED']=data_ED_pcasp['ED(um)'] 
    data_result_pcasp['PCASP_MD']=data_MD_pcasp['MD(um)'] 

    return(data_result_pcasp,data_dn_dlogdp_pcasp) 
def pcasp_make_psd_plot():

    data_pcasp,data_dn_dlogdp_pcasp=read_cal_pcasp_data(file_pcasp_name,0) 
    data_aimms=read_aimms_data(file_aimms_name)
    fig,(ax1,ax2,ax3,ax4,ax5) = plt.subplots(5,1,sharex=True) 
    fig.set_size_inches(10,10)

    ax1.plot(data_aimms['date_time'],
             data_aimms['Altitude(m)'],
             c='k', 
             ls='',
             marker='o',
             ms=2,
             mec='k',
             mfc='k',
             alpha=1,
             )
    ax2.plot(data_pcasp.index ,data_pcasp['PCASP_con(#/cm^3)'],c='k',ls='',marker='o',ms=2,mec='k',mfc='k',alpha=1)
    ax3.plot(data_pcasp.index,data_pcasp['PCASP_ED'],c='k',ls='',marker='o',ms=2,lw=1,mec='k',mfc='k',alpha=1,label='有效直径(μm)')  
    ax4.plot(data_pcasp.index,data_pcasp['PCASP_MD'],c='k',ls='',marker='o',ms=2,lw=1,mec='k',mfc='k',alpha=0.5,label='平均直径(μm)')

    ax1.set_ylabel('高度（m）',fontsize=15) 
    ax2.set_ylabel('数浓度(个/cm$^3$)',fontsize=15) 
    ax3.set_ylabel('尺度(μm)',fontsize=15) 
    ax4.set_ylabel('尺度(μm)',fontsize=15)  
    ax3.set_yscale('log') 
    ax4.set_yscale('log') 
    ax1.set_ylim(0,3600)
    ax3.set_ylim(0.1,3)
    ax4.set_ylim(0.1,3)
  
    ax1.grid(True,linestyle=":",linewidth=1,alpha=0.5)   
    ax2.grid(True,linestyle=":",linewidth=1,alpha=0.5)    
    ax3.grid(True,linestyle=":",linewidth=1,alpha=0.5)
    ax4.grid(True,linestyle=":",linewidth=1,alpha=0.5)

    ax3.legend(loc='best',edgecolor='gray',fontsize=10,frameon=True)
    ax4.legend(loc='best',edgecolor='gray',fontsize=10,frameon=True)

    ax1.tick_params(labelsize=15)
    ax2.tick_params(labelsize=15)
    ax3.tick_params(labelsize=15)
    ax4.tick_params(labelsize=15)
    
    pcasp_mid_size=[0.12,0.13,0.14,0.15,0.16,0.17,0.18,0.2,0.22,0.24,0.26,0.28,0.3,0.4,0.5,0.6,0.8,1,1.2,1.4,1.6,1.8,2,2.2,2.4,2.6,2.8,3]
    x = data_dn_dlogdp_pcasp.index.tolist()
    y=pcasp_mid_size
    X,Y = np.meshgrid(x,y)

    z_tem =  data_dn_dlogdp_pcasp.values 
    z_tem=ma.masked_where(z_tem <= 0, z_tem)
    start_list_dn=z_tem.min()
    end_list_dn=z_tem.max()
    cbar_ticks_list=cbar_ticks(start_list_dn,end_list_dn) 
    gap_ax = np.logspace(math.log10(start_list_dn),math.log10(end_list_dn),30,endpoint=True) 
    z = data_dn_dlogdp_pcasp.values    
    Z = z.T 

    for ii in range(len(x)-1):
        if (x[ii+1]-x[ii]).seconds>1000 :
            z.loc[x[ii]:x[ii+1],:]= np.nan

    im = ax5.contourf(X,Y,Z,gap_ax,norm=clr.LogNorm(),cmap='jet',origin='lower') 
                
    ax5.yaxis.grid(False)
    ax5.set_ylabel('尺度(μm)',fontsize=15)
    ax5.set_yscale('log') 
    ax5.set_xlabel('时间',fontsize=15) 
    ax5.tick_params(labelsize=15)    
    ax5.set_ylim(0.1,3) 
    ax5.xaxis.set_major_formatter(mdate.DateFormatter('%H:%M'))

    fig.subplots_adjust(left=0.07, right=0.87)
    box = ax5.get_position()
    pad, width = 0.02, 0.02 
    cax = fig.add_axes([box.xmax + pad, box.ymin, width, box.height])
    cbar= fig.colorbar(im,cax=cax,extend='both',ticks=cbar_ticks_list)
    cbar.set_label('dn/dlogDp(个/$cm^3$)',fontsize=10)
    cbar.ax.tick_params(labelsize=15)  

    fig.savefig('图13.2_气溶胶谱和各参量时间序列.pdf',dpi = 300, bbox_inches='tight', pad_inches=0.1)
    plt.close()              
    return()

def plot_pcasp_height_psd_figure(verticle_time_list):   
    data_aimms=read_aimms_data(file_aimms_name)
    data_aimms1=data_aimms.set_index('date_time')
    data_aimms_result=data_aimms1.loc[verticle_time_list[0]:verticle_time_list[1],:]
    data_pcasp,data_dn_dlogdp_pcasp=read_cal_pcasp_data(file_pcasp_name,0) 
    data_dn_dlogdp_pcasp_result=data_dn_dlogdp_pcasp.loc[verticle_time_list[0]:verticle_time_list[1],:]
    data_dn_dlogdp_pcasp_result1=data_dn_dlogdp_pcasp_result.join(data_aimms_result['Altitude(m)'], how='outer', rsuffix='_1').groupby(by='Altitude(m)').mean()
    data_pcasp_result=data_pcasp.loc[verticle_time_list[0]:verticle_time_list[1],:].join(data_aimms_result['Altitude(m)'], how='outer', rsuffix='_1').groupby(by='Altitude(m)').mean()
    x=[0.12,0.13,0.14,0.15,0.16,0.17,0.18,0.2,0.22,0.24,0.26,0.28,0.3,0.4,0.5,0.6,0.8,1,1.2,1.4,1.6,1.8,2,2.2,2.4,2.6,2.8,3]
    y=data_dn_dlogdp_pcasp_result1.index.tolist()
    X,Y = np.meshgrid(x,y)
    
    z_tem =  data_dn_dlogdp_pcasp_result1.values 
    z_tem=ma.masked_where(z_tem <= 0, z_tem)
    start_list_dn=z_tem.min()
    end_list_dn=z_tem.max()
    cbar_ticks_list=cbar_ticks(start_list_dn,end_list_dn) 
    gap_ax = np.logspace(math.log10(start_list_dn),math.log10(end_list_dn),30,endpoint=True) 
    z = data_dn_dlogdp_pcasp_result1.values    
    fig,(ax1,ax2,ax) = plt.subplots(1,3,sharey=True)
    fig.set_size_inches(10,10)
    ax1.plot(data_pcasp_result['PCASP_con(#/cm^3)'],data_pcasp_result.index,c='k',ls='',marker='o',ms=2,mec='k',mfc='k',alpha=1)    
    ax2.plot(data_pcasp_result['PCASP_ED'],data_pcasp_result.index,c='k',ls='',marker='o',ms=2,lw=1,mec='k',mfc='k',alpha=1,label='有效直径(μm)')
    ax2.plot(data_pcasp_result['PCASP_MD'],data_pcasp_result.index,c='r',ls='',marker='o',ms=2,lw=1,mec='r',mfc='r',alpha=1,label='平均直径(μm)')
    im =ax.contourf(X,Y,z,gap_ax,norm=clr.LogNorm(),cmap='jet',origin='lower')   
    ax1.grid(True,linestyle=":",linewidth=1,alpha=0.5)   
    ax2.grid(True,linestyle=":",linewidth=1,alpha=0.5)    
    ax.yaxis.grid(False)
    ax2.legend(loc='best',edgecolor='gray',fontsize=10,frameon=True)

    ax1.set_xlabel('数浓度(个/cm$^3$)',fontsize=15) 
    ax2.set_xlabel('尺度(μm)',fontsize=15)   
    ax.set_xlabel('尺度(μm)',fontsize=15)
    ax1.set_ylabel('高度（m）',fontsize=15) 
  
    ax1.set_ylim(0,3500)
    ax2.set_xlim(0.1,3)
    ax2.set_xscale('log')
    ax.set_xlim(0.1,3)
    ax.set_xscale('log')
    ax1.tick_params(labelsize=15)
    ax2.tick_params(labelsize=15)
    ax.tick_params(labelsize=15)  

    fig.subplots_adjust(left=0.07, right=0.87)
    box = ax.get_position()
    pad, width = 0.02, 0.04 
    cax = fig.add_axes([box.xmax + pad, box.ymin, width, box.height])
    cbar= fig.colorbar(im,cax=cax,extend='both',ticks=cbar_ticks_list)   
    cbar.set_label('dn/dlogDp(个/$cm^3$)',fontsize=10)
    cbar.ax.tick_params(labelsize=15)

    fig.savefig('图13.3_气溶胶谱垂直分布.pdf',dpi = 300, bbox_inches='tight', pad_inches=0.1)
    plt.close()  
    return()

if __name__ == '__main__':
    
    file_aimms_name='07AIMMS2020161116151716.csv'
    file_pcasp_name='06SPP_20020161116151716.csv'

    data_aimms=read_aimms_data(file_aimms_name) 
    data_pcasp,data_dn_dlogdp_pcasp=read_cal_pcasp_data(file_pcasp_name,1) 
    pcasp_make_psd_plot() 
    verticle_time_list=['2016-11-16 18:10:00','2016-11-16 18:40:00']  
    plot_pcasp_height_psd_figure(verticle_time_list)
end = time.clock() 
print('>>> Total running time: %s Seconds'%(end-start))