#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@毕凯，北京市人工影响天气办公室
@ email: bikai_picard@vip.sina.com 
"""
import os  
os.chdir("E:\\BIKAI_books\\data\\chap13") 
os.getcwd() 
import pandas as pd 
import numpy as np 
import matplotlib.pyplot as plt 
import matplotlib.colors as clr 
import matplotlib.dates as mdate 
from numpy import ma 
import math 
import matplotlib
matplotlib.rcParams['font.sans-serif']=['FangSong']
matplotlib.rcParams['axes.unicode_minus']=False 
matplotlib.rcParams.update({'text.usetex': False,'mathtext.fontset': 'cm',}) 
import time
start =time.clock()

def cbar_ticks(start,end):
    cbar_lib_list=[0.00000000001,0.0000000001,0.000000001,0.00000001,0.0000001,0.000001,0.00001,0.0001,0.001,0.01,0.1,1,10,100,1000,10000,100000,1000000,10000000]
    id_start=[]
    id_end=[]    
    for i in range(len(cbar_lib_list)): 
        if  cbar_lib_list[i]<= start:
            id_start=i
        if cbar_lib_list[i]<=end :
            id_end=i+1
    result_start=id_start
    result_end=id_end
    cbar_list=cbar_lib_list[result_start:result_end+1]
    return(cbar_list)
    
def read_aimms_data(aimms_name): 
    data_aimms = pd.read_csv(aimms_name,header=0,skiprows=13)
    data_aimms.columns=['Time','Hours','Minutes', 'Seconds', 'Temp(C)','RH(%)', 'Pressure(mBar)','Wind_Flow_N_Comp(m/s)','Wind_Flow_E_Comp(m/s)','Wind_Speed_(m/s)', 'Wind_Direction_(deg)','Wind_Solution','Hours_2','Minutes_2','Seconds_2','Latitude(deg)','Longitude(deg)','Altitude(m)', 'Velocity_N(m/s)','Velocity_E(m/s)', 'Velocity_D(m/s)','Roll_Angle(deg)','Pitch_angle(deg)','Yaw_angle(deg)','True_Airspeed(m/s)' ,'Vertical_Wind','Sideslip_angle(deg)', 'AOA_pres_differential','Sideslip_differential','Status','GPS_time']
    data_aimms['date_time']=pd.to_datetime(aimms_name[9:17])+pd.to_timedelta(data_aimms['Time'].astype(int),unit='s')    
    data_aimms_1=data_aimms.loc[:,['date_time','Temp(C)','RH(%)','Pressure(mBar)','Latitude(deg)','Longitude(deg)','Vertical_Wind','Altitude(m)','True_Airspeed(m/s)']]  
    data_2=data_aimms_1[data_aimms_1['Altitude(m)']>40]    
    return(data_2)

def read_cal_cas_data(file_name): 
    data = pd.read_csv(file_name,header=0,skiprows=36)
    data.columns=['Time', 'Sum_of_Transit', 'Sum_of_Particles', 'Fifo_Full', 'Reset_Flag', 'Forward_Overflow', 'Backward_Overflow', 'IAC_1', 'IAC_2', 'IAC_3', 'IAC_4', 'IAC_5', 'IAC_6', 'IAC_7', 'IAC_8', 'IAC_9', 'IAC_10', 'IAC_11', 'IAC_12', 'IAC_13', 'IAC_14', 'IAC_15', 'IAC_16', 'IAC_17', 'IAC_18', 'IAC_19', 'IAC_20', 'IAC_21', 'IAC_22', 'IAC_23', 'IAC_24', 'IAC_25', 'IAC_26', 'IAC_27', 'IAC_28', 'IAC_29', 'IAC_30', 'IAC_31', 'IAC_32', 'IAC_33', 'IAC_34', 'IAC_35', 'IAC_36', 'IAC_37', 'IAC_38', 'IAC_39', 'IAC_40', 'IAC_41', 'IAC_42', 'IAC_43', 'IAC_44', 'IAC_45', 'IAC_46', 'IAC_47', 'IAC_48', 'IAC_49', 'IAC_50', 'IAC_51', 'IAC_52', 'IAC_53', 'IAC_54', 'IAC_55', 'IAC_56', 'IAC_57', 'IAC_58', 'IAC_59', 'IAC_60', 'IAC_61', 'IAC_62', 'IAC_63', 'IAC_64', 'Dynamic_Pressure', 'Static_Pressure', 'Ambient_Temp', 'Forward_Heat_Sink_T', 'Back_Heat_Sink_T', 'Forward_Block_T', 'Backward_Block_T', 'Photodiode_1', 'Photodiode_2', 'Photodiode_3', 'Photodiode_4', 'Qualifier_TEC_Temp', 'Forward_TEC_Temp', 'Backward_TEC_T', 'Qual_Heat_Sink_T', 'Qual_Hi_Gain_Volt', 'Qual_Mid_Gain_Volt', 'Qual_Lo_Gain_Volt', 'Fwd_Hi_Gain_Volt', 'Fwd_Mid_Gain_Volt', 'Fwd_Lo_Gain_Volt', 'Back_Hi_Gain_Volt', 'Back_Mid_Gain_Volt', 'Back_Lo_Gain_Volt', 'Internal_Temp', 'RH_%', 'Spare_Analog', 'LWC_Hotwire', 'LWC_Slave_Monitor', 'Laser_Curr_Mon_(mA)', 'Laser_Monitor', 'CAS_Forw_ch0', 'CAS_Forw_ch1', 'CAS_Forw_ch2', 'CAS_Forw_ch3', 'CAS_Forw_ch4', 'CAS_Forw_ch5', 'CAS_Forw_ch6', 'CAS_Forw_ch7', 'CAS_Forw_ch8', 'CAS_Forw_ch9', 'CAS_Forw_ch10', 'CAS_Forw_ch11', 'CAS_Forw_ch12', 'CAS_Forw_ch13', 'CAS_Forw_ch14', 'CAS_Forw_ch15', 'CAS_Forw_ch16', 'CAS_Forw_ch17', 'CAS_Forw_ch18', 'CAS_Forw_ch19', 'CAS_Forw_ch20', 'CAS_Forw_ch21', 'CAS_Forw_ch22', 'CAS_Forw_ch23', 'CAS_Forw_ch24', 'CAS_Forw_ch25', 'CAS_Forw_ch26', 'CAS_Forw_ch27', 'CAS_Forw_ch28', 'CAS_Forw_ch29', 'CAS_Back_ch0', 'CAS_Back_ch1', 'CAS_Back_ch2', 'CAS_Back_ch3', 'CAS_Back_ch4', 'CAS_Back_ch5', 'CAS_Back_ch6', 'CAS_Back_ch7', 'CAS_Back_ch8', 'CAS_Back_ch9', 'CAS_Back_ch10', 'CAS_Back_ch11', 'CAS_Back_ch12', 'CAS_Back_ch13', 'CAS_Back_ch14', 'CAS_Back_ch15', 'CAS_Back_ch16', 'CAS_Back_ch17', 'CAS_Back_ch18', 'CAS_Back_ch19', 'CAS_Back_ch20', 'CAS_Back_ch21', 'CAS_Back_ch22', 'CAS_Back_ch23', 'CAS_Back_ch24', 'CAS_Back_ch25', 'CAS_Back_ch26', 'CAS_Back_ch27', 'CAS_Back_ch28', 'CAS_Back_ch29', 'Airspeed_(m/s)', 'CAS_#_Conc', 'CAS_LWC', 'CAS_MVD', 'CAS_ED', 'Status', 'GPS_Time']
    data['Date'] = file_name[-18:-14]+'-'+file_name[-14:-12]+'-'+file_name[-12:-10]   
    data['Date'] = pd.to_datetime(data['Date'])     
    data['date_time']=data['Date']+pd.to_timedelta(data['Time'].astype(int),unit='s') 
    data_aimms_start=str(data_aimms['date_time'].iloc[0])
    data_aimms_end=str(data_aimms['date_time'].iloc[-1])
    index_sp=data[data['date_time'] == data_aimms_start].index[0] 
    index_ep=data[data['date_time'] == data_aimms_end].index[0] 
    data_cas=data.loc[index_sp:index_ep+1,:]
    headerpsd_cas=['CAS_Forw_ch1', 'CAS_Forw_ch2', 'CAS_Forw_ch3', 'CAS_Forw_ch4', 'CAS_Forw_ch5', 'CAS_Forw_ch6', 'CAS_Forw_ch7', 'CAS_Forw_ch8', 'CAS_Forw_ch9', 'CAS_Forw_ch10', 'CAS_Forw_ch11', 'CAS_Forw_ch12', 'CAS_Forw_ch13', 'CAS_Forw_ch14', 'CAS_Forw_ch15', 'CAS_Forw_ch16', 'CAS_Forw_ch17', 'CAS_Forw_ch18', 'CAS_Forw_ch19', 'CAS_Forw_ch20', 'CAS_Forw_ch21', 'CAS_Forw_ch22', 'CAS_Forw_ch23', 'CAS_Forw_ch24', 'CAS_Forw_ch25', 'CAS_Forw_ch26', 'CAS_Forw_ch27', 'CAS_Forw_ch28', 'CAS_Forw_ch29'] 
    data_c_psd_cas = pd.DataFrame()
    for kk in headerpsd_cas:
        data_c_psd_cas[kk]=data_cas[kk]
    data_cas['sample_volumn'] = data_cas['Airspeed_(m/s)'].map(lambda x: 0.25*x) 
    data_con_psd_cas = data_c_psd_cas.div(data_cas['sample_volumn'],axis=0)
    data_tot_con= data_con_psd_cas.sum(axis=1)
    bin_list_cas=[0.68,0.75,0.82,0.89,0.96,1.03,1.1,1.17,1.25,1.5,2,2.5,3,3.5,4,5,6.5,7.2,7.9,10.2,12.5,15,20,25,30,35,40,45,50]

    bin_list_cas_wid= [bin_list_cas[i]-bin_list_cas[i-1] for i in range(len(bin_list_cas))]
    bin_list_cas_wid[0]=0.07    

    dDp_df_cas = pd.DataFrame(np.random.rand(data_con_psd_cas.shape[0],data_con_psd_cas.shape[1]))       
    dDp_df_cas.columns=data_con_psd_cas.columns
    dDp_df_cas.index=data_con_psd_cas.index
    dDp_df_cas_1= pd.DataFrame(bin_list_cas_wid).T 
    for i in range(data_con_psd_cas.shape[0]):
        dDp_df_cas.iloc[i] = dDp_df_cas_1.values
    data_dn_ddp_cas = data_con_psd_cas / dDp_df_cas
    data_dn_ddp_cas.index=data_cas['date_time'] 
    cas_mid_size=[0.68,0.75,0.82,0.89,0.96,1.03,1.1,1.17,1.25,1.5,2,2.5,3,3.5,4,5,6.5,7.2,7.9,10.2,12.5,15,20,25,30,35,40,45,50]  
    
    data_cas_ed3_psd = pd.DataFrame()
    data_cas_ed2_psd = pd.DataFrame() 
    data_cas_ed1_psd = pd.DataFrame()
    data_cas_ed0_psd = pd.DataFrame()    
    for edi in range(len(headerpsd_cas)):
        data_cas_ed3_psd[headerpsd_cas[edi]]=data_con_psd_cas[headerpsd_cas[edi]]*(cas_mid_size[edi])**3
        data_cas_ed2_psd[headerpsd_cas[edi]]=data_con_psd_cas[headerpsd_cas[edi]]*(cas_mid_size[edi])**2 
        data_cas_ed1_psd[headerpsd_cas[edi]]=data_con_psd_cas[headerpsd_cas[edi]]*(cas_mid_size[edi])**1
        data_cas_ed0_psd[headerpsd_cas[edi]]=data_con_psd_cas[headerpsd_cas[edi]]*(cas_mid_size[edi])**0
    data_cas_ed3= data_cas_ed3_psd.sum(axis=1)
    data_cas_ed2= data_cas_ed2_psd.sum(axis=1) 
    data_cas_ed1= data_cas_ed1_psd.sum(axis=1)
    data_cas_ed0= data_cas_ed0_psd.sum(axis=1)
    
    data_ed_cas=data_cas_ed3/data_cas_ed2
    data_md_cas=data_cas_ed1/data_cas_ed0
    data_MD_cas=pd.DataFrame(data_md_cas)
    data_MD_cas.index= data_cas['date_time'] 
    data_MD_cas.columns=['MD(um)'] 
    
    data_ED_cas=pd.DataFrame(data_ed_cas)
    data_ED_cas.index= data_cas['date_time']
    data_ED_cas.columns=['ED(um)']  
    data_cas_dm_psd = pd.DataFrame()
    for mm in range(len(headerpsd_cas)):
        data_cas_dm_psd[headerpsd_cas[mm]]=data_con_psd_cas[headerpsd_cas[mm]]*(math.pi/6)*(cas_mid_size[mm])**3*(10**-6)

    data_cas_lwc= data_cas_dm_psd.sum(axis=1)    
    data_cas_lwc=pd.DataFrame(data_cas_lwc)
    data_cas_lwc.index= data_cas['date_time']
    data_cas_lwc.columns=['lwc(g/m^3)']      

    data_result_cas=pd.DataFrame(data_tot_con)
    data_result_cas.index= data_cas['date_time'] 
    data_result_cas.columns=['CAS_con(#/cm^3)']         
    data_result_cas['CAS_ED']=data_ED_cas['ED(um)']
    data_result_cas['CAS_MD']=data_MD_cas['MD(um)']
    data_result_cas['CAS_lwc']=data_cas_lwc['lwc(g/m^3)'] 
    return(data_result_cas,data_dn_ddp_cas)

def cas_make_psd_plot():
    data_cas,data_dn_ddp_cas=read_cal_cas_data(file_cas_name) 
    data_cas_cloud=data_cas[data_cas['CAS_con(#/cm^3)']>=10]
    data_aimms=read_aimms_data(file_aimms_name)
    
    fig,(ax1,ax2,ax3,ax4,ax5) = plt.subplots(5,1,sharex=True)
    fig.set_size_inches(10,10)

    ax1.plot(data_aimms['date_time'],
             data_aimms['Altitude(m)'],
             c='k',
             ls='',
             marker='o',
             ms=2,
             mec='k',
             mfc='k',
             alpha=1,
             label='数浓度(#/cm^3)')

    ax2.plot(data_cas_cloud.index , data_cas_cloud['CAS_con(#/cm^3)'],c='k',ls='',marker='o',ms=2,mec='k',mfc='k',alpha=1)
    ax3.plot(data_cas_cloud.index,data_cas_cloud['CAS_lwc'],c='k',ls='',marker='o',ms=2,lw=1,mec='k',mfc='k',alpha=1)
    ax4.plot(data_cas_cloud.index,data_cas_cloud['CAS_ED'],c='k',ls='',marker='o',ms=2,lw=1,mec='k',mfc='k',alpha=0.5,label='有效直径(μm)') 
    ax1.set_ylabel('高度（m）',fontsize=15) 
    ax2.set_ylabel('数浓度(个/cm$^3$)',fontsize=15) 
    ax3.set_ylabel('液水含量(g/$m^3$)',fontsize=15) 
    ax4.set_ylabel('尺度(μm)',fontsize=15)   
    ax4.set_yscale('log')   
    ax1.grid(True,linestyle=":",linewidth=1,alpha=0.5)   
    ax2.grid(True,linestyle=":",linewidth=1,alpha=0.5)    
    ax3.grid(True,linestyle=":",linewidth=1,alpha=0.5)
    ax4.grid(True,linestyle=":",linewidth=1,alpha=0.5)

    ax4.legend(loc='best',
               edgecolor='gray',
               fontsize=10,
               frameon=True) 
    ax1.tick_params(labelsize=15)
    ax2.tick_params(labelsize=15)
    ax3.tick_params(labelsize=15)
    ax4.tick_params(labelsize=15)
      
    cas_mid_size=[0.68,0.75,0.82,0.89,0.96,1.03,1.1,1.17,1.25,1.5,2,2.5,3,3.5,4,5,6.5,7.2,7.9,10.2,12.5,15,20,25,30,35,40,45,50]
    x = data_dn_ddp_cas.index.tolist()
    y=cas_mid_size
    X,Y = np.meshgrid(x,y)
    z_tem =  data_dn_ddp_cas.values 
    z_tem=ma.masked_where(z_tem <= 0, z_tem)
    start_list_dn=z_tem.min() 
    end_list_dn=z_tem.max()
    cbar_ticks_list=cbar_ticks(start_list_dn,end_list_dn) 
    gap_ax = np.logspace(math.log10(start_list_dn),math.log10(end_list_dn),30,endpoint=True)  
    z = data_dn_ddp_cas 
    index_none_cloud=data_cas[data_cas['CAS_con(#/cm^3)']<10].index 
    z.loc[index_none_cloud,:]= np.nan
    Z = z.values.T 

    im = ax5.contourf(X,Y,Z,gap_ax,norm=clr.LogNorm(),cmap='jet',origin='lower')  
                
    ax5.yaxis.grid(False)
    ax5.set_ylabel('尺度(μm)',fontsize=15)
    ax5.set_yscale('log')
    ax5.set_xlabel('时间',fontsize=15) 
    ax5.tick_params(labelsize=15)    
    ax5.set_ylim(0.6,50) 
    ax5.xaxis.set_major_formatter(mdate.DateFormatter('%H:%M'))

    fig.subplots_adjust(left=0.07, right=0.87)
    box = ax5.get_position()
    pad, width = 0.02, 0.02 
    cax = fig.add_axes([box.xmax + pad, box.ymin, width, box.height]) 
    cbar= fig.colorbar(im,cax=cax,extend='both',ticks=cbar_ticks_list)
    cbar.set_label('(个/$cm^3$/μm)',fontsize=10)
    cbar.ax.tick_params(labelsize=15)  

    fig.savefig('图13.4_云滴谱和各参量时间序列.pdf',dpi = 300, bbox_inches='tight', pad_inches=0.1)
    plt.close()              
    return()

def plot_cas_multi_time_psds(time_list,color_list) :
    data_cas,data_dn_ddp_cas=read_cal_cas_data(file_cas_name)
    
    y=[0.68,0.75,0.82,0.89,0.96,1.03,1.1,1.17,1.25,1.5,2,2.5,3,3.5,4,5,6.5,7.2,7.9,10.2,12.5,15,20,25,30,35,40,45,50]

    fig,ax = plt.subplots()
    fig.set_size_inches(7,5)

    for i in range(len(time_list)):
        ave_data_cas_dNdp=data_dn_ddp_cas.loc[time_list[i][0]:time_list[i][1],:].mean()
        df_ave_dNdDp_cas = pd.DataFrame()
        df_ave_dNdDp_cas['dp']=y
        df_ave_dNdDp_cas['dN']=ave_data_cas_dNdp.T.values
        
        ax.plot( df_ave_dNdDp_cas['dp'], df_ave_dNdDp_cas['dN'],color=color_list[i],label='PSD_('+time_list[i][0]+'-'+time_list[i][1]+')',linestyle='-',lw=2,alpha=1,marker='o',ms=4,mec=color_list[i],mfc=color_list[i]) 

    ax.set_xlabel('尺度(μm)',fontsize=15)
    ax.set_ylabel('分档数浓度 (个/cm$^3$/μm)',fontsize=15) 
    ax.legend(loc='best',edgecolor='gray',fontsize=8,frameon=True)
    ax.grid(True,linestyle=":",linewidth=1,alpha=0.5)
    ax.set_xlim(0.6, 60)
    ax.set_yscale('log')
    ax.tick_params(labelsize=15)
    
    fig.savefig('图13.5_云滴平均谱.pdf',dpi = 300, bbox_inches='tight', pad_inches=0.1)
    plt.close()                
    return()

if __name__ == '__main__':
    
    file_aimms_name='07AIMMS2020100818093022.csv'     
    file_cas_name='02CAS20100818093022.csv'            
    data_aimms=read_aimms_data(file_aimms_name) 
    data_cas,data_dn_ddp_cas=read_cal_cas_data(file_cas_name)
    data_cas.to_csv('云滴参量计算结果.csv', index=False)        
    cas_make_psd_plot()
    time_list=[['2010-08-18 10:50:00','2010-08-18 10:55:00'],
               ['2010-08-18 10:35:00','2010-08-18 10:40:00'],
               ['2010-08-18 12:16:00','2010-08-18 12:20:00']]  
    color_list=['r','g','b']
    plot_cas_multi_time_psds(time_list,color_list)
end = time.clock()
print('>>> Total running time: %s Seconds'%(end-start))